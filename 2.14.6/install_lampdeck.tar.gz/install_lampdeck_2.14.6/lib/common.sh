#!/bin/bash

###############################################################################
# LAMP Deck common library
#
# Shared variables and helpers used by core commands and app modules.
###############################################################################

set -euo pipefail

APP_NAME="${APP_NAME:-LAMP Deck}"
APP_VERSION="${APP_VERSION:-2.14.6}"

WWW_ROOT="/var/www"
CERT_DIR="/var/www/certs"

# Output Colors
if [ -t 1 ]; then
    RED='\033[0;91m'
    GREEN='\033[0;32m'
    YELLOW='\033[0;33m'
    CYAN='\033[0;36m'
    WHITE='\033[1;37m'
    NC='\033[0m'
else
    RED=''
    GREEN=''
    YELLOW=''
    CYAN=''
    WHITE=''
    NC=''
fi

###############################################################################
# Global configuration
###############################################################################

LAMPDECK_CONFIG="/etc/lampdeck/config.sh"

if [ -f "$LAMPDECK_CONFIG" ]; then
    # shellcheck disable=SC1090
    source "$LAMPDECK_CONFIG"
fi

###############################################################################
# Supported Applications
###############################################################################

list_supported_apps() {
    local dir="${APPS_DIR:-$LIB_DIR/apps}"
    local f
    local app

    [ -d "$dir" ] || return

    for f in "$dir"/*.sh; do
        [ -e "$f" ] || continue

        app="$(basename "$f" .sh)"

        case "$app" in
            template-*)
                continue
                ;;
        esac

        echo "$app"
    done | sort
}

###############################################################################
# network helpers
###############################################################################

get_server_ip() {

    local ip

    ip="$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')"

    echo "${ip:-127.0.0.1}"

}

###############################################################################
# Web user detection / validation
###############################################################################

detect_web_user() {

    if [ ! -r /etc/os-release ]; then
        echo -e "${RED}Error: cannot detect Linux distribution.${NC}"
        exit 1
    fi

    . /etc/os-release

    DIST_ID="${ID:-unknown}"
    DIST_PRETTY_NAME="${PRETTY_NAME:-$DIST_ID}"

    case "$DIST_ID" in
        debian|ubuntu)
            WEB_USER="www-data"
            WEB_GROUP="www-data"
            ;;

        alpine)
            WEB_USER="apache"
            WEB_GROUP="apache"
            ;;

        fedora|rhel|centos|rocky|almalinux|ol)
            WEB_USER="apache"
            WEB_GROUP="apache"
            ;;

        arch|manjaro)
            WEB_USER="http"
            WEB_GROUP="http"
            ;;

        opensuse*|sles)
            WEB_USER="wwwrun"
            WEB_GROUP="www"
            ;;

        *)
            echo -e "${RED}Error: unsupported Linux distribution for LAMP Deck.${NC}"
            echo "Detected: $DIST_PRETTY_NAME"
            exit 1
            ;;
    esac

    export DIST_ID DIST_PRETTY_NAME WEB_USER WEB_GROUP
}

validate_web_user() {

    if ! id "$WEB_USER" >/dev/null 2>&1; then
        echo -e "${RED}Error: web user '$WEB_USER' was not found.${NC}"
        echo "Detected distribution: ${DIST_PRETTY_NAME:-unknown}"
        echo
        echo "This usually means the web server package was not installed correctly."
        exit 1
    fi

    if ! getent group "$WEB_GROUP" >/dev/null 2>&1; then
        echo -e "${RED}Error: web group '$WEB_GROUP' was not found.${NC}"
        echo "Detected distribution: ${DIST_PRETTY_NAME:-unknown}"
        echo
        echo "This usually means the web server package was not installed correctly."
        exit 1
    fi
}

ensure_web_user() {
    detect_web_user
    validate_web_user
}

detect_web_user

case "${DIST_ID:-}" in
    alpine)
        APACHE_SITES_AVAILABLE="/etc/apache2/conf.d"
        APACHE_SITES_ENABLED="/etc/apache2/conf.d"
        APACHE_CONF_AVAILABLE="/etc/apache2/conf.d"
        SUBSITES_CONF="/etc/apache2/conf.d/subsites-aliases.conf"
        APACHE_LOG_DIR="/var/www/logs"
        ;;

    *)
        APACHE_SITES_AVAILABLE="/etc/apache2/sites-available"
        APACHE_SITES_ENABLED="/etc/apache2/sites-enabled"
        APACHE_CONF_AVAILABLE="/etc/apache2/conf-available"
        SUBSITES_CONF="/etc/apache2/conf-available/subsites-aliases.conf"
        APACHE_LOG_DIR="/var/log/apache2"
        ;;
esac

export APACHE_LOG_DIR

###############################################
# Apache
###############################################

apache_configtest() {
    if command -v apache2ctl >/dev/null 2>&1; then
        apache2ctl configtest >/dev/null
    elif command -v httpd >/dev/null 2>&1; then
        httpd -t >/dev/null
    else
        echo -e "${RED}Error: Apache command not found.${NC}"
        exit 1
    fi
}

apache_reload() {
    apache_configtest

    if command -v systemctl >/dev/null 2>&1; then
        systemctl reload apache2
    elif command -v rc-service >/dev/null 2>&1; then
        rc-service apache2 reload || rc-service apache2 restart
    else
        echo -e "${RED}Error: service manager not found.${NC}"
        exit 1
    fi
}

apache_enable_site() {
    local conf="$1"

    case "$DIST_ID" in
        alpine)
            return 0
            ;;
        *)
            a2ensite "$conf"
            ;;
    esac
}

apache_disable_site() {
    local conf="$1"

    case "$DIST_ID" in
        alpine)
            return 0
            ;;
        *)
            a2dissite "$conf"
            ;;
    esac
}

apache_load_module_once() {
    local module="$1"
    local file="/etc/apache2/httpd.conf"

    sed -i "\|$module|d" "$file"
    echo "$module" >> "$file"
}

###############################################
# PHP
###############################################

detect_php_fpm_socket() {

    local socket=""
    local preferred_version="${1:-}"

    # Debian / Ubuntu preferred version
    if [ -n "$preferred_version" ]; then

        socket="/run/php/php${preferred_version}-fpm.sock"

        if [ -S "$socket" ]; then
            echo "$socket"
            return 0
        fi
    fi

    # Debian / Ubuntu
    for socket in /run/php/php*-fpm.sock; do

        if [ -S "$socket" ]; then
            echo "$socket"
            return 0
        fi
    done

    # Alpine
    if [ -S /run/php-fpm/php-fpm.sock ]; then
        echo "/run/php-fpm/php-fpm.sock"
        return 0
    fi

    # Generic fallback
    if [ -S /run/php-fpm.sock ]; then
        echo "/run/php-fpm.sock"
        return 0
    fi

    echo -e "${RED}Error: PHP-FPM socket not found.${NC}"
    return 1
}

get_php_fpm_socket() {
    detect_php_fpm_socket
}

get_php_fpm_minor() {

    local socket

    socket="$(get_php_fpm_socket)"

    if [ -n "$socket" ]; then

        echo "$socket" \
            | sed -E 's|.*/php([0-9]+\.[0-9]+)-fpm\.sock|\1|'
    fi
}

get_php_fpm_version() {

    if command -v php >/dev/null 2>&1; then
        php -r 'echo PHP_VERSION;' 2>/dev/null
        return 0
    fi

    echo "Unknown"
}
