#!/bin/bash

###############################################################################
# LAMP Deck module
# restore
#
# Description:
# Restores a website backup created by the LAMP Deck backup command.
#
# The restore operation includes:
# - website files restoration
# - MariaDB application user and grants restoration, when available
# - MariaDB database restoration, when available
# - Apache alias recovery for individual restore operations
#
# WARNING:
# This operation may overwrite existing files and databases.
#
# Usage:
# lampdeck restore <backup-file> [--force]
#
# Example:
# lampdeck restore my-crm_20260610_165142.tar.gz
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/db.sh"

BACKUP_FILE=""
FORCE=0

for arg in "$@"; do
    case "$arg" in
        --force)
            FORCE=1
            ;;
        *)
            if [ -z "$BACKUP_FILE" ]; then
                BACKUP_FILE="$arg"
            fi
            ;;
    esac
done

if [ -z "$BACKUP_FILE" ]; then
    echo "Usage: lampdeck restore <backup-file> [--force]"
    exit 1
fi

if [ ! -f "$BACKUP_FILE" ]; then

    FOUND_BACKUP=""

    if [ -d "/var/backups/lampdeck/$BACKUP_FILE" ]; then
        FOUND_BACKUP="$(find "/var/backups/lampdeck/$BACKUP_FILE" \
            -maxdepth 1 \
            -type f \
            -name "${BACKUP_FILE}_*.tar.gz" \
            | sort \
            | tail -n1)"
    fi

    if [ -z "$FOUND_BACKUP" ]; then
        FOUND_BACKUP="$(find /var/backups/lampdeck \
            -mindepth 2 \
            -maxdepth 2 \
            -type f \
            -name "$BACKUP_FILE" \
            -print -quit 2>/dev/null)"
    fi

    if [ -n "$FOUND_BACKUP" ]; then
        BACKUP_FILE="$FOUND_BACKUP"
    fi

fi

if [ ! -f "$BACKUP_FILE" ]; then
    echo "Backup file not found:"
    echo "$BACKUP_FILE"
    exit 1
fi

TMP_PARENT="/var/tmp/lampdeck-restore"
mkdir -p "$TMP_PARENT"
TMP_DIR="$(mktemp -d "$TMP_PARENT/restore.XXXXXX")"

cleanup() {
    rm -rf "$TMP_DIR"
}

trap cleanup EXIT

echo
echo "============================================"
echo "LAMP Deck BACKUP RESTORE"
echo "============================================"
echo
echo "Backup file:"
echo "$BACKUP_FILE"
echo

echo "Extracting..."
tar xzf "$BACKUP_FILE" -C "$TMP_DIR"

INFO_FILE="$TMP_DIR/backup-info.txt"

if [ ! -f "$INFO_FILE" ]; then
    echo "Invalid backup file."
    exit 1
fi

SITE="$(grep '^Site:' "$INFO_FILE" | cut -d':' -f2- | xargs)"
HAS_DB="$(grep '^Has DB:' "$INFO_FILE" | cut -d':' -f2- | xargs)"
DATABASE="$(grep '^Database:' "$INFO_FILE" | cut -d':' -f2- | xargs)"

echo
echo "WARNING"
echo "------------------------------------------------"
echo
echo "THIS OPERATION MAY DESTROY YOUR DATA"
echo
echo "Existing website files will be replaced."
echo "Existing database content will be replaced."
echo
echo "Website : $SITE"
echo "Database: ${DATABASE:--}"
echo
echo "------------------------------------------------"
echo

if [ "$FORCE" -eq 0 ]; then
    read -r -p "Continue? (y/N): " CONFIRM

    if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
        echo "Restore cancelled."
        exit 0
    fi
fi

BASE="$WWW_ROOT/$SITE"

echo "Restoring website files..."

if [ ! -d "$TMP_DIR/files" ]; then
    echo "ERROR: files directory not found inside backup."
    exit 1
fi

rm -rf "$BASE"
mkdir -p "$BASE"

rsync -a "$TMP_DIR/files/" "$BASE/"

echo "Applying permissions..."

validate_web_user

chown -R "$WEB_USER:$WEB_GROUP" "$BASE"
find "$BASE" -type d -exec chmod 755 {} \;
find "$BASE" -type f -exec chmod 644 {} \;

if [ -d "$BASE/moodledata" ]; then
    chmod -R u+rwX,g+rwX "$BASE/moodledata"
fi

if [ "$FORCE" -eq 0 ]; then
    echo "Recovering website alias..."
    lampdeck recover "$SITE" >/dev/null
fi

if [ "$HAS_DB" = "1" ]; then

    echo
    echo "A MariaDB root password is required to recreate"
    echo "and restore databases from backups that contain MariaDB data."
    echo

    if [ -z "${DB_ROOT_PASS:-}" ]; then
        DB_ROOT_PASS="$(db_prompt_root_password)"
        db_validate_root "$DB_ROOT_PASS"
    fi

    SQL_FILE="$(find "$TMP_DIR" \
        -maxdepth 1 \
        -type f \
        -name "${SITE}_*.sql" \
        ! -name "${SITE}_*_user.sql" \
        -print -quit)"

    USER_SQL_FILE="$(find "$TMP_DIR" \
        -maxdepth 1 \
        -type f \
        -name "${SITE}_*_user.sql" \
        -print -quit)"

    if [ -n "${USER_SQL_FILE:-}" ] && [ -f "$USER_SQL_FILE" ]; then
        echo "Restoring database user..."
        echo "User SQL file: $(basename "$USER_SQL_FILE")"

        mariadb -u root -p"$DB_ROOT_PASS" \
            -e "DROP USER IF EXISTS '$SITE'@'localhost';"

        if ! mariadb -u root -p"$DB_ROOT_PASS" < "$USER_SQL_FILE"; then
            echo
            echo "ERROR: database user restore failed for $SITE"
            echo "SQL file: $USER_SQL_FILE"
            exit 1
        fi
    fi

    echo "Restoring database..."

    if [ -z "${SQL_FILE:-}" ] || [ ! -f "$SQL_FILE" ]; then
        echo "ERROR: database dump not found inside backup."
        exit 1
    fi

    echo "SQL file: $(basename "$SQL_FILE")"

    if ! mariadb -u root -p"$DB_ROOT_PASS" < "$SQL_FILE"; then
        echo
        echo "ERROR: database restore failed for $SITE"
        echo "SQL file: $SQL_FILE"
        exit 1
    fi

fi

echo
echo "============================================"
echo "RESTORE COMPLETED FOR $SITE"
echo "============================================"
echo
