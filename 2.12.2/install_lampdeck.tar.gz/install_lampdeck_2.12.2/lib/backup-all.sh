#!/bin/bash

###############################################################################
# LAMP Deck module
# backup-all
#
# Description:
# Creates individual compressed backups for all websites managed by LAMP Deck.
#
# It scans /var/www, ignores internal folders such as html and certs, and calls
# the regular backup module for each website found.
#
# Each website backup follows the same behavior as:
# lampdeck backup <folder>
#
# This command does not create one single combined archive. Instead, it creates
# one backup archive per website under:
# /var/backups/lampdeck/<site>/
#
# When database-backed applications are found, the MariaDB root password is
# requested only once and reused for all database dumps in the same execution.
#
# Usage:
# lampdeck backup-all
#
# Example:
# lampdeck backup-all
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"
source "$LIB_DIR/db.sh"

echo
echo "============================================"
echo "LAMP Deck Backup-All"
echo "============================================"
echo
echo "This operation will create backups for all websites."
echo
echo "A MariaDB root password is required to export"
echo "databases from applications that use MariaDB."
echo
echo "No changes will be made to existing websites."
echo

DB_ROOT_PASS="$(db_prompt_root_password)"
db_validate_root "$DB_ROOT_PASS"
export DB_ROOT_PASS

for base in "$WWW_ROOT"/*; do
    [ -d "$base" ] || continue

    site="$(basename "$base")"

    case "$site" in
        html|certs|localhost|logs|modules|run)
            continue
            ;;
    esac

    "$LIB_DIR/backup.sh" "$site"
done

unset DB_ROOT_PASS
