#!/bin/bash

###############################################################################
# LAMP Deck module
# auth-enable
#
# Description:
# Enables HTTP Basic Authentication for the LAMP Deck frontpage.
#
# Features:
# - default user: admin
# - optional custom username
# - hidden password prompt
# - password confirmation
# - Apache configuration update
# - automatic web server reload
#
# Usage:
#   lampdeck auth-enable
#   lampdeck auth-enable <user>
#
# Examples:
#   lampdeck auth-enable
#   lampdeck auth-enable aurelio
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

if [ $# -eq 0 ]; then
    AUTH_USER="admin"

elif [ $# -eq 1 ]; then
    AUTH_USER="$1"

else
    echo "Usage:"
    echo "  lampdeck auth-enable"
    echo "  lampdeck auth-enable <user>"
    exit 1
fi

while true; do

    read -r -s -p "Password: " AUTH_PASS
    echo

    if [ -z "$AUTH_PASS" ]; then
        echo "Error: password cannot be empty."
        continue
    fi

    read -r -s -p "Confirm password: " AUTH_PASS_CONFIRM
    echo

    if [ "$AUTH_PASS" != "$AUTH_PASS_CONFIRM" ]; then
        echo "Error: passwords do not match."
        continue
    fi

    break

done

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")" && pwd)}"
source "$LIB_DIR/common.sh"

VHOST="$APACHE_SITES_AVAILABLE/000-lampdeck-default.conf"

HTPASSWD_FILE="/etc/apache2/.htpasswd"

[ -f "$VHOST" ] || { echo "Error: $VHOST not found"; exit 1; }

HASH="$(openssl passwd -apr1 "$AUTH_PASS")"

cat > "$HTPASSWD_FILE" <<EOF
$AUTH_USER:$HASH
EOF

sed -i '/<Directory \/var\/www\/html>/,/<\/Directory>/ {
    /AuthType Basic/d
    /AuthName "LAMP Deck"/d
    /AuthUserFile/d
    /Require all granted/d
    /Require valid-user/d
}' "$VHOST"

sed -i '/<Directory \/var\/www\/html>/a\
    AllowOverride All\
    AuthType Basic\
    AuthName "LAMP Deck"\
    AuthUserFile /etc/apache2/.htpasswd\
    Require valid-user' "$VHOST"

apache_reload

echo
echo "Frontpage authentication enabled."
echo "User: $AUTH_USER"
echo
