#!/bin/bash

###############################################################################
# LAMP Deck module
# auth-disable
#
# Description:
# Disables HTTP Basic Authentication for the LAMP Deck frontpage.
#
# Features:
# - removes authentication directives
# - restores public frontpage access
# - removes htpasswd file
# - automatic web server reload
#
# Usage:
#   lampdeck auth-disable
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

echo
read -r -p "Disable frontpage authentication? [y/N]: " CONFIRM

case "$CONFIRM" in
    y|Y|yes|YES)
        ;;
    *)
        echo "Operation cancelled."
        exit 0
        ;;
esac

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")" && pwd)}"
source "$LIB_DIR/common.sh"

VHOST="$APACHE_SITES_AVAILABLE/000-lampdeck-default.conf"

HTPASSWD_FILE="/etc/apache2/.htpasswd"

[ -f "$VHOST" ] || { echo "Error: $VHOST not found"; exit 1; }

sed -i '/<Directory \/var\/www\/html>/,/<\/Directory>/ {
    /AuthType Basic/d
    /AuthName "LAMP Deck"/d
    /AuthUserFile/d
    /Require valid-user/d
    /Require all granted/d
}' "$VHOST"

sed -i '/<Directory \/var\/www\/html>/a\
    AllowOverride All\
    Require all granted' "$VHOST"

rm -f "$HTPASSWD_FILE"

apache_reload

echo
echo "Frontpage authentication disabled."
echo
