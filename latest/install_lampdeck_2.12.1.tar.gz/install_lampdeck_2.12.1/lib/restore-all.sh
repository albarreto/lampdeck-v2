#!/bin/bash

###############################################################################
# LAMP Deck module
# restore-all
#
# Description:
# Restores the latest backup of all websites.
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"
source "$LIB_DIR/db.sh"

BACKUP_ROOT="/var/backups/lampdeck"

echo
echo "============================================"
echo "LAMP Deck Restore-All"
echo "============================================"
echo
echo "WARNING"
echo "------------------------------------------------"
echo
echo "THIS OPERATION MAY DESTROY YOUR DATA"
echo
echo "All websites may be overwritten."
echo "All databases may be overwritten."
echo
echo "------------------------------------------------"
echo

read -r -p "Type RESTORE to continue: " CONFIRM

if [ "$CONFIRM" != "RESTORE" ]; then
    echo
    echo "Restore cancelled."
    exit 0
fi

echo
echo "A MariaDB root password is required to recreate"
echo "and restore databases from backups that contain MariaDB data."
echo

DB_ROOT_PASS="$(db_prompt_root_password)"
db_validate_root "$DB_ROOT_PASS"
export DB_ROOT_PASS

for site_dir in "$BACKUP_ROOT"/*; do
    [ -d "$site_dir" ] || continue

    SITE="$(basename "$site_dir")"

    LATEST="$(find "$site_dir" -maxdepth 1 -type f -name "${SITE}_*.tar.gz" \
        | sort \
        | tail -n1)"

    if [ -z "$LATEST" ]; then
        echo "Skipping $SITE: no backup found."
        continue
    fi

    lampdeck restore "$LATEST" --force
done

unset DB_ROOT_PASS

