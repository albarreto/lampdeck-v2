#!/bin/bash

###############################################################################
# LAMP Deck library
# mail
#
# Description:
# Configures Postfix as a local SMTP relay for applications installed by
# LAMP Deck. Applications send mail to 127.0.0.1:25 without authentication,
# and Postfix relays the messages through an external authenticated SMTP server.
#
# Commands:
#   lampdeck mail-config
#   lampdeck mail-test <email>
#   lampdeck mail-status
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

MAIL_CONF="/etc/lampdeck/mail.conf"
POSTFIX_SASL="/etc/postfix/sasl_passwd"

###############################################################################
# Helpers
###############################################################################

mail_detect_os() {
    if [ ! -r /etc/os-release ]; then
        echo "Error: cannot detect Linux distribution."
        exit 1
    fi

    # shellcheck disable=SC1091
    . /etc/os-release

    DIST_ID="${ID:-unknown}"
}

mail_install_postfix_if_needed() {
    if command -v postfix >/dev/null 2>&1 && command -v postconf >/dev/null 2>&1; then
        return 0
    fi

    mail_detect_os

    echo "Installing Postfix mail relay packages..."

    case "$DIST_ID" in
        debian|ubuntu)
            export DEBIAN_FRONTEND=noninteractive

            apt-get update

            # Preseed a minimal local-only Postfix setup to avoid interactive dialogs.
            echo "postfix postfix/mailname string localhost" | debconf-set-selections
            echo "postfix postfix/main_mailer_type string Local only" | debconf-set-selections

            apt-get install -y \
                postfix \
                mailutils \
                libsasl2-modules \
                ca-certificates \
                rsyslog

            systemctl enable --now rsyslog >/dev/null 2>&1 || true
            ;;

        alpine)
            apk add --no-cache \
                postfix \
                mailx \
                cyrus-sasl \
                cyrus-sasl-login \
                rsyslog \
                ca-certificates

                rc-update add rsyslog default
                rc-update add postfix default

                rc-service rsyslog start >/dev/null 2>&1 || true
                rc-service postfix start >/dev/null 2>&1 || true

            ;;

        *)
            echo "Error: unsupported Linux distribution for automatic Postfix install: $DIST_ID"
            exit 1
            ;;
    esac
}

mail_restart_postfix() {
    if command -v systemctl >/dev/null 2>&1; then
        systemctl enable postfix >/dev/null 2>&1 || true
        systemctl restart postfix
        return 0
    fi

    if command -v rc-service >/dev/null 2>&1; then
        rc-service postfix restart
        return 0
    fi

    postfix reload 2>/dev/null || postfix start
}

mail_require_postfix() {
    if ! command -v postconf >/dev/null 2>&1; then
        echo "Error: Postfix is not installed."
        echo "Run: lampdeck mail-config"
        exit 1
    fi
}

mail_load_config() {
    if [ ! -f "$MAIL_CONF" ]; then
        echo "Mail relay is not configured."
        echo "Run: lampdeck mail-config"
        exit 1
    fi

    # shellcheck disable=SC1090
    source "$MAIL_CONF"
}

mail_validate_port() {
    local port="$1"

    if [[ ! "$port" =~ ^[0-9]+$ ]] || [ "$port" -lt 1 ] || [ "$port" -gt 65535 ]; then
        echo "Error: invalid SMTP port: $port"
        exit 1
    fi
}

mail_make_safe_hostname() {
    local host="${1:-}"

    if [ -z "$host" ]; then
        echo "localhost"
        return 0
    fi

    echo "$host" | tr -cd 'a-zA-Z0-9._-'
}

###############################################################################
# mail-config
###############################################################################

mail_config() {
    local smtp_host=""
    local smtp_port=""
    local smtp_user=""
    local smtp_pass=""
    local mail_from=""
    local mail_from_name=""
    local mailname=""

    mail_install_postfix_if_needed

    mkdir -p /etc/lampdeck
    mkdir -p /etc/postfix

    echo
    echo "============================================"
    echo "LAMP Deck Mail Relay Configuration"
    echo "============================================"
    echo
    echo "Apps will send mail to 127.0.0.1:25."
    echo "Postfix will relay through your external SMTP server."
    echo

    read -r -p "SMTP host: " smtp_host
    read -r -p "SMTP port [587]: " smtp_port
    smtp_port="${smtp_port:-587}"

    read -r -p "SMTP username: " smtp_user
    read -r -s -p "SMTP password: " smtp_pass
    echo

    read -r -p "Default From e-mail [$smtp_user]: " mail_from
    mail_from="${mail_from:-$smtp_user}"

    read -r -p "Default From name [LAMP Deck]: " mail_from_name
    mail_from_name="${mail_from_name:-LAMP Deck}"

    mailname="$(hostname -f 2>/dev/null || hostname)"
    mailname="$(mail_make_safe_hostname "$mailname")"

    if [ -z "$smtp_host" ] || [ -z "$smtp_user" ] || [ -z "$smtp_pass" ]; then
        echo "Error: SMTP host, username and password are required."
        exit 1
    fi

    mail_validate_port "$smtp_port"

    cat > "$MAIL_CONF" <<EOCONF
MAIL_RELAY_ENABLED="1"
MAIL_LOCAL_HOST="127.0.0.1"
MAIL_LOCAL_PORT="25"
MAIL_FROM="$mail_from"
MAIL_FROM_NAME="$mail_from_name"
SMTP_HOST="$smtp_host"
SMTP_PORT="$smtp_port"
SMTP_USER="$smtp_user"
EOCONF

    chmod 600 "$MAIL_CONF"

    cat > "$POSTFIX_SASL" <<EOSASL
[$smtp_host]:$smtp_port $smtp_user:$smtp_pass
EOSASL

    chmod 600 "$POSTFIX_SASL"
    postmap "$POSTFIX_SASL"

    postconf -X default_transport 2>/dev/null || true
    postconf -X relay_transport 2>/dev/null || true

    # Keep Postfix local-only. Apps on the same server can use 127.0.0.1:25,
    # but the server will not become an open relay on the network.
    postconf -e "myhostname = $mailname"
    postconf -e "myorigin = /etc/mailname"
    postconf -e "inet_interfaces = loopback-only"
    postconf -e "inet_protocols = ipv4"
    postconf -e "mydestination = localhost"
    postconf -e "mynetworks = 127.0.0.0/8 [::1]/128"
    postconf -e "relayhost = [$smtp_host]:$smtp_port"
    postconf -e "smtp_sasl_auth_enable = yes"
    postconf -e "smtp_sasl_password_maps = hash:$POSTFIX_SASL"
    postconf -e "smtp_sasl_security_options = noanonymous"
    postconf -e "smtp_tls_security_level = encrypt"
    postconf -e "smtp_tls_CAfile = /etc/ssl/certs/ca-certificates.crt"

    echo "$mailname" > /etc/mailname

    mail_restart_postfix

    echo
    echo "Mail relay configured successfully."
    echo
    echo "Configure installed apps with:"
    echo "  SMTP host: 127.0.0.1"
    echo "  SMTP port: 25"
    echo "  SMTP auth: disabled"
    echo "  SMTP TLS: disabled"
    echo
    echo "Testing SMTP connectivity..."

    if timeout 10 bash -c "</dev/tcp/$smtp_host/$smtp_port" 2>/dev/null; then
        echo "SMTP connectivity OK."
    else
        echo
        echo "WARNING: Unable to connect to $smtp_host:$smtp_port"
        echo "Outbound SMTP may be blocked by firewall, proxy or corporate network policy."
        echo
    fi

}

###############################################################################
# mail-test
###############################################################################

mail_test() {
    local to="${1:-}"
    local from=""
    local from_name=""

    if [ -z "$to" ]; then
        echo "Usage: lampdeck mail-test <email>"
        exit 1
    fi

    mail_require_postfix
    mail_load_config

    from="${MAIL_FROM:-lampdeck@localhost}"
    from_name="${MAIL_FROM_NAME:-LAMP Deck}"

    {
        echo "From: $from_name <$from>"
        echo "To: $to"
        echo "Subject: LAMP Deck mail test"
        echo
        echo "This is a test message sent through LAMP Deck Mail Relay."
        echo "Local SMTP: 127.0.0.1:25"
        echo "Relay host: ${SMTP_HOST:-unknown}:${SMTP_PORT:-unknown}"
    } | sendmail -t

    echo "Test message submitted to Postfix for: $to"
    echo "Check logs if it does not arrive."

    sleep 2

    echo
    echo "Queue:"
    postqueue -p 2>/dev/null || true
}

###############################################################################
# mail-status
###############################################################################

mail_status() {
    echo
    echo "============================================"
    echo "LAMP Deck Mail Relay Status"
    echo "============================================"
    echo

    if [ -f "$MAIL_CONF" ]; then
        echo "Config: configured ($MAIL_CONF)"
    else
        echo "Config: not configured"
    fi

    echo
    echo "Hostname: $(postconf -h myhostname 2>/dev/null)"
    echo "Relay: $(postconf -h relayhost 2>/dev/null)"
    echo

    if command -v postconf >/dev/null 2>&1; then
        echo "Postfix configuration:"
        postconf -n \
            relayhost \
            inet_interfaces \
            mynetworks \
            smtp_sasl_auth_enable \
            smtp_tls_security_level || true
    else
        echo "Postfix: not installed"
    fi

    echo

    if command -v systemctl >/dev/null 2>&1; then
        if systemctl --no-pager --quiet is-active postfix; then
            echo "Service: active"
        else
            echo "Service: inactive"
        fi
    elif command -v rc-service >/dev/null 2>&1; then
        rc-service postfix status || true
    fi

    echo
    echo "Queue:"
    postqueue -p 2>/dev/null || true

    echo
    echo "Recent mail log hints:"

    if [ -f /var/log/mail.log ]; then
        tail -n 20 /var/log/mail.log
    elif [ -f /var/log/maillog ]; then
        tail -n 20 /var/log/maillog
    else
        echo "No /var/log/mail.log or /var/log/maillog found."
        echo "On systemd servers, use: journalctl -u postfix -n 50 --no-pager"
    fi

    echo
}

###############################################################################
# mail-flush
###############################################################################

mail_flush() {
    mail_require_postfix

    echo
    echo "============================================"
    echo "LAMP Deck Mail Relay Queue Cleanup"
    echo "============================================"
    echo

    postqueue -p

    echo
    read -r -p "Delete all queued messages? (y/N): " answer

    case "$answer" in
        y|Y|yes|YES)
            postsuper -d ALL

            echo
            echo "Queue cleaned successfully."
            ;;
        *)
            echo
            echo "Operation cancelled."
            ;;
    esac

    echo
}

###############################################################################
# Router
###############################################################################

case "${1:-}" in
    config)
        mail_config
        ;;

    test)
        shift || true
        mail_test "${1:-}"
        ;;

    status)
        mail_status
        ;;

    flush)
        mail_flush
        ;;

    *)
        echo "Usage:"
        echo "  lampdeck mail-config"
        echo "  lampdeck mail-test <email>"
        echo "  lampdeck mail-status"
        echo "  lampdeck mail-flush"
        exit 1
        ;;
esac
