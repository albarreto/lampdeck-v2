// ===============================
// Tabs
// ===============================
function initTabs() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabPanels = document.querySelectorAll('.tab-panel');

    tabButtons.forEach((button) => {
        button.addEventListener('click', () => {
            const target = button.dataset.tab;

            tabButtons.forEach((b) => b.classList.remove('active'));
            tabPanels.forEach((p) => p.classList.remove('active'));

            button.classList.add('active');

            const targetPanel = document.getElementById('tab-' + target);

            if (targetPanel) {
                targetPanel.classList.add('active');
            }

            if (target === 'terminal') {
                const terminalFrame = document.getElementById(
                    'lampdeck-terminal-frame'
                );

                if (
                    terminalFrame &&
                    terminalFrame.getAttribute('src') === 'about:blank'
                ) {
                    terminalFrame.setAttribute(
                        'src',
                        terminalFrame.dataset.src
                    );
                }
            }
        });
    });
}

// ===============================
// Filters
// ===============================
function initSiteFilters() {
    const filterButtons = document.querySelectorAll('.filter-button[data-filter]');
    const siteCards = document.querySelectorAll('.site-card[data-category]');
    const toggleDisabledButton = document.getElementById('toggle-disabled');

    let currentCategory = 'all';
    let showDisabled = false;

    function applySiteFilters() {
        siteCards.forEach((card) => {
            const category = card.dataset.category;
            const disabled = card.dataset.disabled === '1';

            const categoryMatch = currentCategory === 'all' || category === currentCategory;
            const disabledMatch = showDisabled || !disabled;

            card.style.display = (categoryMatch && disabledMatch) ? 'block' : 'none';
        });
    }

    filterButtons.forEach((button) => {
        button.addEventListener('click', () => {
            currentCategory = button.dataset.filter;

            filterButtons.forEach((b) => b.classList.remove('active'));
            button.classList.add('active');

            applySiteFilters();
        });
    });

    if (toggleDisabledButton) {
        toggleDisabledButton.addEventListener('click', () => {
            showDisabled = !showDisabled;
            toggleDisabledButton.dataset.showDisabled = showDisabled ? '1' : '0';
            toggleDisabledButton.classList.toggle('active', showDisabled);
            toggleDisabledButton.textContent = showDisabled ? 'Hide disabled' : 'Show disabled';

            applySiteFilters();
        });
    }

    applySiteFilters();
}

// ===============================
// Init
// ===============================
document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initSiteFilters();
});

