#!/bin/bash

###############################################################################
# LAMP Deck module
# recover-all
#
# Description:
# Recreates Apache aliases for all websites managed by LAMP Deck.
#
# It scans /var/www, ignores internal folders such as html and certs,
# and calls the regular recover module for each website found.
#
# Usage:
# lampdeck recover-all
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"

source "$LIB_DIR/common.sh"

echo
echo "============================================"
echo "LAMP Deck Recover-All"
echo "============================================"
echo
echo "This operation will recreate missing Apache aliases for all websites."
echo "Existing aliases will be skipped by the regular recover command."
echo

FOUND=0

for base in "$WWW_ROOT"/*; do
    [ -d "$base" ] || continue

    site="$(basename "$base")"

    case "$site" in
        html|certs|localhost|logs|modules|run)
            continue
            ;;
    esac

    FOUND=1

    echo "Recovering site: $site"
    "$LIB_DIR/recover.sh" "$site"
done

if [ "$FOUND" -eq 0 ]; then
    echo "No websites found in $WWW_ROOT."
    exit 0
fi

echo
echo "Recover-all completed."
echo
