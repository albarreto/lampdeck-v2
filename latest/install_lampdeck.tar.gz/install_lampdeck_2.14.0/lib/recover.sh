#!/bin/bash

###############################################################################
# LAMP Deck module
# recover
#
# Description:
# Recreates the Apache alias configuration for an existing website.
#
# The website files and database are not modified.
# Only the Apache alias entries are rebuilt using the site's metadata.
#
# Usage:
# lampdeck recover <site>
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")" && pwd)}"

source "$LIB_DIR/common.sh"

SITE="${1:-}"

if [ -z "$SITE" ]; then
    echo "Usage: lampdeck recover <site>"
    exit 1
fi

BASE="$WWW_ROOT/$SITE"

if [ ! -d "$BASE" ]; then
    echo "Error: site not found: $SITE"
    exit 1
fi

if grep -q "Alias /$SITE/" "$SUBSITES_CONF" 2>/dev/null; then
    echo "Alias already exists for $SITE"
    exit 0
fi

###############################################################################
# Detect application webroot from lampdeck.ini
#
# Examples:
#   MediaWiki -> empty webroot  -> /var/www/mediawiki
#   Moodle    -> public webroot -> /var/www/moodle/public
###############################################################################

INI="$BASE/lampdeck.ini"
APP_WEBROOT=""

echo "DEBUG recover:"
echo "  SITE=$SITE"
echo "  BASE=$BASE"
echo "  INI=$INI"

if [ -f "$INI" ]; then
    echo "  INI exists: yes"
    echo "  raw webroot line:"
    grep -n "^[[:space:]]*webroot[[:space:]]*=" "$INI" || true
else
    echo "  INI exists: no"
fi

APP_WEBROOT="$(
    awk -F '=' '
        /^\[app\]/ { in_app=1; next }
        /^\[/ && !/^\[app\]/ { in_app=0 }

        in_app && $1 ~ /^[[:space:]]*webroot[[:space:]]*$/ {
            value = $2

            gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
            gsub(/^"/, "", value)
            gsub(/"$/, "", value)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)

            print value
            exit
        }
    ' "$INI"
)"

echo "  APP_WEBROOT=[$APP_WEBROOT]"

###############################################################################
# Validate detected webroot
###############################################################################

ALIAS_TARGET="$BASE"

if [ -n "$APP_WEBROOT" ]; then
    ALIAS_TARGET="$BASE/$APP_WEBROOT"

    if [ ! -d "$ALIAS_TARGET" ]; then
        echo "Error: configured webroot not found:"
        echo "  $ALIAS_TARGET"
        exit 1
    fi
fi

echo "  ALIAS_TARGET=[$ALIAS_TARGET]"

###############################################################################
# Ensure Apache aliases file exists
###############################################################################

if [ ! -f "$SUBSITES_CONF" ]; then
    touch "$SUBSITES_CONF"
fi

###############################################################################
# Recreate Apache alias
###############################################################################

{
    echo
    echo "RedirectMatch 301 ^/$SITE\$ /$SITE/"
    echo "Alias /$SITE/ $ALIAS_TARGET/"
    echo

    if [ -n "$APP_WEBROOT" ]; then
        echo "<Directory $BASE/>"
        echo "    Require all denied"
        echo "</Directory>"
        echo
    fi

    echo "<Directory $ALIAS_TARGET/>"
    echo "    AllowOverride All"
    echo "    Require all granted"
    echo "    DirectoryIndex index.php index.html"
    echo "</Directory>"
    echo

} >> "$SUBSITES_CONF"

apache_reload

echo
echo "Site recovered successfully:"
echo "  https://${HOSTNAME_FQDN:-$(get_server_ip)}/$SITE/"
echo
