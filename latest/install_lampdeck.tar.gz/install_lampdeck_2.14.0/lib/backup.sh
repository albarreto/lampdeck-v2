#!/bin/bash

###############################################################################
# LAMP Deck module
# backup
#
# Description:
# Creates a compressed backup for a single LAMP Deck website.
#
# The backup includes:
# - all website files from /var/www/<site>
# - database dump when lampdeck.ini has [app] has_db = 1
# - MariaDB application user and grants when database is used
# - backup metadata file with site, path, database and timestamp information
#
# Database dumps are generated with --databases, so the SQL file includes
# CREATE DATABASE and USE statements, making restoration easier on another server.
#
# Usage:
# lampdeck backup <folder>
#
# Example:
# lampdeck backup my-crm
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"
source "$LIB_DIR/db.sh"

BACKUP_ROOT="/var/backups/lampdeck"

SITE="${1:-}"
SITE="${SITE#/}"
SITE="${SITE%/}"
BASE="$WWW_ROOT/$SITE"
INI="$BASE/lampdeck.ini"

if [ -z "$SITE" ]; then
    echo -e "${RED}Usage: lampdeck backup <folder>${NC}"
    exit 1
fi

if [ ! -d "$BASE" ]; then
    echo -e "${RED}Error: folder not found: $BASE${NC}"
    exit 1
fi

TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"

TMP_PARENT="/var/tmp/lampdeck-backup"
mkdir -p "$TMP_PARENT"
TMP_DIR="$(mktemp -d "$TMP_PARENT/backup.XXXXXX")"

OUT_DIR="$BACKUP_ROOT/$SITE"
OUT_FILE="$OUT_DIR/${SITE}_${TIMESTAMP}.tar.gz"
SQL_FILE="${SITE}_${TIMESTAMP}.sql"
DB_USER_SQL="${SITE}_${TIMESTAMP}_user.sql"

mkdir -p "$OUT_DIR"

HAS_DB="0"

if [ -f "$INI" ]; then
    HAS_DB="$(awk -F '=' '
        /^\[app\]/ { in_app=1; next }
        /^\[/ && !/^\[app\]/ { in_app=0 }
        in_app && $1 ~ /^[[:space:]]*has_db[[:space:]]*$/ {
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2)
            print $2
            exit
        }
    ' "$INI")"
fi

HAS_DB="${HAS_DB:-0}"

cleanup() {
    rm -rf "$TMP_DIR"
}

trap cleanup EXIT

echo
echo -e "${CYAN}============================================${NC}"
echo -e "${GREEN}Creating backup: $SITE${NC}"
echo -e "${CYAN}============================================${NC}"
echo

echo -e "${CYAN}Copying website files...${NC}"
mkdir -p "$TMP_DIR/files"
rsync -a "$BASE/" "$TMP_DIR/files/"

if [ "$HAS_DB" = "1" ]; then
    if [ -z "${DB_ROOT_PASS:-}" ]; then
        DB_ROOT_PASS="$(db_prompt_root_password)"
        db_validate_root "$DB_ROOT_PASS"
    fi

    echo -e "${CYAN}Exporting database...${NC}"
    mariadb-dump \
        -u root \
        -p"$DB_ROOT_PASS" \
        --databases "$SITE" \
        > "$TMP_DIR/$SQL_FILE"

    echo -e "${CYAN}Exporting database user...${NC}"

    {
        mariadb -N -B -u root -p"$DB_ROOT_PASS" -e "
            SHOW CREATE USER '$SITE'@'localhost';
        " | sed 's/$/;/'

        mariadb -N -B -u root -p"$DB_ROOT_PASS" -e "
            SHOW GRANTS FOR '$SITE'@'localhost';
        " | sed 's/$/;/'
    } > "$TMP_DIR/$DB_USER_SQL" || {
        echo -e "${YELLOW}WARNING: could not export database user '$SITE'@'localhost'.${NC}"
        rm -f "$TMP_DIR/$DB_USER_SQL"
    }
fi

cat > "$TMP_DIR/backup-info.txt" <<EOF
LAMP Deck backup
Site: $SITE
Path: $BASE
Has DB: $HAS_DB
Database: $SITE
Database Dump: $([ "$HAS_DB" = "1" ] && echo "$SQL_FILE" || echo "-")
Database User Dump: $([ "$HAS_DB" = "1" ] && [ -f "$TMP_DIR/$DB_USER_SQL" ] && echo "$DB_USER_SQL" || echo "-")
Created At: $(date '+%Y-%m-%d %H:%M:%S')
EOF

echo -e "${CYAN}Compressing backup...${NC}"
tar czf "$OUT_FILE" -C "$TMP_DIR" .

echo
echo -e "${GREEN}✓ Backup created successfully${NC}"
echo -e "${WHITE}$OUT_FILE${NC}"
echo
