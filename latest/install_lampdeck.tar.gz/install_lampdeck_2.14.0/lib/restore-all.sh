#!/bin/bash

###############################################################################
# LAMP Deck module
# restore-all
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"
source "$LIB_DIR/db.sh"

BACKUP_ROOT="/var/backups/lampdeck"

echo
echo -e "${CYAN}============================================${NC}"
echo -e "${GREEN}LAMP Deck BACKUP RESTORE-ALL${NC}"
echo -e "${CYAN}============================================${NC}"
echo

echo -e "${YELLOW}WARNING${NC}"
echo -e "${YELLOW}------------------------------------------------${NC}"
echo
echo -e "${YELLOW}THIS OPERATION MAY DESTROY YOUR DATA${NC}"
echo
echo "All websites may be overwritten."
echo "All databases may be overwritten."
echo
echo -e "${YELLOW}------------------------------------------------${NC}"
echo

read -r -p "Type RESTORE to continue: " CONFIRM

if [ "$CONFIRM" != "RESTORE" ]; then
    echo
    echo -e "${YELLOW}Restore cancelled.${NC}"
    exit 0
fi

echo
echo -e "${YELLOW}A MariaDB root password is required to recreate${NC}"
echo -e "${YELLOW}and restore databases from backups that contain MariaDB data.${NC}"
echo

DB_ROOT_PASS="$(db_prompt_root_password)"
db_validate_root "$DB_ROOT_PASS"
export DB_ROOT_PASS

for site_dir in "$BACKUP_ROOT"/*; do

    [ -d "$site_dir" ] || continue

    SITE="$(basename "$site_dir")"

    LATEST="$(find "$site_dir" -maxdepth 1 -type f -name "${SITE}_*.tar.gz" \
        | sort \
        | tail -n1)"

    if [ -z "$LATEST" ]; then
        echo -e "${YELLOW}Skipping $SITE: no backup found.${NC}"
        continue
    fi

    lampdeck restore "$LATEST" --force
done

echo
echo -e "${CYAN}Rebuilding website aliases...${NC}"
lampdeck recover-all >/dev/null

echo
echo -e "${GREEN}✓ All backups restored successfully.${NC}"
echo

unset DB_ROOT_PASS
