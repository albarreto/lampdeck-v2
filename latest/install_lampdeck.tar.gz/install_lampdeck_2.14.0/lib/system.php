<?php

function get_meminfo() {
    $data = @file('/proc/meminfo', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $mem = [];

    if ($data) {
        foreach ($data as $line) {
            if (preg_match('/^([A-Za-z_]+):\s+(\d+)/', $line, $m)) {
                $mem[$m[1]] = (int)$m[2] * 1024;
            }
        }
    }

    $total = $mem['MemTotal'] ?? 0;
    $available = $mem['MemAvailable'] ?? ($mem['MemFree'] ?? 0);
    $used = max(0, $total - $available);

    return [
        'total'   => $total,
        'used'    => $used,
        'free'    => $available,
        'percent' => $total > 0 ? round(($used / $total) * 100) : 0
    ];
}

function get_diskinfo($path = '/') {
    $total = @disk_total_space($path) ?: 0;
    $free  = @disk_free_space($path) ?: 0;
    $used  = max(0, $total - $free);

    return [
        'total'   => $total,
        'used'    => $used,
        'free'    => $free,
        'percent' => $total > 0 ? round(($used / $total) * 100) : 0
    ];
}

function service_status($service) {

    if (cmd('command -v systemctl')) {

        $status = cmd(
            'systemctl is-active ' . escapeshellarg($service)
        );

        return $status !== '' ? $status : 'unknown';
    }

    if (cmd('command -v rc-service')) {

        $status = strtolower(cmd(
            'rc-service ' . escapeshellarg($service) . ' status'
        ));

        return (
            str_contains($status, 'started') ||
            str_contains($status, 'running')
        )
            ? 'active'
            : 'inactive';
    }

    return 'unknown';
}

function status_class($status) {
    switch ($status) {
        case 'active':
            return 'ok';
        case 'inactive':
        case 'failed':
            return 'bad';
        default:
            return 'warn';
    }
}

function normalize_version($service, $version) {
    $version = trim((string)$version);

    if ($version === '') {
        return '';
    }

    switch ($service) {
        case 'apache2':
        case 'httpd':

            if (preg_match('/(Apache\/[0-9.]+)/', $version, $m)) {
                return $m[1];
            }

            return $version;
        case 'php':
            if (preg_match('/([0-9]+\.[0-9]+\.[0-9]+)/', $version, $m)) {
                return $m[1];
            }
            return $version;

        case 'mariadb':
            if (preg_match('/([0-9]+\.[0-9]+\.[0-9]+)/', $version, $m)) {
                return $m[1];
            }
            return rtrim(str_replace('MariaDB', '', $version), ' ,');

        default:
            return rtrim($version, ' ,');
    }
}

function service_version($service) {

    switch ($service) {

        case 'apache2':
        case 'httpd':

            $v = cmd(
                "apache2 -v | awk -F': ' '/Server version/ {print \$2}'"
            );

            if ($v === '') {
                $v = cmd(
                    "httpd -v | awk -F': ' '/Server version/ {print \$2}'"
                );
            }

            return normalize_version($service, $v);

        case 'redis':
        case 'redis-server':

            $v = cmd(
                "redis-server --version | awk '{for(i=1;i<=NF;i++) if(\$i ~ /^v=/){sub(/^v=/,\"\",\$i); print \$i}}'"
            );

            return normalize_version($service, $v);

        case 'mariadb':

            $v = cmd("mariadb --version");

            return normalize_version($service, $v);

        default:

            if (preg_match('/^php/', $service)) {
                return normalize_version('php', PHP_VERSION);
            }

            return '';
    }
}


function detect_php_fpm_unit() {

    $patterns = [
        '/run/php/php*-fpm.sock',
        '/run/php-fpm*/php-fpm.sock',
        '/run/php-fpm.sock'
    ];

    foreach ($patterns as $pattern) {

        $matches = glob($pattern);

        if (!$matches) {
            continue;
        }

        foreach ($matches as $sock) {

            // Debian/Ubuntu
            if (preg_match('/php([0-9]+\.[0-9]+)-fpm\.sock/', $sock, $m)) {
                return 'php' . $m[1] . '-fpm';
            }

            // Alpine
            if (preg_match('#/php-fpm([0-9]+)#', $sock, $m)) {
                return 'php-fpm' . $m[1];
            }
        }
    }

    // fallback via Apache configs
    $sock = cmd("
        grep -RhoE 'php([0-9]+\\.[0-9]+-fpm|fpm[0-9]+)\\.sock' \
        /etc/apache2/sites-enabled \
        /etc/apache2/conf-enabled \
        /etc/apache2/conf.d \
        2>/dev/null | head -n1
    ");

    if ($sock !== '') {

        // Debian/Ubuntu
        if (preg_match('/php([0-9]+\.[0-9]+)-fpm\.sock/', $sock, $m)) {
            return 'php' . $m[1] . '-fpm';
        }

        // Alpine
        if (preg_match('/php-fpm([0-9]+)\.sock/', $sock, $m)) {
            return 'php-fpm' . $m[1];
        }
    }

    // OpenRC Alpine fallback
    if (cmd('command -v rc-service')) {

        $services = cmd('rc-service -l 2>/dev/null');

        foreach (explode("\n", $services) as $line) {

            $line = trim($line);

            if (preg_match('/^php-fpm[0-9]+$/', $line)) {
                return $line;
            }
        }
    }

    return 'php-fpm';
}
