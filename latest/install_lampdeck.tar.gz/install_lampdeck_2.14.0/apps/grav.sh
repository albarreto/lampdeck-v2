#!/bin/bash

###############################################################################
# LAMP Deck app module
# grav
#
# Usage:
# lampdeck install grav <site-name> [description]
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="grav"
APP_NAME="Grav"
APP_HAS_DB="0"
APP_CATEGORY="CMS"
APP_ADMIN_PATH="admin"
APP_ADMIN_LABEL="Admin"
APP_DOWNLOAD_URL="https://getgrav.org/download/core/grav-admin/latest"

app_prepare_no_db "${1:-}" "${2:-}"

#########################################
# package
#########################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"
app_init_tmp_dir

echo "Extracting $APP_NAME package..."

unzip -q "$APP_CACHE_FILE" -d "$APP_TMP_DIR"

EXTRACTED_DIR="$(find "$APP_TMP_DIR" -mindepth 1 -maxdepth 1 -type d | head -n 1)"

if [ -z "${EXTRACTED_DIR:-}" ]; then
    echo "Error: extracted directory not found"
    exit 1
fi

echo "Copying $APP_NAME files to $BASE..."
rsync -a "$EXTRACTED_DIR"/ "$BASE"/

#########################################
# apache / rewrite
#########################################

if [ -f "$BASE/webserver-configs/htaccess.txt" ]; then
    cp "$BASE/webserver-configs/htaccess.txt" "$BASE/.htaccess"
fi

#########################################
# metadata
#########################################

app_write_metadata

#########################################
# permissions
#########################################

app_apply_default_permissions
app_apply_rw_permissions \
    "$BASE/assets" \
    "$BASE/backup" \
    "$BASE/cache" \
    "$BASE/images" \
    "$BASE/logs" \
    "$BASE/tmp" \
    "$BASE/user"

#########################################
# apache reload
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

app_print_success_no_db

