#!/bin/bash

###############################################################################
# LAMP Deck app module
# kanboard
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="kanboard"
APP_NAME="Kanboard"
APP_HAS_DB="1"
APP_CATEGORY="Project Management"
APP_ADMIN_PATH=""
APP_ADMIN_LABEL=""
APP_DOWNLOAD_URL="https://github.com/kanboard/kanboard/archive/refs/tags/v1.2.52.tar.gz"

app_prepare_with_db "${1:-}" "${2:-}"

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"
app_init_tmp_dir
app_extract_archive

APP_EXTRACT_ROOT="$(find "$APP_TMP_DIR" -mindepth 1 -maxdepth 1 -type d | head -n 1)"

if [ -z "${APP_EXTRACT_ROOT:-}" ] || [ ! -d "$APP_EXTRACT_ROOT" ]; then
    echo "ERROR: extracted directory not found"
    exit 1
fi

app_copy_files_to_base

cat > "$BASE/config.php" <<EOF
<?php

define('DB_DRIVER', 'mysql');
define('DB_USERNAME', '$DB_USER');
define('DB_PASSWORD', '$DB_PASS');
define('DB_NAME', '$DB_NAME');
define('DB_HOSTNAME', 'localhost');
EOF

cd "$BASE"

php cli db:migrate || true

app_apply_default_permissions

app_apply_rw_permissions \
    "$BASE/data" \
    "$BASE/plugins" \
    "$BASE/files"

app_write_metadata "$APP_SLUG"

app_reload_apache
app_disable_rollback

echo
echo "Default login:"
echo "  User: admin"
echo "  Pass: admin"
echo

app_print_success_with_db
