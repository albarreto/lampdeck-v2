#!/bin/bash

###############################################################################
# LAMP Deck app module
# nextcloud
#
# Description:
# Installs and configures a Nextcloud site inside the LAMP Deck environment.
#
# Usage:
# lampdeck install nextcloud <site-name> [description]
#
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="nextcloud"
APP_NAME="Nextcloud"
APP_CATEGORY="Collaboration"
APP_HAS_DB="1"

APP_ADMIN_PATH="settings/admin"
APP_ADMIN_LABEL="Admin"

APP_DOWNLOAD_URL="https://download.nextcloud.com/server/releases/latest.tar.bz2"

###############################################################################
# SUPPORTED PHP VERSIONS
###############################################################################

NEXTCLOUD_MIN_PHP="8.2"
NEXTCLOUD_MAX_PHP="8.5"

PHP_VERSION="${PHP_RUNTIME_VERSION:-$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')}"

version_ge() {
    [ "$(printf '%s\n' "$2" "$1" | sort -V | head -n1)" = "$2" ]
}

version_le() {
    [ "$(printf '%s\n' "$1" "$2" | sort -V | head -n1)" = "$1" ]
}

if ! version_ge "$PHP_VERSION" "$NEXTCLOUD_MIN_PHP" || \
   ! version_le "$PHP_VERSION" "$NEXTCLOUD_MAX_PHP"; then

    echo
    echo "ERROR: Unsupported PHP version for Nextcloud."
    echo
    echo "Detected PHP version : $PHP_VERSION"
    echo "Supported range      : $NEXTCLOUD_MIN_PHP to $NEXTCLOUD_MAX_PHP"
    echo
    exit 1

fi

###############################################################################
# PREPARE
###############################################################################

app_prepare_with_db "${1:-}" "${2:-}"

###############################################################################
# NEXTCLOUD ADMIN
###############################################################################

read -r -p "Nextcloud admin username [admin]: " NC_ADMIN_USER

NC_ADMIN_USER="${NC_ADMIN_USER:-admin}"

read -r -s -p "Nextcloud admin password: " NC_ADMIN_PASS
echo

if [ -z "${NC_ADMIN_PASS:-}" ]; then
    echo "ERROR: admin password cannot be empty."
    exit 1
fi

###############################################################################
# PACKAGE
###############################################################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"

app_init_tmp_dir

echo "Extracting Nextcloud package..."

tar xjf "$APP_CACHE_FILE" -C "$APP_TMP_DIR"

APP_EXTRACT_ROOT="$APP_TMP_DIR/nextcloud"

if [ ! -d "$APP_EXTRACT_ROOT" ]; then
    echo "ERROR: extracted Nextcloud directory not found"
    exit 1
fi

app_copy_files_to_base

###############################################################################
# DATA DIRECTORY
###############################################################################

mkdir -p "$BASE/data"

###############################################################################
# PERMISSIONS
###############################################################################

app_apply_default_permissions

app_apply_rw_permissions \
    "$BASE/config" \
    "$BASE/custom_apps" \
    "$BASE/data" \
    "$BASE/themes"

###############################################################################
# NEXTCLOUD INSTALL
###############################################################################

SERVER_HOST="${HOSTNAME_FQDN:-$SERVER_IP}"

echo
echo "Installing Nextcloud..."
echo

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" maintenance:install \
    --database mysql \
    --database-name \"$DB_NAME\" \
    --database-user \"$DB_USER\" \
    --database-pass \"$DB_PASS\" \
    --admin-user \"$NC_ADMIN_USER\" \
    --admin-pass \"$NC_ADMIN_PASS\" \
    --data-dir \"$BASE/data\"
"

###############################################################################
# NEXTCLOUD CONFIG
###############################################################################

echo
echo "Configuring Nextcloud..."
echo

# Allow access using configured hostname/FQDN
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set trusted_domains 0 \
    --value=\"$SERVER_HOST\"
"

# Allow access using site alias name
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set trusted_domains 1 \
    --value=\"$SITE\"
"

# Allow access using server IP address
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set trusted_domains 2 \
    --value=\"$SERVER_IP\"
"

# Inform Nextcloud that it is installed under a subdirectory
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set overwritewebroot \
    --value=\"/$SITE\"
"

# Force HTTPS URLs generation
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set overwriteprotocol \
    --value=\"https\"
"

# Set canonical URL used by OCC and background jobs
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set overwrite.cli.url \
    --value=\"https://$SERVER_HOST/$SITE\"
"

# Disable default sample files for new users
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set skeletondirectory \
    --value=\"\"
"

# Disable first-run wizard and welcome content
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" app:disable firstrunwizard
" || true

# Regenerate .htaccess with current configuration
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" maintenance:update:htaccess
"

# Run post-install repairs and mimetype migrations
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" maintenance:repair --include-expensive
" || true

# Schedule heavy maintenance jobs during off-peak hours
# Value is UTC. 5 = 05:00 UTC (~02:00 in UTC-3)
su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set maintenance_window_start \
    --type=integer \
    --value=5
" || true

###############################################################################
# REDIS / APCU
###############################################################################

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set memcache.local \
    --value='\\OC\\Memcache\\APCu'
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set memcache.distributed \
    --value='\\OC\\Memcache\\Redis'
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set memcache.locking \
    --value='\\OC\\Memcache\\Redis'
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set redis host \
    --value='127.0.0.1'
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set redis port \
    --type=integer \
    --value=6379
"

###############################################################################
# APACHE / REWRITE
###############################################################################

## .htaccess será gerado pelo nextcloud

###############################################################################
# PHP TUNING
###############################################################################

for ini in \
    "/etc/php/${PHP_VERSION}/fpm/php.ini" \
    "/etc/php/${PHP_VERSION}/cli/php.ini"
do

    [ -f "$ini" ] || continue

    sed -i 's/^memory_limit = .*/memory_limit = 512M/' "$ini"
    sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 10G/' "$ini"
    sed -i 's/^post_max_size = .*/post_max_size = 10G/' "$ini"
    sed -i 's/^max_execution_time = .*/max_execution_time = 3600/' "$ini"
    sed -i 's/^max_input_time = .*/max_input_time = 3600/' "$ini"

done

###############################################################################
# METADATA
###############################################################################

app_write_metadata "$APP_SLUG"

###############################################################################
# APACHE
###############################################################################

app_reload_apache

systemctl restart "php${PHP_VERSION}-fpm" 2>/dev/null || true

app_disable_rollback

###############################################################################
# OUTPUT
###############################################################################

app_print_success_with_db

echo "NEXTCLOUD ADMIN:"
echo "  USER: $NC_ADMIN_USER"
echo "  PASSWORD: $NC_ADMIN_PASS"
echo
echo "RECOMMENDED:"
echo "  lampdeck create-domain my-cloud.local $SITE"
echo
echo "AFTER CREATING DOMAIN:"
echo "  su -s /bin/sh "$WEB_USER" -c 'php $BASE/occ config:system:set trusted_domains 2 --value=my-cloud.local'"
echo "  su -s /bin/sh "$WEB_USER" -c 'php $BASE/occ config:system:set overwrite.cli.url --value=https://my-cloud.local'"
echo "============================================"
