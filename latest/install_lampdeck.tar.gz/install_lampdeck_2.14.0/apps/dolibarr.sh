#!/bin/bash

###############################################################################
# LAMP Deck app module
# dolibarr
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="dolibarr"
APP_NAME="Dolibarr"
APP_HAS_DB="1"
APP_CATEGORY="Business"
APP_ADMIN_PATH="admin"
APP_ADMIN_LABEL="Admin"

DOLIBARR_BRANCH="23.0.3"
APP_DOWNLOAD_URL="https://github.com/Dolibarr/dolibarr/archive/refs/tags/${DOLIBARR_BRANCH}.tar.gz"

app_prepare_with_db "${1:-}" "${2:-}"

#########################################
# package
#########################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"
app_init_tmp_dir
app_extract_archive

EXTRACTED_DIR="$(find "$APP_TMP_DIR" -mindepth 1 -maxdepth 1 -type d | head -n 1)"

if [ -z "${EXTRACTED_DIR:-}" ]; then
    echo "Error: extracted directory not found"
    exit 1
fi

echo "Copying $APP_NAME files to $BASE..."
rsync -a "$EXTRACTED_DIR/htdocs/" "$BASE/"

#########################################
# documents dir
#########################################

mkdir -p "$BASE/documents"
mkdir -p "$BASE/conf"

cat > "$BASE/documents/.htaccess" <<'EOF'
Require all denied
EOF

touch "$BASE/conf/conf.php"

#########################################
# metadata
#########################################

app_write_metadata

#########################################
# permissions
#########################################

app_apply_default_permissions
app_apply_rw_permissions \
    "$BASE/conf" \
    "$BASE/documents"

#########################################
# apache reload
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

app_print_success_with_db

cat <<EOF
INSTALLER: https://$HOSTNAME_FQDN/$SITE/install/

Dolibarr documents directory:
$BASE/documents

*** VERY IMPORTANT ***
During installation, CHANGE documents directory from:
  ../documents
to:
  $BASE/documents
===========================================

EOF
