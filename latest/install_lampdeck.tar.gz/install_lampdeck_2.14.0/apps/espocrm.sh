#!/bin/bash

###############################################################################
# LAMP Deck app module
# EspoCRM
#
# Description:
# Installs and configures an EspoCRM site inside the LAMP Deck environment.
#
# Usage:
# lampdeck install espocrm <site-name> [description]
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="espocrm"
APP_NAME="EspoCRM"
APP_HAS_DB="1"
APP_CATEGORY="Business"
APP_WEBROOT="public"
APP_ADMIN_PATH=""
APP_ADMIN_LABEL=""
APP_CACHE_FILE="/tmp/espocrm.zip"
APP_DOWNLOAD_URL="http://www.espocrm.com/downloads/EspoCRM-9.3.7.zip"

app_prepare_with_db "${1:-}" "${2:-}"

#########################################
# package
#########################################

validate_command unzip || exit 1

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"

app_init_tmp_dir

echo "Extracting $APP_NAME package..."

unzip -q "$APP_CACHE_FILE" -d "$APP_TMP_DIR/extracted"

EXTRACTED_DIR="$(find "$APP_TMP_DIR/extracted" \
    -mindepth 1 \
    -maxdepth 1 \
    -type d \
    | head -n 1)"

if [ -z "${EXTRACTED_DIR:-}" ]; then
    echo "ERROR: extracted directory not found"
    exit 1
fi

APP_EXTRACT_ROOT="$EXTRACTED_DIR"

app_copy_files_to_base

#########################################
# app config
#########################################

ln -s ../client "$BASE/public/client"

cat > "$BASE/data/config-internal.php" <<EOF
<?php

return [
    'database' => [
        'platform' => 'Mysql',
        'host' => 'localhost',
        'port' => '',
        'dbname' => '$DB_NAME',
        'user' => '$DB_USER',
        'password' => '$DB_PASS',
        'charset' => 'utf8mb4'
    ]
];
EOF

cat > "$BASE/data/config.php" <<EOF
<?php

return [
    'siteUrl' => 'https://' . \$_SERVER['HTTP_HOST'] . '/$SITE',
    'basePath' => '$SITE'
];
EOF

#########################################
# permissions
#########################################

app_apply_default_permissions

app_apply_rw_permissions \
    "$BASE/data" \
    "$BASE/custom" \
    "$BASE/client/custom" \
    "$BASE/data/cache" \
    "$BASE/data/upload" \
    "$BASE/application/Espo/Modules"

#########################################
# metadata
#########################################

app_write_metadata "$APP_SLUG"

#########################################
# apache
#########################################

app_reload_apache
app_disable_rollback

#########################################
# cron
#########################################

CRON_FILE="/etc/cron.d/lampdeck-espocrm-$SITE"

cat > "$CRON_FILE" <<EOF
* * * * * $WEB_USER cd $BASE && php cron.php > /dev/null 2>&1
EOF

chmod 644 "$CRON_FILE"

#########################################
# output
#########################################

app_print_success_with_db

echo "NOTE:"
echo "- Finish installation in the browser"
echo "- EspoCRM installer may ask to confirm database settings"
echo "============================================"
echo
