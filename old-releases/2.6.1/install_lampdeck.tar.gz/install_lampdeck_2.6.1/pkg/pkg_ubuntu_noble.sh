#!/bin/bash

###############################################################################
# LAMP Deck package installer
# Target: Ubuntu 24.04 LTS (Noble)
#
# Description:
#   Installs the package set required by LAMP Deck on Ubuntu 24.04 LTS
#
# Installs:
#   Apache2
#   PHP 8.3 (FPM, native)
#   MariaDB
#   Redis
#   Certbot
#   phpMyAdmin
#
# Project:
#   LAMP Deck
#   https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
#   GPL-3.0-or-later
###############################################################################

set -euo pipefail

PKG_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PKG_SCRIPT_DIR/../lib/pkg_common.sh"

PHP_VERSION="8.3"
PHP_FPM_SOCKET="/run/php/php${PHP_VERSION}-fpm.sock"

install_ubuntu_24_04_packages() {

    export DEBIAN_FRONTEND=noninteractive

    local timezone="${TIMEZONE:-America/Maceio}"
    local hostname_fqdn="${HOSTNAME_FQDN:-server.local}"

    echo "== Updating system"
    apt update
    apt upgrade -y

    echo "== Base packages"
    apt install -y \
        ca-certificates \
        curl \
        wget \
        gnupg \
        lsb-release \
        apt-transport-https \
        unzip \
        zip \
        rsync \
        nano \
        vim \
        htop \
        tar \
        openssl \
        software-properties-common

    echo "== Installing Apache"
    apt install -y apache2 apache2-utils

    a2dismod mpm_prefork 2>/dev/null || true
    a2enmod mpm_event proxy_fcgi setenvif rewrite headers expires ssl http2 deflate alias env dir mime

    systemctl enable apache2

    echo "== Installing PHP ${PHP_VERSION} from Ubuntu native repositories"

    apt install -y \
        php${PHP_VERSION}-fpm \
        php${PHP_VERSION}-cli \
        php${PHP_VERSION}-common \
        php${PHP_VERSION}-mysql \
        php${PHP_VERSION}-curl \
        php${PHP_VERSION}-gd \
        php${PHP_VERSION}-intl \
        php${PHP_VERSION}-mbstring \
        php${PHP_VERSION}-xml \
        php${PHP_VERSION}-zip \
        php${PHP_VERSION}-bcmath \
        php${PHP_VERSION}-soap \
        php${PHP_VERSION}-opcache \
        php${PHP_VERSION}-readline \
        php${PHP_VERSION}-redis

    echo "== Installing optional PHP Imagick"

    if ! apt install -y php${PHP_VERSION}-imagick; then
        echo "WARNING: php-imagick could not be installed. Continuing without Imagick."
    fi

    echo "== Cleaning old PHP-FPM configurations"

    for conf in /etc/apache2/conf-enabled/php*-fpm.conf; do
        [ -e "$conf" ] || continue
        conf_name="$(basename "$conf" .conf)"
        echo "Disabling Apache conf: $conf_name"
        a2disconf "$conf_name" >/dev/null 2>&1 || true
    done

    for svc in /lib/systemd/system/php*-fpm.service; do

        [ -e "$svc" ] || continue

        svc_name=$(basename "$svc" .service)

        # preserve active version
        if [ "$svc_name" = "php${PHP_VERSION}-fpm" ]; then
            continue
        fi

        echo "Stopping service: ${svc_name}.service"

        systemctl stop "${svc_name}.service" >/dev/null 2>&1 || true
        systemctl disable "${svc_name}.service" >/dev/null 2>&1 || true
    done

    a2enconf php${PHP_VERSION}-fpm
    systemctl enable php${PHP_VERSION}-fpm
    systemctl restart php${PHP_VERSION}-fpm

    echo "== Installing Redis"
    apt install -y redis-server
    systemctl enable redis-server

    echo "== Installing Certbot"
    apt install -y certbot python3-certbot-apache

    echo "== Installing MariaDB"
    apt install -y mariadb-server mariadb-client

    systemctl enable mariadb

    if [ -n "${DB_ROOT_PASS:-}" ]; then
        echo "== Configuring MariaDB root password"

        mariadb <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT_PASS}';
FLUSH PRIVILEGES;
EOF
    fi

    for ini in /etc/php/${PHP_VERSION}/fpm/php.ini /etc/php/${PHP_VERSION}/cli/php.ini
    do
        sed -i 's/^memory_limit = .*/memory_limit = 512M/' "$ini"
        sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 256M/' "$ini"
        sed -i 's/^post_max_size = .*/post_max_size = 256M/' "$ini"
        sed -i 's/^max_execution_time = .*/max_execution_time = 300/' "$ini"
        sed -i 's/^max_input_vars = .*/max_input_vars = 5000/' "$ini" || true

        grep -q "^date.timezone" "$ini" \
            && sed -i "s#^date.timezone.*#date.timezone = ${timezone}#" "$ini" \
            || echo "date.timezone = ${timezone}" >> "$ini"
    done

    cat > /etc/php/${PHP_VERSION}/mods-available/opcache.ini <<EOF
zend_extension=opcache.so
opcache.enable=1
opcache.enable_cli=0
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=40000
opcache.validate_timestamps=1
opcache.revalidate_freq=2
opcache.save_comments=1
EOF

    local pool="/etc/php/${PHP_VERSION}/fpm/pool.d/www.conf"

    sed -i 's/^pm = .*/pm = dynamic/' "$pool"
    sed -i 's/^pm.max_children = .*/pm.max_children = 40/' "$pool"
    sed -i 's/^pm.start_servers = .*/pm.start_servers = 4/' "$pool"
    sed -i 's/^pm.min_spare_servers = .*/pm.min_spare_servers = 2/' "$pool"
    sed -i 's/^pm.max_spare_servers = .*/pm.max_spare_servers = 6/' "$pool"
    grep -q '^pm.max_requests' "$pool" || echo 'pm.max_requests = 500' >> "$pool"

    cat > /etc/mysql/mariadb.conf.d/60-wp.cnf <<EOF
[mysqld]

character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

max_connections = 150

innodb_buffer_pool_size = 512M
innodb_log_file_size = 128M
innodb_flush_method = O_DIRECT

table_open_cache = 4000
thread_cache_size = 100

tmp_table_size = 64M
max_heap_table_size = 64M
EOF

    mkdir -p /var/www/html
    mkdir -p /var/www/certs

    echo "== Installing phpMyAdmin"

    echo "phpmyadmin phpmyadmin/dbconfig-install boolean false" | debconf-set-selections
    echo "phpmyadmin phpmyadmin/reconfigure-webserver multiselect apache2" | debconf-set-selections

    apt install -y phpmyadmin

    cat > /etc/apache2/conf-available/phpmyadmin.conf <<EOF
Alias /phpmyadmin /usr/share/phpmyadmin

<Directory /usr/share/phpmyadmin>
    Require all granted
    AllowOverride All
</Directory>
EOF

    a2enconf phpmyadmin >/dev/null 2>&1 || true

    if [ "$DB_ALREADY_INSTALLED" -eq 0 ]; then
        echo "== Configuring phpMyAdmin database"

        if [ -z "${DB_ROOT_PASS:-}" ]; then
            echo "ERROR: DB_ROOT_PASS is required to configure phpMyAdmin."
            exit 1
        fi

        local pma_db="phpmyadmin"
        local pma_user="phpmyadmin"
        local pma_pass="${DB_ROOT_PASS}"

        mariadb -u root -p"${DB_ROOT_PASS}" -e "
        CREATE DATABASE IF NOT EXISTS \`${pma_db}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
        CREATE USER IF NOT EXISTS '${pma_user}'@'localhost' IDENTIFIED BY '${pma_pass}';
        ALTER USER '${pma_user}'@'localhost' IDENTIFIED BY '${pma_pass}';
        GRANT ALL PRIVILEGES ON \`${pma_db}\`.* TO '${pma_user}'@'localhost';
        FLUSH PRIVILEGES;
        "

        if [ -f /usr/share/phpmyadmin/sql/create_tables.sql ]; then
            mariadb -u root -p"${DB_ROOT_PASS}" "${pma_db}" < /usr/share/phpmyadmin/sql/create_tables.sql
        elif [ -f /usr/share/dbconfig-common/data/phpmyadmin/install/mysql ]; then
            mariadb -u root -p"${DB_ROOT_PASS}" "${pma_db}" < /usr/share/dbconfig-common/data/phpmyadmin/install/mysql
        else
            echo "WARNING: phpMyAdmin internal SQL file not found."
        fi

        cat > /etc/phpmyadmin/config-db.php <<EOF
<?php
\$dbserver='localhost';
\$dbport='';
\$dbuser='${pma_user}';
\$dbpass='${pma_pass}';
\$basepath='';
\$dbname='${pma_db}';
\$dbtype='mysqli';
EOF
    fi

    cat > /etc/apache2/conf-available/servername.conf <<EOF
ServerName localhost
EOF

    a2enconf servername >/dev/null 2>&1 || true

    echo "== Checking default self-signed certificate"

    if [ ! -f /var/www/certs/server.crt ] || [ ! -f /var/www/certs/server.key ]; then
        echo "== Generating default self-signed certificate"

        openssl req -x509 -nodes -days 825 \
            -newkey rsa:2048 \
            -keyout /var/www/certs/server.key \
            -out /var/www/certs/server.crt \
            -subj "/C=BR/ST=SE/L=Aracaju/O=Local/CN=$hostname_fqdn"
    else
        echo "== Existing default certificate found. Keeping current files."
    fi

    cat > /etc/apache2/sites-available/000-default.conf <<EOF
<VirtualHost *:80>
    DocumentRoot /var/www/html

    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/\.well-known/acme-challenge/
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
</VirtualHost>
EOF

    cat > /etc/apache2/sites-available/default-ssl.conf <<EOF
<IfModule mod_ssl.c>
<VirtualHost *:443>
    DocumentRoot /var/www/html
    DirectoryIndex index.php index.html

    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch \.php$>
        SetHandler "proxy:unix:${PHP_FPM_SOCKET}|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile /var/www/certs/server.crt
    SSLCertificateKeyFile /var/www/certs/server.key
</VirtualHost>
</IfModule>
EOF

    a2ensite 000-default >/dev/null 2>&1 || true
    a2ensite default-ssl >/dev/null 2>&1 || true

    if [ ! -f /etc/apache2/conf-available/subsites-aliases.conf ]; then
        : > /etc/apache2/conf-available/subsites-aliases.conf
    fi

    a2enconf subsites-aliases >/dev/null 2>&1 || true

    validate_web_user
    chown -R "$WEB_USER:$WEB_GROUP" /var/www

    systemctl restart mariadb
    systemctl restart apache2
    systemctl restart redis-server

    echo
    echo "============================================"
    echo "Ubuntu 24.04 package stack installed."
    echo "============================================"
    echo
}
