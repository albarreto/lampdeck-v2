#!/bin/bash

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")/..}"
source "$LIB_DIR/common.sh"

SERVER_IP="$(get_server_ip)"

SITE="${1:-}"
DESC="${2:-}"

SITE="${SITE#/}"
SITE="${SITE%/}"

if [ -z "$SITE" ]; then
    echo "Usage: lampdeck install wordpress <site-name> [description]"
    exit 1
fi

if [[ ! "$SITE" =~ ^[a-zA-Z0-9._-]+$ ]]; then
    echo "Error: use only letters, numbers, dot, hyphen, and underscore in the site name."
    exit 1
fi

DB_NAME="$SITE"
DB_USER="$SITE"
DB_PASS="$(openssl rand -base64 18 | tr -dc 'a-zA-Z0-9' | head -c16)"
BASE="$WWW_ROOT/$SITE"

echo
echo "============================================"
echo "Installing WordPress: $SITE"
echo "============================================"
echo

read -s -p "Enter MariaDB root password: " DB_ROOT_PASS
echo

echo "Validating database access..."

if ! mysql -u root -p"${DB_ROOT_PASS}" -e "SELECT 1" >/dev/null 2>&1; then
    echo
    echo "ERROR: Cannot authenticate to MariaDB with provided root password."
    echo "Aborting installation."
    exit 1
fi

echo "Database authentication OK"
echo

echo "Creating base website..."

/usr/local/bin/lampdeck create-website "$SITE" "$DESC"

echo
echo "Creating database..."

mysql -u root -p"${DB_ROOT_PASS}" <<EOSQL
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '$DB_USER'@'localhost'
IDENTIFIED BY '$DB_PASS';

ALTER USER '$DB_USER'@'localhost'
IDENTIFIED BY '$DB_PASS';

GRANT ALL PRIVILEGES
ON \`$DB_NAME\`.*
TO '$DB_USER'@'localhost';

FLUSH PRIVILEGES;
EOSQL

unset DB_ROOT_PASS

cd /tmp || exit 1
rm -rf /tmp/wordpress

TMP_TAR="/tmp/wordpress-latest.tar.gz"
DOWNLOAD_WP=1

if [ -f "$TMP_TAR" ] && find "$TMP_TAR" -mtime 0 | grep -q .; then
    DOWNLOAD_WP=0
    echo "Using cached WordPress package (downloaded today)"
fi

if [ "$DOWNLOAD_WP" = "1" ]; then
    echo "Downloading WordPress..."
    cd /tmp || exit 1
    wget --no-use-server-timestamps -O "$TMP_TAR" https://wordpress.org/latest.tar.gz
fi

echo "Extracting WordPress package..."
tar xf "$TMP_TAR"

echo "Copying WordPress files..."
rsync -a --delete /tmp/wordpress/ "$BASE/"

cp "$BASE/wp-config-sample.php" "$BASE/wp-config.php"

sed -i "s|database_name_here|$DB_NAME|g" "$BASE/wp-config.php"
sed -i "s|username_here|$DB_USER|g" "$BASE/wp-config.php"
sed -i "s|password_here|$DB_PASS|g" "$BASE/wp-config.php"
sed -i "s|localhost|127.0.0.1|g" "$BASE/wp-config.php"

cat >> "$BASE/wp-config.php" <<EOCFG

define('WP_HOME', 'https://$SERVER_IP/$SITE');
define('WP_SITEURL', 'https://$SERVER_IP/$SITE');
define('WP_REDIS_HOST', '127.0.0.1');
EOCFG

cat > "$BASE/.htaccess" <<EOHT
RewriteEngine On
RewriteBase /$SITE/
RewriteRule ^index\.php$ - [L]

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /$SITE/index.php [L]
EOHT

if [ -n "$DESC" ]; then
    echo "$DESC" > "$BASE/.siteinfo"
fi

echo "wordpress" > "$BASE/.app-type"

chown -R www-data:www-data "$BASE"
find "$BASE" -type d -exec chmod 755 {} \;
find "$BASE" -type f -exec chmod 644 {} \;
chmod -R 775 "$BASE/wp-content"

apache2ctl configtest >/dev/null
systemctl reload apache2

echo
echo "=============================================="
echo "WORDPRESS WEBSITE CREATED"
echo "URL: https://$SERVER_IP/$SITE/"
echo "DB NAME: $DB_NAME"
echo "DB USER: $DB_USER"
echo "PASSWORD: $DB_PASS"
echo
echo "NOTE: Finish installation in the browser"
echo "============================================="
