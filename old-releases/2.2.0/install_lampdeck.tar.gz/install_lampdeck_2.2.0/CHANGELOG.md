# Changelog

## 2.2.0 - 2026-04-14
- Modular app architecture introduced
- WordPress installer moved to apps/wordpress.sh
- New install syntax:
  lampdeck install wordpress <site> [description]
- Improved frontpage app detection logic using .app-type markers
- Removed redundant create-wp command
- WordPress installer now:
  - validates MariaDB root password before creating site
  - uses cached download if package was fetched the same day
  - provides clearer install progress output
- Improved internal script organization
- Prepared structure for additional apps (Joomla, Drupal, Grav)

## 2.1.5 - 2026-04-14
- Frontpage is always preserved when accessing the server by IP
- Domains no longer override the main frontpage
- Improved multisite behavior
- Prevents modification when website folder already exists
- More reliable domain creation
- Improved default website template (light layout)
- Version command now shows Apache, PHP, MariaDB and Redis versions

## 2.1.4 - 2026-04-13
- Fixed installation phpmyadmin in upgrades
- Fixed logo size in Frontpage
- Fixed phpmyadmin installation
- Fixed installation PHP8.4 packages for ubuntu releases

## 2.1.0 - 2026-04-12
- Support for Ubuntu 20.04 LTS (Jammy), 24.04 LTS (Noble)
- Support for Alpine 3.x

## 2.0.0 - 2026-04-11
- Initial release
