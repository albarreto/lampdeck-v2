# LAMP Deck

Lightweight multisite manager for LAMP servers.

**LAMP Deck** installs and manages a complete LAMP environment with a simple dashboard and CLI helpers for fast website deployment.

Focused on simplicity, reproducibility and low resource usage.

<p align="center">
  <img src="https://raw.githubusercontent.com/albarreto/lampdeck-v2/main/screenshots/frontpage.png" width="900">
</p>


## Stack

- Apache2 (event MPM)
- PHP 8 (FPM)
- MariaDB
- Redis
- phpMyAdmin


## Features

### Core

- One-command installation
- Multisite structure in `/var/www`
- Automatic website listing
- Lightweight dashboard
- Minimal resource usage
- Predictable directory structure
- Modular architecture for app installers


### Site management

- Fast creation of HTML websites
- Automatic CMS installation
  - WordPress
  - Joomla
- Automatic database creation for supported apps
- Optional site description via `.siteinfo`
- Automatic detection of site type:
  - HTML
  - WordPress
  - Joomla
- Direct admin links in dashboard
  - WP-Admin
  - Joomla Administrator
- Optional domain association
- Optional SSL via Let's Encrypt
- Safe validation of site names
- Prevents overwrite of existing sites


### CLI helpers

Examples:

```bash
lampdeck create-website mysite "Example description"

lampdeck install wordpress blog "Company blog"

lampdeck install joomla portal "Company portal"

lampdeck create-domain site1.com site1

lampdeck activate-ssl site1.com
