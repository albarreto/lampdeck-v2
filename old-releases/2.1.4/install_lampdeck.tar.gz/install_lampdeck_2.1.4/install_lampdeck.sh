#!/bin/bash
#
###############################################################################
#
# LAMP Deck Installer
#
# Project: https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# Description
# -----------------------------------------------------------------------------
# Automated installer for a modern LAMP stack optimized for multi-site hosting.
#
# This script installs and configures:
#
#   • Apache 2.4 (event MPM)
#   • PHP-FPM (8.4+)
#   • MariaDB 10.x
#   • Redis
#   • phpMyAdmin
#   • Certbot (Let's Encrypt)
#
# It also deploys a lightweight management interface that allows:
#
#   • creation of isolated websites under /var/www
#   • automatic Apache alias configuration
#   • rapid WordPress deployment with database creation
#   • optional domain configuration with HTTPS
#   • centralized overview of hosted sites
#
#
# Features
# -----------------------------------------------------------------------------
#   • Multi-site structure using Apache Alias
#   • WordPress-ready PHP tuning
#   • Redis object cache support
#   • automatic database provisioning
#   • self-signed SSL by default
#   • Let's Encrypt integration
#   • clean and minimal web interface
#   • helper CLI tools:
#
#       create-website   create basic site
#       create-wp        create WordPress instance
#       create-domain    attach domain to site
#       activate-ssl     generate valid certificate
#       lamp-version     show stack versions
#
#
# License
# -----------------------------------------------------------------------------
# GNU General Public License v3.0
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License,
# or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See the GNU General Public License for more details:
#
###############################################################################

set -euo pipefail


###############################################################################
# LAMP Deck Installer
###############################################################################

APP_NAME="LAMP Deck"
APP_VERSION="2.1.4"

SERVER_IP="$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')"
SERVER_IP="${SERVER_IP:-127.0.0.1}"

LIB_DIR="/usr/lib/lampdeck"
BIN_DIR="/usr/local/bin"

echo
echo "============================================"
echo "$APP_NAME v$APP_VERSION INSTALLATION"
echo "============================================"
echo
echo "This installer will configure the LAMP Deck environment."
echo "Required components will be installed and configured automatically."
echo

if [ -d /var/lib/mysql/mysql ]; then
    DB_ALREADY_INSTALLED=1
else
    DB_ALREADY_INSTALLED=0
fi

if [ "$DB_ALREADY_INSTALLED" -eq 0 ]; then
    echo
    echo "============================================"
    echo "LAMP DECK INSTALLATION"
    echo "============================================"
    echo
    echo "Database configuration is required."
    echo

    while true; do
        read -s -p "Enter MariaDB root password: " DB_ROOT_PASS
        echo
        read -s -p "Confirm MariaDB root password: " DB_ROOT_PASS_CONFIRM
        echo

        if [ "$DB_ROOT_PASS" != "$DB_ROOT_PASS_CONFIRM" ]; then
            echo "Passwords do not match. Try again."
            echo
            continue
        fi

        if [ -z "$DB_ROOT_PASS" ]; then
            echo "Password cannot be empty."
            echo
            continue
        fi

        break
    done

    export DB_ROOT_PASS
else
    echo
    echo "Existing MariaDB installation detected."
    echo "Keeping current MariaDB root configuration."
    echo
fi

###############################################################################
# Packages Installer
###############################################################################

echo "== Detecting Linux distribution"

if [ ! -r /etc/os-release ]; then
    echo "Error: cannot detect Linux distribution."
    exit 1
fi

. /etc/os-release

DIST_ID="${ID:-unknown}"
DIST_VERSION_ID="${VERSION_ID:-unknown}"
DIST_CODENAME="${VERSION_CODENAME:-unknown}"

echo "Detected:"
echo "  ID=$DIST_ID"
echo "  VERSION_ID=$DIST_VERSION_ID"
echo "  VERSION_CODENAME=$DIST_CODENAME"
echo

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

case "$DIST_ID:$DIST_VERSION_ID:$DIST_CODENAME" in

    #########################################################
    # DEBIAN
    #########################################################

    debian:12:*|debian:*:bookworm)
        source "$SCRIPT_DIR/pkg/pkg_debian_bookworm.sh"
        install_debian_bookworm_packages
        ;;

    debian:13:*|debian:*:trixie)
        source "$SCRIPT_DIR/pkg/pkg_debian_trixie.sh"
        install_debian_trixie_packages
        ;;

    #########################################################
    # UBUNTU
    #########################################################

    ubuntu:22.04:*|ubuntu:*:jammy)
        source "$SCRIPT_DIR/pkg/pkg_ubuntu_jammy.sh"
        install_ubuntu_22_04_packages
        ;;

    ubuntu:24.04:*|ubuntu:*:noble)
        source "$SCRIPT_DIR/pkg/pkg_ubuntu_noble.sh"
        install_ubuntu_24_04_packages
        ;;

    #########################################################
    # ALPINE
    #########################################################

    alpine:*:*)
        source "$SCRIPT_DIR/pkg/pkg_alpine_3.sh"
        install_alpine_packages
        ;;

    #########################################################
    # DEFAULT
    #########################################################

    *)
        echo "Error: unsupported distribution/version."
        echo
        echo "Supported:"
        echo "  Alpine 3.19+"
        echo "  Debian 12 (bookworm)"
        echo "  Debian 13 (trixie)"
        echo "  Ubuntu 22.04 (jammy)"
        echo "  Ubuntu 24.04 (noble)"
        echo
        exit 1
        ;;

esac

#########################################################
# COMMON
#########################################################

mkdir -p "$LIB_DIR"
cat > "$LIB_DIR/common.sh" <<EOF
#!/bin/bash

APP_NAME="${APP_NAME}"
APP_VERSION="${APP_VERSION}"
WWW_ROOT="/var/www"
CERT_DIR="/var/www/certs"
APACHE_SITES_AVAILABLE="/etc/apache2/sites-available"
APACHE_SITES_ENABLED="/etc/apache2/sites-enabled"
APACHE_CONF_AVAILABLE="/etc/apache2/conf-available"
SUBSITES_CONF="/etc/apache2/conf-available/subsites-aliases.conf"

get_server_ip() {
    local ip
    ip="\$(ip route get 1.1.1.1 2>/dev/null | awk '{print \$7; exit}')"
    echo "\${ip:-127.0.0.1}"
}
EOF

chmod +x "$LIB_DIR/common.sh"

#########################################################
# MAIN CLI
#########################################################

cat > "$BIN_DIR/lampdeck" <<EOF
#!/bin/bash

###############################################################################
# ${APP_NAME} - main CLI
# Description: Central command line interface for ${APP_NAME}
#
# Project: https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR}"

run_module() {
    local module="\$1"
    shift || true

    local target="\$LIB_DIR/\$module"

    if [ ! -f "\$target" ]; then
        echo "Error: module not found: \$target"
        exit 1
    fi

    if [ ! -x "\$target" ]; then
        chmod +x "\$target" 2>/dev/null || true
    fi

    exec "\$target" "\$@"
}

if [ ! -d "\$LIB_DIR" ]; then
    echo "Error: auxiliary directory not found: \$LIB_DIR"
    echo "LAMP Deck is not correctly installed."
    exit 1
fi

CMD="\${1:-}"

case "\$CMD" in
    create-website)
        shift
        run_module "create-website.sh" "\$@"
        ;;

    create-wp)
        shift
        run_module "create-wp.sh" "\$@"
        ;;

    create-domain)
        shift
        run_module "create-domain.sh" "\$@"
        ;;

    activate-ssl)
        shift
        run_module "activate-ssl.sh" "\$@"
        ;;

    sites)
        shift
        run_module "sites.sh" "\$@"
        ;;

    version)
        shift
        run_module "version.sh" "\$@"
        ;;

    --help|-h|help|"")
        shift || true
        run_module "help.sh" "\$@"
        ;;

    *)
        echo "Unknown command: \$CMD"
        echo
        run_module "help.sh"
        exit 1
        ;;
esac
EOF

chmod +x "$BIN_DIR/lampdeck"

#########################################################
# MODULE: help
#########################################################

cat > /usr/lib/lampdeck/help.sh <<EOF
#!/bin/bash

###############################################################################
# ${APP_NAME} module
# help
#
# Description:
# Displays command usage information
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# GPL-3.0-or-later
###############################################################################

cat <<HELP

${APP_NAME} v${APP_VERSION}
Multisite manager for LAMP servers

USAGE
  lampdeck <command> [options]

ALSO
  lampdeck help
  lampdeck -h
  lampdeck --help

COMMANDS

  create-website <site> [description]
      Create a basic HTML website in /var/www/<site>

  create-wp <site> [description]
      Create a full WordPress installation

  create-domain <domain> <site>
      Configure Apache vhost for an existing site

  activate-ssl <domain>
      Enable Let's Encrypt SSL certificate

  sites
      List installed sites

  version (or -h --help)
      Show installed version

EXAMPLES

  lampdeck create-website portal "Internal system"
  lampdeck create-wp blog "Corporate website"
  lampdeck create-domain blog.example.com blog
  lampdeck activate-ssl blog.example.com

PROJECT
  https://github.com/albarreto/lampdeck-v2

HELP

EOF

chmod +x /usr/lib/lampdeck/help.sh

#########################################################
# MODULE: version
#########################################################

cat > "$LIB_DIR/version.sh" <<'EOF'
#!/bin/bash

set -euo pipefail
source /usr/lib/lampdeck/common.sh

echo "${APP_NAME} v${APP_VERSION}"
EOF

chmod +x "$LIB_DIR/version.sh"

#########################################################
# MODULE: sites
#########################################################

cat > "$LIB_DIR/sites.sh" <<'EOF'
#!/bin/bash

set -euo pipefail
source /usr/lib/lampdeck/common.sh

SERVER_IP="$(get_server_ip)"

if [ ! -d "$WWW_ROOT" ]; then
    echo "Error: $WWW_ROOT not found."
    exit 1
fi

site_type() {
    local base="$1"

    if [ -f "$base/wp-config.php" ] || [ -d "$base/wp-admin" ]; then
        echo "wordpress"
    else
        echo "html"
    fi
}

site_desc() {
    local base="$1"
    local info="$base/.siteinfo"

    if [ -f "$info" ]; then
        tr '\n' ' ' < "$info" | sed 's/[[:space:]]\+/ /g; s/^ //; s/ $//'
    else
        echo ""
    fi
}

site_domain() {
    local base="$1"
    local result=""

    result=$(
        grep -Ril "DocumentRoot[[:space:]]\+$base" "$APACHE_SITES_AVAILABLE" 2>/dev/null \
        | while read -r conf; do
            awk '/^[[:space:]]*ServerName[[:space:]]+/ { print $2; exit }' "$conf"
          done \
        | head -n 1
    )

    echo "${result:-}"
}

site_url() {
    local site="$1"
    local domain="$2"

    if [ -n "$domain" ]; then
        echo "https://$domain"
    else
        echo "https://$SERVER_IP/$site/"
    fi
}

print_header() {
    printf "%-22s %-10s %-35s %-28s %-50s\n" \
        "SITE" "TYPE" "URL" "DOMAIN" "DESCRIPTION"

    printf "%-22s %-10s %-35s %-28s %-50s\n" \
        "----------------------" \
        "----------" \
        "-----------------------------------" \
        "----------------------------" \
        "--------------------------------------------------"
}

FOUND=0
print_header

for base in "$WWW_ROOT"/*; do
    [ -d "$base" ] || continue

    site="$(basename "$base")"

    case "$site" in
        html|certs)
            continue
            ;;
    esac

    FOUND=1

    type="$(site_type "$base")"
    domain="$(site_domain "$base")"
    url="$(site_url "$site" "$domain")"
    desc="$(site_desc "$base")"

    printf "%-22s %-10s %-35s %-28s %-50s\n" \
        "$site" \
        "$type" \
        "$url" \
        "${domain:--}" \
        "$desc"
done

if [ "$FOUND" -eq 0 ]; then
    echo "No websites found in $WWW_ROOT."
fi
EOF

chmod +x "$LIB_DIR/sites.sh"

#########################################################
# MODULE: create-website
#########################################################

cat > "$LIB_DIR/create-website.sh" <<'EOF'
#!/bin/bash

###############################################################################
# ${APP_NAME} module
# create-website
#
# Description:
# Creates a new basic website
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail
source /usr/lib/lampdeck/common.sh

SERVER_IP="$(get_server_ip)"
SITE="${1:-}"
DESC="${2:-}"

SITE="${SITE#/}"
SITE="${SITE%/}"
CREATED_AT="$(date '+%d/%m/%Y às %H:%M:%S')"

if [ -z "$SITE" ]; then
    echo "How to Use: lampdeck create-website <site-name> [description]"
    exit 1
fi

if [[ ! "$SITE" =~ ^[a-zA-Z0-9._-]+$ ]]; then
    echo "Error: use only letters, numbers, dot, hyphen, and underscore in the site name."
    exit 1
fi

BASE="$WWW_ROOT/$SITE"

if [ ! -f "$SUBSITES_CONF" ]; then
    touch "$SUBSITES_CONF"
fi

if [ "${CREATE_WEBSITE_SKIP_CHECK:-0}" != "1" ]; then
    if compgen -G "$BASE/*.php" > /dev/null \
       || [ -f "$BASE/index.php" ] \
       || [ -f "$BASE/index.html" ]; then

        echo
        echo "WARNING:"
        echo "Files already exist in:"
        echo "  $BASE"
        echo
        echo "Existing files:"
        ls -1 "$BASE" 2>/dev/null | grep -E '\.php$|index\.html$' || true
        echo
        echo "This action may overwrite existing content and CANNOT be undone."
        echo

        read -r -p "Do you want to continue? (y/N): " CONFIRM

        case "$CONFIRM" in
            y|Y) ;;
            *)
                echo "Operation cancelled."
                exit 1
                ;;
        esac
    fi
fi

mkdir -p "$BASE"

if ! grep -q "Alias /$SITE/" "$SUBSITES_CONF" 2>/dev/null; then
    cat >> "$SUBSITES_CONF" <<EOT

RedirectMatch 302 ^/$SITE$ /$SITE/

Alias /$SITE/ $BASE/

<Directory $BASE/>
    AllowOverride All
    Require all granted
    DirectoryIndex index.php index.html
</Directory>

EOT
fi

if [ ! -f "$BASE/index.php" ] && [ ! -f "$BASE/index.html" ]; then
    cat > "$BASE/index.php" <<EOPHP
    <?php
    \$site = '__SITE__';
    \$desc = '__DESC__';
    \$createdAt = '__DATA__';
    \$lampVersion = '__VERSAO__';

    function h(\$v){
        return htmlspecialchars((string)\$v, ENT_QUOTES, 'UTF-8');
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>

    <meta charset="UTF-8">

    <title><?=h(\$site)?> | LAMP Deck</title>

    <style>

    body{
    font-family:Arial;
    background:#f6f8fb;
    margin:0;
    padding:40px;
    }

    .box{
    max-width:780px;
    margin:auto;
    background:white;
    border-radius:14px;
    padding:28px;
    box-shadow:0 10px 30px rgba(0,0,0,.08);
    }

    h1{
    margin-top:0;
    }

    .meta{
    color:#555;
    margin-top:8px;
    }

    .desc{
    margin-top:20px;
    padding:14px;
    background:#f1f5f9;
    border-radius:8px;
    }

    .footer{
    margin-top:30px;
    font-size:12px;
    color:#777;
    text-align:center;
    }

    </style>

    </head>

    <body>

    <div class="box">

    <h1><?=h(\$site)?></h1>

    <?php if(trim(\$desc)!==''): ?>

        <div class="desc">
        <?=nl2br(h(\$desc))?>
        </div>

    <?php endif; ?>

    <br/>
    <div class="meta">
        Creation Date: <?=h(\$createdAt)?>
    </div>

    <div class="footer">
        Generated by LAMP Deck v<?=h(\$lampVersion)?>
    </div>

    </div>

    </body>
    </html>
EOPHP
fi

sed -i "s|__SITE__|$SITE|g" "$BASE/index.php"
sed -i "s|__DESC__|$DESC|g" "$BASE/index.php"
sed -i "s|__DATA__|$CREATED_AT|g" "$BASE/index.php"
sed -i "s|__WWW_ROOT__|$WWW_ROOT|g" "$BASE/index.php"
sed -i "s|__VERSAO__|$APP_VERSION|g" "$BASE/index.php"

if [ -n "$DESC" ]; then
    echo "$DESC" > "$BASE/.siteinfo"
fi

chown -R www-data:www-data "$BASE"
systemctl reload apache2

echo
echo "============================================"
echo "SIMPLE WEBSITE CREATED"
echo "URL: https://$SERVER_IP/$SITE/"
echo "============================================"
echo
EOF

#########################################################
# MODULE: create-wp
#########################################################

cat > "$LIB_DIR/create-wp.sh" <<'EOF'
#!/bin/bash

###############################################################################
# LAMP Deck module
# create-wp
#
# Description:
# Creates a new WordPress website including database
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail
source /usr/lib/lampdeck/common.sh

SERVER_IP="$(get_server_ip)"

SITE="${1:-}"
DESC="${2:-}"

SITE="${SITE#/}"
SITE="${SITE%/}"

if [ -z "$SITE" ]; then
    echo "How to Use: lampdeck create-wp <site-name> [description]"
    exit 1
fi

if [[ ! "$SITE" =~ ^[a-zA-Z0-9._-]+$ ]]; then
    echo "Error: use only letters, numbers, dot, hyphen, and underscore in the site name."
    exit 1
fi

DB_NAME="$SITE"
DB_USER="$SITE"
DB_PASS="$(openssl rand -base64 18 | tr -dc 'a-zA-Z0-9' | head -c16)"
BASE="$WWW_ROOT/$SITE"

if [ -f "$BASE/wp-config.php" ] \
   || [ -d "$BASE/wp-admin" ] \
   || [ -d "$BASE/wp-content" ] \
   || [ -d "$BASE/wp-includes" ]; then

    echo
    echo "*** WARNING ***"
    echo "An existing WordPress installation was detected in:"
    echo "  $BASE"
    echo
    echo "This action will overwrite the existing WordPress installation."
    echo "This operation CANNOT be undone."
    echo

    read -r -p "Do you want to continue? (y/N): " CONFIRM

    case "$CONFIRM" in
        y|Y) ;;
        *)
            echo "Operation cancelled."
            exit 1
            ;;
    esac
fi

echo
echo "== Creating DB, if not exists"
read -s -p "Enter MariaDB root password: " DB_ROOT_PASS
echo

#=== SQL
mysql -u root -p"${DB_ROOT_PASS}" <<EOSQL
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '$DB_USER'@'localhost'
IDENTIFIED BY '$DB_PASS';

ALTER USER '$DB_USER'@'localhost'
IDENTIFIED BY '$DB_PASS';

GRANT ALL PRIVILEGES
ON \`$DB_NAME\`.*
TO '$DB_USER'@'localhost';

FLUSH PRIVILEGES;
EOSQL

unset DB_ROOT_PASS

CREATE_WEBSITE_SKIP_CHECK=1 /usr/local/bin/lampdeck create-website "$SITE" "$DESC"

TMP_TAR="/tmp/wordpress-latest.tar.gz"
DOWNLOAD_WP=1

if [ -f "$TMP_TAR" ] && find "$TMP_TAR" -mtime 0 | grep -q .; then
    DOWNLOAD_WP=0
    echo "Using cached WordPress package (downloaded today)"
fi

if [ "$DOWNLOAD_WP" = "1" ]; then
    echo "Downloading WordPress..."
    cd /tmp || exit 1
    wget --no-use-server-timestamps -O "$TMP_TAR" https://wordpress.org/latest.tar.gz
fi

cd /tmp || exit 1
rm -rf /tmp/wordpress
tar xf "$TMP_TAR"


echo "== Copying WordPress to folder"
rsync -a --delete /tmp/wordpress/ "$BASE/"

cp "$BASE/wp-config-sample.php" "$BASE/wp-config.php"

sed -i "s|database_name_here|$DB_NAME|g" "$BASE/wp-config.php"
sed -i "s|username_here|$DB_USER|g" "$BASE/wp-config.php"
sed -i "s|password_here|$DB_PASS|g" "$BASE/wp-config.php"
sed -i "s|localhost|127.0.0.1|g" "$BASE/wp-config.php"

cat >> "$BASE/wp-config.php" <<EOCFG

define('WP_HOME', 'https://$SERVER_IP/$SITE');
define('WP_SITEURL', 'https://$SERVER_IP/$SITE');
define('WP_REDIS_HOST', '127.0.0.1');
EOCFG

cat > "$BASE/.htaccess" <<EOHT
RewriteEngine On
RewriteBase /$SITE/
RewriteRule ^index\.php$ - [L]

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /$SITE/index.php [L]
EOHT

if [ -n "$DESC" ]; then
    echo "$DESC" > "$BASE/.siteinfo"
fi

chown -R www-data:www-data "$BASE"
find "$BASE" -type d -exec chmod 755 {} \;
find "$BASE" -type f -exec chmod 644 {} \;
chmod -R 775 "$BASE/wp-content"

apache2ctl configtest >/dev/null
systemctl reload apache2

echo
echo "=============================================="
echo "WORDPRESS WEBSITE CREATED"
echo "URL: https://$SERVER_IP/$SITE/"
echo "DB NAME: $DB_NAME"
echo "DB USER: $DB_USER"
echo "PASSWORD: $DB_PASS"
echo
echo "NOTE: Finish installation in the browser"
echo "============================================="
EOF

chmod +x "$LIB_DIR/create-wp.sh"

#########################################################
# MODULE: create-domain
#########################################################

cat > "$LIB_DIR/create-domain.sh" <<'EOF'
#!/bin/bash

###############################################################################
# ${APP_NAME} module
# create-domain
#
# Description:
# Creates a new domain for an existing site
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail
source /usr/lib/lampdeck/common.sh

if [ $# -lt 2 ]; then
    echo "How to Use: lampdeck create-domain <domain> <folder>"
    echo "e.g. lampdeck create-domain acme.com acme"
    exit 1
fi

DOMAIN="$1"
SITE="$2"
BASE="$WWW_ROOT/$SITE"
CONF="$APACHE_SITES_AVAILABLE/$DOMAIN.conf"

if [ ! -d "\$BASE" ]; then
    echo "Error: folder \$BASE does not exist."
    exit 1
fi

cat > "\$CONF" <<EOVHOST
<VirtualHost *:80>
    ServerName \$DOMAIN
    ServerAlias www.\$DOMAIN

    DocumentRoot \$BASE
    DirectoryIndex index.php index.html

    <Directory \$BASE>
        AllowOverride All
        Require all granted
        Options FollowSymLinks
    </Directory>

    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/\.well-known/acme-challenge/
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]

    ErrorLog \${APACHE_LOG_DIR}/\${DOMAIN}-error.log
    CustomLog \${APACHE_LOG_DIR}/\${DOMAIN}-access.log combined
</VirtualHost>

<IfModule mod_ssl.c>
<VirtualHost *:443>
    ServerName \$DOMAIN
    ServerAlias www.\$DOMAIN

    Protocols h2 http/1.1
    DocumentRoot \$BASE
    DirectoryIndex index.php index.html

    <Directory \$BASE>
        AllowOverride All
        Require all granted
        Options FollowSymLinks
    </Directory>

    <FilesMatch \\.php$>
        SetHandler "proxy:unix:/run/php/php8.4-fpm.sock|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile \$CERT_DIR/server.crt
    SSLCertificateKeyFile \$CERT_DIR/server.key

    ErrorLog \${APACHE_LOG_DIR}/\${DOMAIN}-ssl-error.log
    CustomLog \${APACHE_LOG_DIR}/\${DOMAIN}-ssl-access.log combined
</VirtualHost>
</IfModule>
EOVHOST

a2ensite "\$DOMAIN.conf" >/dev/null
apache2ctl configtest >/dev/null
systemctl reload apache2

echo
echo "Domain created successfully:"
echo "  Domain: \$DOMAIN"
echo "  Folder: \$BASE"
echo
echo "Access:"
echo "  https://\$DOMAIN"
echo "*** IMPORTANT: DON'T FORGET TO configure DNS or local hosts file!"
echo
echo "Then issue a genuine SSL certificate with:"
echo "  lampdeck activate-ssl \$DOMAIN"
EOF

chmod +x "$LIB_DIR/create-domain.sh"

#########################################################
# MODULE: activate-ssl
#########################################################

cat > "$LIB_DIR/activate-ssl.sh" <<'EOF'
#!/bin/bash

set -euo pipefail
source /usr/lib/lampdeck/common.sh

DOMAIN="${1:-}"

if [ -z "$DOMAIN" ]; then
    echo "How to Use: lampdeck activate-ssl domain.com"
    exit 1
fi

certbot --apache -d "$DOMAIN"
EOF

chmod +x "$LIB_DIR/activate-ssl.sh"


############################################
# Install assets images
############################################

echo "== Creating assets"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

ICONS_SRC="$SCRIPT_DIR/assets/icons"
IMAGES_SRC="$SCRIPT_DIR/assets/images"

ICONS_DST="/var/www/html/assets/icons"
IMAGES_DST="/var/www/html/assets/images"

mkdir -p "$ICONS_DST"
mkdir -p "$IMAGES_DST"

if [ -d "$ICONS_SRC" ]; then
    cp "$ICONS_SRC"/*.webp "$ICONS_DST"/ 2>/dev/null || true
    echo "Icons installed."
else
    echo "WARNING: assets/icons folder not found."
fi

if [ -d "$IMAGES_SRC" ]; then
    cp "$IMAGES_SRC"/*.webp "$IMAGES_DST"/ 2>/dev/null || true
    echo "Images installed."
else
    echo "WARNING: assets/images folder not found."
fi

if [ -d /var/www/html/assets ]; then
    chown -R www-data:www-data /var/www/html/assets
    find /var/www/html/assets -type d -exec chmod 755 {} \;
    find /var/www/html/assets -type f -exec chmod 644 {} \;
fi


#########################################################
# FRONTPAGE
#########################################################

mkdir -p /var/www/html

cat > /var/www/html/index.php <<'EOF'
<?php
/*
===============================================================================
 LAMP Deck v2.x
 ------------------------------------------------------------------------------
 Author: Aurélio Barreto
 E-mail: aurelio@aureliobarreto.com
 Project: https://github.com/albarreto/lampdeck-v2

 Copyright (C) 2026 Aurélio Barreto

 License
 -----------------------------------------------------------------------------
 GNU General Public License v3.0

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License,
 or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 See the GNU General Public License for more details:
 https://www.gnu.org/licenses/gpl-3.0.en.html
===============================================================================
*/

$dirs = array_filter(
    scandir('/var/www'),
    function ($d) {
        if (!isset($d[0]) || $d[0] === '.') {
            return false;
        }

        if (in_array($d, ['html', 'certs'])) {
            return false;
        }

        return is_dir('/var/www/' . $d);
    }
);

sort($dirs);

$serverName = $_SERVER['HTTP_HOST'] ?? 'Servidor';
$totalSites = count($dirs);

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function site_desc($site) {
    $file = "/var/www/$site/.siteinfo";
    if (is_file($file) && is_readable($file)) {
        $txt = trim((string)file_get_contents($file));
        if ($txt !== '') {
            return $txt;
        }
    }
    return '';
}

function is_wordpress_site($site) {
    $base = "/var/www/$site";

    return is_file("$base/wp-config.php")
        || is_dir("$base/wp-admin")
        || is_dir("$base/wp-content");
}

function site_icon($site) {
    return is_wordpress_site($site)
        ? '/assets/icons/icon-wordpress.webp'
        : '/assets/icons/icon-html.webp';
}

function site_type_label($site) {
    return is_wordpress_site($site)
        ? 'WordPress site'
        : 'HTML site';
}

function cmd($command) {
    $out = @shell_exec($command . ' 2>/dev/null');
    return is_string($out) ? trim($out) : '';
}

function format_bytes($bytes) {
    $bytes = (float)$bytes;
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;

    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }

    return number_format($bytes, ($i >= 2 ? 1 : 0), ',', '.') . ' ' . $units[$i];
}

function get_meminfo() {
    $data = @file('/proc/meminfo', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $mem = [];

    if ($data) {
        foreach ($data as $line) {
            if (preg_match('/^([A-Za-z_]+):\s+(\d+)/', $line, $m)) {
                $mem[$m[1]] = (int)$m[2] * 1024;
            }
        }
    }

    $total = $mem['MemTotal'] ?? 0;
    $available = $mem['MemAvailable'] ?? ($mem['MemFree'] ?? 0);
    $used = max(0, $total - $available);

    return [
        'total'   => $total,
        'used'    => $used,
        'free'    => $available,
        'percent' => $total > 0 ? round(($used / $total) * 100) : 0
    ];
}

function get_diskinfo($path = '/') {
    $total = @disk_total_space($path) ?: 0;
    $free  = @disk_free_space($path) ?: 0;
    $used  = max(0, $total - $free);

    return [
        'total'   => $total,
        'used'    => $used,
        'free'    => $free,
        'percent' => $total > 0 ? round(($used / $total) * 100) : 0
    ];
}

function service_status($service) {
    $status = cmd('systemctl is-active ' . escapeshellarg($service));
    return $status !== '' ? $status : 'unknown';
}

function status_class($status) {
    switch ($status) {
        case 'active':
            return 'ok';
        case 'inactive':
        case 'failed':
            return 'bad';
        default:
            return 'warn';
    }
}

function normalize_version($service, $version) {
    $version = trim((string)$version);

    if ($version === '') {
        return '';
    }

    switch ($service) {
        case 'mariadb':
            if (preg_match('/([0-9]+\.[0-9]+\.[0-9]+)/', $version, $m)) {
                return $m[1];
            }
            return rtrim(str_replace('MariaDB', '', $version), ' ,');

        default:
            return rtrim($version, ' ,');
    }
}

function service_version($service) {
    switch ($service) {
        case 'apache2':
            $v = cmd("apache2 -v | awk -F'/' '/Server version/ {print \$2}' | awk '{print \$1}'");
            return normalize_version($service, $v);

        case 'php8.4-fpm':
            return normalize_version($service, PHP_VERSION);

        case 'redis-server':
            $v = cmd("redis-server --version | awk '{for(i=1;i<=NF;i++) if(\$i ~ /^v=/){sub(/^v=/,\"\",\$i); print \$i}}'");
            return normalize_version($service, $v);

        case 'mariadb':
            $v = cmd("mariadb --version");
            return normalize_version($service, $v);

        default:
            return '';
    }
}

$memInfo  = get_meminfo();
$diskInfo = get_diskinfo('/');

$services = [
    ['label' => 'Apache',  'unit' => 'apache2'],
    ['label' => 'PHP',     'unit' => 'php8.4-fpm'],
    ['label' => 'Redis',   'unit' => 'redis-server'],
    ['label' => 'MariaDB', 'unit' => 'mariadb']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LAMP Deck v__VERSAO__</title>
    <style>
        :root {
            --bg: #0f172a;
            --card: rgba(255,255,255,0.06);
            --card-2: rgba(255,255,255,0.04);
            --border: rgba(255,255,255,0.10);
            --text: #e5e7eb;
            --muted: #94a3b8;
            --primary: #38bdf8;
            --shadow: 0 20px 50px rgba(0,0,0,0.35);
            --ok: #22c55e;
            --bad: #ef4444;
            --warn: #f59e0b;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(14,165,233,0.18), transparent 30%),
                radial-gradient(circle at top left, rgba(34,197,94,0.12), transparent 25%),
                linear-gradient(180deg, var(--bg), #020617);
            color: var(--text);
            min-height: 100vh;
        }

        .container {
            max-width: 1180px;
            margin: 0 auto;
            padding: 28px 18px 42px;
        }

        .hero {
            background: linear-gradient(135deg, rgba(56,189,248,0.16), rgba(255,255,255,0.04));
            border: 1px solid var(--border);
            border-radius: 22px;
            padding: 26px;
            box-shadow: var(--shadow);
        }

        .hero-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 18px;
            flex-wrap: wrap;
        }

        .hero-title {
            min-width: 240px;
            flex: 1 1 280px;
        }

        .hero-title-group{
            display:flex;
            align-items:center;
            gap:14px;
        }

        .hero-text{
            display:flex;
            flex-direction:column;
        }

        .ld-logo{
            height:50px;
            width:auto;
            object-fit:contain;
        }

        h1 {
            margin: 0;
            font-size: 34px;
            line-height: 1.1;
        }

        .subtitle-mini {
            margin-top: 6px;
            color: var(--muted);
            font-size: 12px;
            letter-spacing: .03em;
        }

        .service-mini-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(120px, 1fr));
            gap: 10px;
            width: min(100%, 560px);
            flex: 0 1 560px;
        }

        .service-mini {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 10px 12px;
            box-shadow: var(--shadow);
            min-height: 58px;
        }

        .service-mini-head {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 4px;
        }

        .service-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            flex: 0 0 10px;
        }

        .service-dot.ok {
            background: var(--ok);
        }

        .service-dot.bad {
            background: var(--bad);
        }

        .service-dot.warn {
            background: var(--warn);
        }

        .service-mini-name {
            font-size: 14px;
            font-weight: 700;
            line-height: 1.2;
        }

        .service-mini-version {
            font-size: 11px;
            color: var(--muted);
            line-height: 1.2;
            padding-left: 18px;
            word-break: break-word;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
            margin-top: 22px;
        }

        .stat {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 16px;
            box-shadow: var(--shadow);
        }

        .stat.compact {
            padding: 12px 14px;
        }

        .stat .label {
            font-size: 12px;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: .06em;
            margin-bottom: 8px;
        }

        .stat .value {
            font-size: 24px;
            font-weight: 700;
            word-break: break-word;
        }

        .resource-block + .resource-block {
            margin-top: 10px;
        }

        .resource-head {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            align-items: baseline;
            margin-bottom: 5px;
        }

        .resource-name {
            font-size: 12px;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: .05em;
        }

        .resource-value {
            font-size: 12px;
            color: var(--text);
            text-align: right;
            font-weight: 400;
        }

        .resource-value strong {
            font-weight: 700;
        }

        .gauge {
            width: 100%;
            height: 7px;
            border-radius: 999px;
            background: rgba(255,255,255,0.08);
            overflow: hidden;
            border: 1px solid rgba(255,255,255,0.06);
        }

        .gauge-bar {
            height: 100%;
            border-radius: 999px;
        }

        .gauge-bar.mem {
            background: linear-gradient(90deg, #38bdf8, #0ea5e9);
        }

        .gauge-bar.disk {
            background: linear-gradient(90deg, #22c55e, #16a34a);
        }

        .tabs {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 24px;
        }

        .tab-button {
            border: 1px solid var(--border);
            background: var(--card);
            color: var(--text);
            padding: 10px 16px;
            border-radius: 999px;
            cursor: pointer;
            font-size: 14px;
            transition: .18s ease;
        }

        .tab-button:hover,
        .tab-button.active {
            background: rgba(56,189,248,0.16);
            border-color: rgba(56,189,248,0.40);
            color: #dff6ff;
        }

        .tab-panel {
            display: none;
            margin-top: 22px;
        }

        .tab-panel.active {
            display: block;
        }

        .section-title {
            margin: 0 0 12px;
            font-size: 22px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 16px;
        }

        .site-card, .tool-card, .cmd-block {
            display: block;
            text-decoration: none;
            color: inherit;
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 18px;
            padding: 18px;
            box-shadow: var(--shadow);
            transition: transform .18s ease, border-color .18s ease, background .18s ease;
        }

        .site-card:hover,
        .tool-card:hover {
            transform: translateY(-3px);
            border-color: rgba(56,189,248,0.45);
            background: rgba(255,255,255,0.08);
        }

        .tool-title, .cmd-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .site-head {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 6px;
        }

        .site-icon-link,
        .site-name-link {
            text-decoration: none;
            color: inherit;
        }

        .site-icon {
            width: 24px;
            height: 24px;
            object-fit: contain;
            flex: 0 0 24px;
            display: block;
        }

        .site-title-row {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .site-name {
            font-size: 20px;
            font-weight: 700;
            margin: 0;
            line-height: 1.2;
        }

        .site-admin-link {
            font-size: 13px;
            color: var(--primary);
            text-decoration: none;
            opacity: 0.95;
        }

        .site-admin-link:hover {
            text-decoration: underline;
            opacity: 1;
        }

        .site-card:hover .site-name {
            color: #dff6ff;
        }

        .site-meta, .tool-desc, .cmd-desc {
            margin-top: 10px;
            font-size: 14px;
            color: var(--muted);
            line-height: 1.5;
        }

        .empty {
            background: var(--card-2);
            border: 1px dashed var(--border);
            border-radius: 18px;
            padding: 24px;
            color: var(--muted);
        }

        .commands {
            display: grid;
            gap: 14px;
        }

        pre {
            margin: 10px 0 0;
            white-space: pre-wrap;
            word-break: break-word;
            background: rgba(0,0,0,0.25);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 12px;
            padding: 12px;
            color: #dbeafe;
            font-size: 13px;
            overflow: auto;
        }

        code {
            background: rgba(255,255,255,0.08);
            padding: 2px 6px;
            border-radius: 6px;
            color: #dbeafe;
        }

        .footer {
            margin-top: 30px;
            color: var(--muted);
            font-size: 13px;
            text-align: center;
        }

        .footer a {
            color: var(--primary);
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 980px) {
            .service-mini-grid {
                width: 100%;
                grid-template-columns: repeat(2, minmax(140px, 1fr));
                flex: 1 1 100%;
            }
        }

        @media (max-width: 640px) {
            h1 { font-size: 28px; }
            .container { padding: 18px 12px 30px; }
            .hero { padding: 18px; }
            .tabs { gap: 8px; }
            .tab-button { width: 100%; text-align: center; }
            .service-mini-grid {
                grid-template-columns: 1fr 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <section class="hero">

            <div class="hero-top">

                <div class="hero-title">
                    <div class="hero-title-group">
                        <img src="/assets/images/logo.webp" class="ld-logo" alt="LAMP Deck logo">
                        <div class="hero-text">
                            <h1>
                                <a href="/" style="color:inherit;text-decoration:none;">
                                    LAMP Deck
                                </a>
                            </h1>

                            <div class="subtitle-mini">
                                Multisite manager for LAMP Servers
                            </div>
                        </div>
                    </div>
                </div>

                <div class="service-mini-grid">
                    <?php foreach ($services as $svc): ?>
                        <?php
                            $status  = service_status($svc['unit']);
                            $version = service_version($svc['unit']);
                            $class   = status_class($status);
                        ?>
                        <div class="service-mini" title="<?= h($svc['label']) ?> <?= h($version ?: 'Unknown') ?> (<?= h($status) ?>)">
                            <div class="service-mini-head">
                                <span class="service-dot <?= h($class) ?>"></span>
                                <div class="service-mini-name"><?= h($svc['label']) ?></div>
                            </div>
                            <div class="service-mini-version"><?= h($version ?: 'Unknown') ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="stats">
                <div class="stat">
                    <div class="label">Host</div>
                    <div class="value"><?= h($serverName) ?></div>
                </div>

                <div class="stat">
                    <div class="label">Websites</div>
                    <div class="value"><?= $totalSites ?></div>
                </div>

                <div class="stat compact">
                    <div class="resource-block">
                        <div class="resource-head">
                            <div class="resource-name">RAM</div>
                            <div class="resource-value">
                                <strong><?= h($memInfo['percent']) ?>%</strong> (<?= h(format_bytes($memInfo['used'])) ?> de <?= h(format_bytes($memInfo['total'])) ?>)
                            </div>
                        </div>

                        <div class="gauge" title="RAM <?= h(format_bytes($memInfo['used'])) ?> / <?= h(format_bytes($memInfo['total'])) ?>">
                            <div class="gauge-bar mem" style="width: <?= (int)$memInfo['percent'] ?>%;"></div>
                        </div>
                    </div>

                    <div class="resource-block">
                        <div class="resource-head">
                            <div class="resource-name">Disk</div>
                            <div class="resource-value">
                                <strong><?= h($diskInfo['percent']) ?>%</strong> (<?= h(format_bytes($diskInfo['used'])) ?> de <?= h(format_bytes($diskInfo['total'])) ?>)
                            </div>
                        </div>

                        <div class="gauge" title="Disk <?= h(format_bytes($diskInfo['used'])) ?> / <?= h(format_bytes($diskInfo['total'])) ?>">
                            <div class="gauge-bar disk" style="width: <?= (int)$diskInfo['percent'] ?>%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tabs">
                <button class="tab-button active" data-tab="sites">Websites</button>
                <button class="tab-button" data-tab="ferramentas">Tools</button>
                <button class="tab-button" data-tab="instrucoes">Instructions</button>
                <button class="tab-button" data-tab="changelog">Changelog</button>
            </div>
        </section>

        <section id="tab-sites" class="tab-panel active">
            <h2 class="section-title">Available Websites</h2>

            <?php if (empty($dirs)): ?>
                <div class="empty">
                    No website folders were found in <code>/var/www</code>.
                </div>
            <?php else: ?>
                <div class="grid">
                    <?php foreach ($dirs as $d): ?>
                        <?php
                            $icon = site_icon($d);
                            $isWp = is_wordpress_site($d);
                            $desc = site_desc($d);
                            $typeLabel = site_type_label($d);
                        ?>
                        <div class="site-card">
                            <div class="site-head">
                                <a class="site-icon-link" href="/<?= rawurlencode($d) ?>/" target="_blank" rel="noopener noreferrer">
                                    <img
                                        class="site-icon"
                                        src="<?= h($icon) ?>"
                                        alt="<?= h($typeLabel) ?>"
                                        title="<?= h($typeLabel) ?>"
                                    >
                                </a>

                                <div class="site-title-row">
                                    <a class="site-name-link" href="/<?= rawurlencode($d) ?>/" target="_blank" rel="noopener noreferrer">
                                        <div class="site-name"><?= h($d) ?></div>
                                    </a>

                                    <?php if ($isWp): ?>
                                        <a
                                            class="site-admin-link"
                                            href="/<?= rawurlencode($d) ?>/wp-admin/"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                        >(WP-Admin)</a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if ($desc !== ''): ?>
                                <div class="site-meta"><?= h($desc) ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section id="tab-ferramentas" class="tab-panel">
            <h2 class="section-title">Tools</h2>
            <div class="grid">
                <a class="tool-card" href="/phpmyadmin/" target="_blank" rel="noopener noreferrer">
                    <div class="tool-title">phpMyAdmin</div>
                    <div class="tool-desc">Access MariaDB through the browser.</div>
                </a>

                <a class="tool-card" href="/info.php" target="_blank" rel="noopener noreferrer">
                    <div class="tool-title">phpinfo()</div>
                    <div class="tool-desc">Check PHP modules, directives and environment details.</div>
                </a>
            </div>
        </section>

        <section id="tab-instrucoes" class="tab-panel">
            <h2 class="section-title">Instructions</h2>

            <div class="commands">
                <div class="cmd-block">
                    <div class="cmd-title">Create a simple subsite</div>
                    <div class="cmd-desc">Accepts an optional description to be shown on the main page.</div>
                    <pre>lampdeck create-website site1 "Internal system"</pre>
                </div>

                <div class="cmd-block">
                    <div class="cmd-title">Create a full WordPress site</div>
                    <div class="cmd-desc">Also accepts an optional description for the site card.</div>
                    <pre>lampdeck create-wp site1 "Corporate WordPress website"</pre>
                </div>

                <div class="cmd-block">
                    <div class="cmd-title">Configure a domain for an existing folder</div>
                    <div class="cmd-desc">Creates Apache vhost for an existing site.</div>
                    <pre>lampdeck create-domain site1.com site1</pre>
                </div>

                <div class="cmd-block">
                    <div class="cmd-title">Enable valid SSL with Let's Encrypt</div>
                    <div class="cmd-desc">Use when the domain is already pointing to the server IP.</div>
                    <pre>lampdeck activate-ssl site1.com</pre>
                </div>
            </div>
        </section>

        <section id="tab-changelog" class="tab-panel">
            <h2 class="section-title">Changelog</h2>

            <div class="cmd-block">
#xxx
                <pre>
Version 2.1.4 - 2026-04-13
- Fixed installation phpmyadmin in upgrades
- Fixed logo size in Frontpage
- Fixed phpmyadmin installation
- Fixed installation PHP8.4 packages for ubuntu releases

Version 2.1.0 - 2026-04-12
- Support for Ubuntu 20.04 LTS (Jammy), 24.04 LTS (Noble)
- Support for Alpine 3.x

Version 2.0.0 - 2026-04-10
- Initial release
                </pre>
            </div>
        </section>

        <div class="footer">
            LAMP Deck v__VERSAO__ (__ID__ __VERSION_CODENAME__) · © 2026 Aurélio Barreto · <a href="https://github.com/albarreto/lampdeck-v2" target="_blank" rel="noopener noreferrer">GitHub</a>
        </div>
    </div>

    <script>
        const buttons = document.querySelectorAll('.tab-button');
        const panels = document.querySelectorAll('.tab-panel');

        buttons.forEach((button) => {
            button.addEventListener('click', () => {
                const target = button.dataset.tab;

                buttons.forEach((b) => b.classList.remove('active'));
                panels.forEach((p) => p.classList.remove('active'));

                button.classList.add('active');
                document.getElementById('tab-' + target).classList.add('active');
            });
        });
    </script>
</body>
</html>
EOF

sed -i "s/__VERSAO__/${APP_VERSION}/g" /var/www/html/index.php
sed -i "s/__ID__/${ID}/g" /var/www/html/index.php
sed -i "s/__VERSION_CODENAME__/${VERSION_CODENAME}/g" /var/www/html/index.php

#########################################################
# INFO PHP
#########################################################

echo "<?php phpinfo();" > /var/www/html/info.php

#########################################################
# BASH COMPLETION
#########################################################

mkdir -p /etc/bash_completion.d
cat > /etc/bash_completion.d/lampdeck <<'EOF'
_lampdeck_completions()
{
    local cur prev prev2 cmd
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    prev2="${COMP_WORDS[COMP_CWORD-2]}"
    cmd="${COMP_WORDS[1]}"

    local commands="create-website create-wp create-domain activate-ssl sites version help"

    _lampdeck_list_sites()
    {
        if [ -d /var/www ]; then
            find /var/www -mindepth 1 -maxdepth 1 -type d 2>/dev/null \
                | xargs -r -n1 basename \
                | grep -vE '^(html|certs)$'
        fi
    }

    _lampdeck_list_domains()
    {
        if [ -d /etc/apache2/sites-available ]; then
            find /etc/apache2/sites-available -maxdepth 1 -type f -name '*.conf' 2>/dev/null \
                | xargs -r -n1 basename \
                | sed 's/\.conf$//' \
                | grep -vE '^(000-default|default-ssl)$'
        fi
    }

    if [ "$COMP_CWORD" -eq 1 ]; then
        COMPREPLY=( $(compgen -W "$commands" -- "$cur") )
        return 0
    fi

    case "$cmd" in
        create-website|create-wp)
            if [ "$COMP_CWORD" -eq 2 ]; then
                COMPREPLY=( $(compgen -W "$(_lampdeck_list_sites)" -- "$cur") )
                return 0
            fi
            ;;
        create-domain)
            if [ "$COMP_CWORD" -eq 3 ]; then
                COMPREPLY=( $(compgen -W "$(_lampdeck_list_sites)" -- "$cur") )
                return 0
            fi
            ;;
        activate-ssl)
            if [ "$COMP_CWORD" -eq 2 ]; then
                COMPREPLY=( $(compgen -W "$(_lampdeck_list_domains)" -- "$cur") )
                return 0
            fi
            ;;
    esac
}

complete -F _lampdeck_completions lampdeck
EOF

#########################################################
# DISABLE DEFAULT APACHE PAGE
#########################################################

if [ -f /var/www/html/index.html ] && [ ! -f /var/www/html/index_apache.html ]; then
    mv /var/www/html/index.html /var/www/html/index_apache.html
fi

echo
echo "#############################################################"
echo "CONGRATULATIONS!!! ${APP_NAME} v${APP_VERSION} was installed/upgraded."
echo "#############################################################"
echo
echo "How to access:"
echo "  https://${SERVER_IP}/"
echo "  https://${SERVER_IP}/phpmyadmin/"
echo
echo "Installed Commands:"
echo "  lampdeck create-website site1 \"Internal System\""
echo "  lampdeck create-wp site1 \"Company WordPress Website\""
echo "  lampdeck create-domain site1.com site1"
echo "  lampdeck activate-ssl site1.com"
echo "  lampdeck sites"
echo "  lampdeck version"
echo "  lampdeck help"
echo
echo "Autocompletation for lampdeck was installed."
echo "NOTE: To enable it in the current shell, run: source /etc/bash_completion.d/lampdeck"
echo "      or close and reopen terminal"
echo

