# Changelog

## 2.0.0 - 2026-04-11
- Initial release
