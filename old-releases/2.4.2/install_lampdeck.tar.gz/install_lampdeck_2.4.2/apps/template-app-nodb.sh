#!/bin/bash

###############################################################################
# LAMP Deck app module
# template-nodb
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="template-nodb"                 # Example: grav
APP_NAME="Template NoDB App"             # Example: Grav
APP_HAS_DB="0"                           # 0 = app does not use database
APP_ADMIN_PATH=""
APP_ADMIN_LABEL=""
APP_DOWNLOAD_URL="https://example.com/template-nodb.tar.gz"

app_prepare_no_db "${1:-}" "${2:-}"

#########################################
# package
#########################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"
app_init_tmp_dir
app_extract_archive
app_copy_files_to_base

#########################################
# custom app config
#########################################

# Add app-specific configuration here

#########################################
# metadata
#########################################

app_write_metadata "$APP_SLUG"

#########################################
# permissions
#########################################

app_apply_default_permissions

# Add app-specific writable directories here
# app_apply_rw_permissions "$BASE/cache"

#########################################
# apache reload
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

app_print_success_no_db


