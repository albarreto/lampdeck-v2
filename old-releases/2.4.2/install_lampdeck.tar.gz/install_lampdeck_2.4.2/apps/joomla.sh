#!/bin/bash

###############################################################################
# LAMP Deck app module
# joomla
#
# Description:
# Installs and configures a Joomla site inside the LAMP Deck environment.
#
# Includes:
# - site name validation
# - root database password validation
# - base website creation
# - database creation with overwrite support from db.sh
# - Joomla download and extraction
# - metadata files
# - permissions setup
# - automatic rollback on failure
#
# Usage:
# lampdeck install joomla <site-name> [description]
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="joomla"                        # Example: joomla
APP_NAME="Joomla"                        # Example: Joomla
APP_HAS_DB="1"                           # 1 = app uses database
APP_ADMIN_PATH="administrator"
APP_ADMIN_LABEL="Admin"
APP_DOWNLOAD_URL="${JOOMLA_URL:-https://downloads.joomla.org/cms/joomla6/6-1-0/Joomla_6-1-0-Stable-Full_Package.tar.gz?format=gz}"

app_prepare_with_db "${1:-}" "${2:-}"

#########################################
# package
#########################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"
app_init_tmp_dir
app_extract_archive
app_copy_files_to_base

#########################################
# metadata
#########################################

app_write_metadata "$APP_SLUG"

#########################################
# permissions
#########################################

app_apply_default_permissions
app_apply_rw_permissions \
    "$BASE/cache" \
    "$BASE/administrator/cache" \
    "$BASE/images" \
    "$BASE/tmp" \
    "$BASE/logs"

#########################################
# apache reload
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

app_print_success_with_db
