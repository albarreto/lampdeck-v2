#!/bin/bash

###############################################################################
# LAMP Deck app module
# wordpress
#
# Description:
# Installs and configures a WordPress site inside the LAMP Deck environment.
#
# Includes:
# - site name validation
# - root database password validation
# - base website creation
# - database creation with overwrite support from db.sh
# - WordPress download and extraction
# - wp-config.php configuration
# - Apache rewrite rules
# - metadata files
# - permissions setup
# - automatic rollback on failure
#
# Usage:
# lampdeck install wordpress <site-name> [description]
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="wordpress"                      # Example: wordpress
APP_NAME="WordPress"                      # Example: WordPress
APP_HAS_DB="1"                            # 1 = app uses database
APP_ADMIN_PATH="wp-admin"
APP_ADMIN_LABEL="WP-Admin"
APP_DOWNLOAD_URL="https://wordpress.org/latest.tar.gz"

app_prepare_with_db "${1:-}" "${2:-}"

#########################################
# package
#########################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"
app_init_tmp_dir
app_extract_archive "wordpress" # Incluindo a subpasta "wordpress" q vem no tar.gz
app_copy_files_to_base

#########################################
# app config
#########################################

cp "$BASE/wp-config-sample.php" "$BASE/wp-config.php"

sed -i "s|database_name_here|$DB_NAME|g" "$BASE/wp-config.php"
sed -i "s|username_here|$DB_USER|g" "$BASE/wp-config.php"
sed -i "s|password_here|$DB_PASS|g" "$BASE/wp-config.php"
sed -i "s|localhost|127.0.0.1|g" "$BASE/wp-config.php"

cat >> "$BASE/wp-config.php" <<EOCFG

define('WP_HOME', 'https://$SERVER_IP/$SITE');
define('WP_SITEURL', 'https://$SERVER_IP/$SITE');
define('WP_REDIS_HOST', '127.0.0.1');

EOCFG

cat > "$BASE/.htaccess" <<EOHT
RewriteEngine On

RewriteBase /$SITE/

RewriteRule ^index\.php$ - [L]

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d

RewriteRule . /$SITE/index.php [L]
EOHT

#########################################
# metadata
#########################################

app_write_metadata "$APP_SLUG"

#########################################
# permissions
#########################################

app_apply_default_permissions
app_apply_rw_permissions "$BASE/wp-content"

#########################################
# apache reload
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

app_print_success_with_db
