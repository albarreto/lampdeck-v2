#!/bin/bash

###############################################################################
# LAMP Deck app module
# html/php
#
# Description:
# Installs and configures a regula site HTML/PHP
#
# Usage:
# lampdeck install joomla <site-name> [description]
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="html"                 # Example: wordpress
APP_NAME="HTML/PHP"             # Example: Wordpress
#APP_ADMIN_PATH=""
#APP_ADMIN_LABEL=""
#APP_HAS_DB="0"                  # 0 = app does not use database

app_prepare_no_db "${1:-}" "${2:-}"

#########################################
# custom app config
#########################################

# Add app-specific configuration here

#########################################
# metadata
#########################################

app_write_metadata "$APP_SLUG"

#########################################
# permissions
#########################################

app_apply_default_permissions


#########################################
# apache reload
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

app_print_success_no_db
