#!/bin/bash
#
###############################################################################
#
# LAMP Deck Installer
#
# Project: https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# Description
# -----------------------------------------------------------------------------
# Automated installer for a modern LAMP stack optimized for multi-site hosting.
#
# This script installs and configures:
#
#   • Apache 2.4 (event MPM)
#   • PHP-FPM (8.x)
#   • MariaDB
#   • Redis
#   • phpMyAdmin
#   • Certbot (Let's Encrypt)
#
# It also deploys a lightweight management interface that allows:
#
#   • creation of isolated websites under /var/www
#   • automatic Apache alias configuration
#   • rapid WordPress deployment with database creation
#   • optional domain configuration with HTTPS
#   • centralized overview of hosted sites
#
#
# Features
# -----------------------------------------------------------------------------
#   • Multi-site structure using Apache Alias
#   • WordPress-ready PHP tuning
#   • Redis object cache support
#   • automatic database provisioning
#   • self-signed SSL by default
#   • Let's Encrypt integration
#   • clean and minimal web interface
#   • helper CLI tools:
#
#       create-website   create basic site
#       create-domain    attach domain to site
#       install          install supported web application
#       activate-ssl     generate valid certificate
#       lamp-version     show stack versions
#
#
# License
# -----------------------------------------------------------------------------
# GNU General Public License v3.0
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License,
# or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See the GNU General Public License for more details:
#
###############################################################################

set -euo pipefail


###############################################################################
# LAMP Deck Installer
###############################################################################

APP_NAME="LAMP Deck"
APP_VERSION="2.4.2" # RC: 9.9.9-rc.9
SERVER_IP="$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')"
SERVER_IP="${SERVER_IP:-127.0.0.1}"
LIB_DIR="/usr/lib/lampdeck"
BIN_DIR="/usr/local/bin"
APPS_DIR="$LIB_DIR/apps"

echo
echo "============================================"
echo "$APP_NAME v$APP_VERSION INSTALLATION"
echo "============================================"
echo
echo "This installer will configure the LAMP Deck environment."
echo "Required components will be installed and configured automatically."
echo

if [ -d /var/lib/mysql/mysql ]; then
    DB_ALREADY_INSTALLED=1
else
    DB_ALREADY_INSTALLED=0
fi

if [ "$DB_ALREADY_INSTALLED" -eq 0 ]; then
    echo
    echo "============================================"
    echo "LAMP DECK INSTALLATION"
    echo "============================================"
    echo
    echo "Database configuration is required."
    echo

    while true; do
        read -s -p "Enter MariaDB root password: " DB_ROOT_PASS
        echo
        read -s -p "Confirm MariaDB root password: " DB_ROOT_PASS_CONFIRM
        echo

        if [ "$DB_ROOT_PASS" != "$DB_ROOT_PASS_CONFIRM" ]; then
            echo "Passwords do not match. Try again."
            echo
            continue
        fi

        if [ -z "$DB_ROOT_PASS" ]; then
            echo "Password cannot be empty."
            echo
            continue
        fi

        break
    done

    export DB_ROOT_PASS
else
    echo
    echo "Existing MariaDB installation detected."
    echo "Keeping current MariaDB root configuration."
    echo
fi

###############################################################################
# Packages Installer
###############################################################################

echo "== Detecting Linux distribution"

if [ ! -r /etc/os-release ]; then
    echo "Error: cannot detect Linux distribution."
    exit 1
fi

. /etc/os-release

DIST_ID="${ID:-unknown}"
DIST_VERSION_ID="${VERSION_ID:-unknown}"
DIST_CODENAME="${VERSION_CODENAME:-unknown}"

echo "Detected:"
echo "  ID=$DIST_ID"
echo "  VERSION_ID=$DIST_VERSION_ID"
echo "  VERSION_CODENAME=$DIST_CODENAME"
echo

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

case "$DIST_ID:$DIST_VERSION_ID:$DIST_CODENAME" in

    #########################################################
    # DEBIAN
    #########################################################

    debian:12:*|debian:*:bookworm)
        source "$SCRIPT_DIR/pkg/pkg_debian_bookworm.sh"
        install_debian_bookworm_packages
        ;;

    debian:13:*|debian:*:trixie)
        source "$SCRIPT_DIR/pkg/pkg_debian_trixie.sh"
        install_debian_trixie_packages
        ;;

    #########################################################
    # UBUNTU
    #########################################################

    ubuntu:22.04:*|ubuntu:*:jammy)
        source "$SCRIPT_DIR/pkg/pkg_ubuntu_jammy.sh"
        install_ubuntu_22_04_packages
        ;;

    ubuntu:24.04:*|ubuntu:*:noble)
        source "$SCRIPT_DIR/pkg/pkg_ubuntu_noble.sh"
        install_ubuntu_24_04_packages
        ;;

    #########################################################
    # ALPINE
    #########################################################

    alpine:*:*)
        source "$SCRIPT_DIR/pkg/pkg_alpine_3.sh"
        install_alpine_packages
        ;;

    #########################################################
    # DEFAULT
    #########################################################

    *)
        echo "Error: unsupported distribution/version."
        echo
        echo "Supported:"
        echo "  Alpine 3.19+ (soon)"
        echo "  Debian 12 (bookworm)"
        echo "  Debian 13 (trixie)"
        echo "  Ubuntu 22.04 (jammy)"
        echo "  Ubuntu 24.04 (noble)"
        echo
        exit 1
        ;;

esac

#########################################################
# INSTALL SHARED LIBS
#########################################################

echo "== Installing shared libraries"

if [ -d "$SCRIPT_DIR/lib" ]; then

    cp "$SCRIPT_DIR/lib/"*.sh "$LIB_DIR"/ 2>/dev/null || true
    chmod +x "$LIB_DIR/"*.sh 2>/dev/null || true

    echo "=== Shared libraries installed."

else
    echo " === WARNING: lib folder not found."
fi

#########################################################
# INSTALL APP MODULES
#########################################################

echo "== Installing app modules"

if [ -d "$SCRIPT_DIR/apps" ]; then
    cp "$SCRIPT_DIR/apps/"*.sh "$APPS_DIR"/ 2>/dev/null || true
    chmod +x "$APPS_DIR/"*.sh 2>/dev/null || true
    echo "=== Apps installed."
else
    echo "=== WARNING: apps folder not found."
fi

#########################################################
# MAIN CLI
#########################################################
cat > "$BIN_DIR/lampdeck" <<'EOF'
#!/bin/bash

###############################################################################
# LAMP Deck - main CLI
# Description: Central command line interface for LAMP Deck
#
# Project: https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="__LIB_DIR__"

run_module() {
    local module="${1-}"

    if [ -z "$module" ]; then
        echo "Error: run_module() called without module name"
        exit 1
    fi

    shift || true

    local target="$LIB_DIR/$module"

    if [ ! -f "$target" ]; then
        if [[ "$module" == apps/*\.sh ]]; then
            local app_name

            local SUPPORTED_APPS=("WordPress" "Joomla")

            app_name="$(basename "$module" .sh)"

            echo "Error: unsupported app \"$app_name\"."
            echo "Currently supported apps:"
            for app in "${SUPPORTED_APPS[@]}"; do
                echo "- $app"
            done
        else
            echo "Error: module not found: $target"
        fi
        exit 1
    fi

    if [ ! -x "$target" ]; then
        chmod +x "$target" 2>/dev/null || true
    fi

    "$target" "$@"
}

if [ ! -d "$LIB_DIR" ]; then
    echo "Error: auxiliary directory not found: $LIB_DIR"
    echo "LAMP Deck is not correctly installed."
    exit 1
fi

CMD="${1:-}"

case "$CMD" in
    create-website)
        shift

        SITE="${1:-}"

        if [ -z "$SITE" ]; then
            echo "Usage: lampdeck create-website <site> [description] [-d <domain>]"
            exit 1
        fi

        shift

        DOMAIN=""
        DESCRIPTION_PARTS=()

        while [ $# -gt 0 ]; do
            case "$1" in
                -d)
                    if [ -n "$DOMAIN" ]; then
                        echo "Error: domain already informed."
                        exit 1
                    fi

                    shift

                    if [ $# -eq 0 ] || [ -z "${1:-}" ] || [[ "$1" == -* ]]; then
                        echo "Error: option -d requires a domain."
                        echo "Usage: lampdeck create-website <site> [description] [-d <domain>]"
                        exit 1
                    fi

                    DOMAIN="$1"
                    ;;
                -*)
                    echo "Error: unknown option: $1"
                    echo "Usage: lampdeck create-website <site> [description] [-d <domain>]"
                    exit 1
                    ;;
                *)
                    DESCRIPTION_PARTS+=("$1")
                    ;;
            esac
            shift
        done

        DESCRIPTION="${DESCRIPTION_PARTS[*]}"

        run_module "create-website.sh" "$SITE" "$DESCRIPTION"

        if [ -n "$DOMAIN" ]; then
            "$LIB_DIR/create-domain.sh" "$DOMAIN" "$SITE"
        fi
        ;;

    install)
        shift
        APP="${1:-}"

        if [ -z "$APP" ]; then
            echo "Usage: lampdeck install <app> <site> [description] [-d <domain>]"
            exit 1
        fi

        shift

        SITE=""
        DOMAIN=""
        DESCRIPTION_PARTS=()

        while [ $# -gt 0 ]; do
            case "$1" in
                -d)
                    if [ -n "$DOMAIN" ]; then
                        echo "Error: domain already informed."
                        exit 1
                    fi

                    shift

                    if [ $# -eq 0 ] || [ -z "${1:-}" ] || [[ "$1" == -* ]]; then
                        echo "Error: option -d requires a domain."
                        echo "Usage: lampdeck install <app> <site> [description] [-d <domain>]"
                        exit 1
                    fi

                    DOMAIN="$1"
                    ;;
                -*)
                    echo "Error: unknown option: $1"
                    echo "Usage: lampdeck install <app> <site> [description] [-d <domain>]"
                    exit 1
                    ;;
                *)
                    if [ -z "$SITE" ]; then
                        SITE="$1"
                    else
                        DESCRIPTION_PARTS+=("$1")
                    fi
                    ;;
            esac
            shift
        done

        if [ -z "$SITE" ]; then
            echo "Usage: lampdeck install <app> <site> [description] [-d <domain>]"
            exit 1
        fi

        DESCRIPTION="${DESCRIPTION_PARTS[*]}"

        run_module "apps/$APP.sh" "$SITE" "$DESCRIPTION"

        if [ -n "$DOMAIN" ]; then
            "$LIB_DIR/create-domain.sh" "$DOMAIN" "$SITE"
        fi
        ;;

    create-domain)
        shift
        run_module "create-domain.sh" "$@"
        ;;

    activate-ssl)
        shift
        run_module "activate-ssl.sh" "$@"
        ;;

    sites)
        shift
        run_module "sites.sh" "$@"
        ;;

    version)
        shift
        run_module "version.sh" "$@"
        ;;

    --help|-h|help|"")
        shift || true
        run_module "help.sh" "$@"
        ;;

    *)
        echo "Unknown command: $CMD"
        echo
        run_module "help.sh"
        exit 1
        ;;
esac
EOF

sed -i "s|__LIB_DIR__|$LIB_DIR|g" "$BIN_DIR/lampdeck"
chmod +x "$BIN_DIR/lampdeck"


#########################################################
# MODULE: help
#########################################################

cat > $LIB_DIR/help.sh <<EOF
#!/bin/bash

###############################################################################
# ${APP_NAME} module
# help
#
# Description:
# Displays command usage information
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# GPL-3.0-or-later
###############################################################################

cat <<HELP

${APP_NAME} v${APP_VERSION}
Multisite manager for LAMP servers

USAGE
  lampdeck <command> [options]

ALSO
  lampdeck help
  lampdeck -h
  lampdeck --help

COMMANDS

  create-website <site> [description]
      Create a basic HTML website in /var/www/<site>

  install <app> <site> [description]
  install <app> <site> [description] [-d <domain>]
      Install a supported web application
      -d <domain>   Create and configure a domain for the installed site

  create-domain <domain> <site>
      Configure Apache vhost for an existing site

  activate-ssl <domain>
      Enable Let's Encrypt SSL certificate

  sites
      List installed sites

  version (or -h --help)
      Show installed version

EXAMPLES

  lampdeck create-website portal "Internal system"
  lampdeck install wordpress blog "Corporate website"
  lampdeck create-domain blog.example.com blog
  lampdeck activate-ssl blog.example.com

SUPPORTED APPS
  wordpress
  joomla

PROJECT
  https://github.com/albarreto/lampdeck-v2

HELP

EOF

chmod +x $LIB_DIR/help.sh

#########################################################
# MODULE: version
#########################################################

cat > "$LIB_DIR/version.sh" <<'EOF'
#!/bin/bash

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

echo
echo "${APP_NAME} v${APP_VERSION}"
echo

# OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    echo "OS:       $PRETTY_NAME"
fi

# Apache
if command -v apache2 >/dev/null 2>&1; then
    APACHE_VERSION="$(apache2 -v | awk -F': ' '/Server version/ {print $2}')"
    echo "Apache:   $APACHE_VERSION"
fi

# PHP
if command -v php >/dev/null 2>&1; then
    PHP_VERSION="$(php -r 'echo PHP_VERSION;')"
    echo "PHP:      $PHP_VERSION"
fi

# MariaDB / MySQL
if command -v mariadb >/dev/null 2>&1 || command -v mysql >/dev/null 2>&1; then
    DB_VERSION="$(mariadb -N -B -e "SELECT VERSION();" 2>/dev/null || true)"

    if [ -z "$DB_VERSION" ] && command -v mariadb >/dev/null 2>&1; then
        DB_VERSION="$(mariadb --version | sed -E 's/.* ([0-9]+\.[0-9]+\.[0-9]+[-A-Za-z0-9\.]*).*/\1/')"
    fi

    if [ -z "$DB_VERSION" ] && command -v mysql >/dev/null 2>&1; then
        DB_VERSION="$(mysql --version | sed -E 's/.*Distrib ([0-9]+\.[0-9]+\.[0-9]+).*/\1/')"
    fi

    if [ -n "$DB_VERSION" ]; then
        echo "MariaDB:  $DB_VERSION"
    fi
fi

# Redis
if command -v redis-server >/dev/null 2>&1; then
    REDIS_VERSION="$(redis-server --version | awk '{print $3}' | cut -d= -f2)"
    echo "Redis:    $REDIS_VERSION"
fi

echo
EOF

chmod +x "$LIB_DIR/version.sh"

#########################################################
# MODULE: sites
#########################################################

cat > "$LIB_DIR/sites.sh" <<'EOF'
#!/bin/bash

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

SERVER_IP="$(get_server_ip)"

if [ ! -d "$WWW_ROOT" ]; then
    echo "Error: $WWW_ROOT not found."
    exit 1
fi

site_type() {
    local base="$1"
    local ini="$base/lampdeck.ini"

    if [ -f "$ini" ]; then
        awk -F '=' '
            /^\[app\]/ { in_app=1; next }
            /^\[/ && !/^\[app\]/ { in_app=0 }
            in_app && $1 ~ /^[[:space:]]*type[[:space:]]*$/ {
                gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2)
                print tolower($2)
                exit
            }
        ' "$ini"
    else
        echo "unknown"
    fi
}

site_desc() {
    local base="$1"
    local ini="$base/lampdeck.ini"

    if [ -f "$ini" ]; then
        awk -F '=' '
            /^\[site\]/ { in_site=1; next }
            /^\[/ && !/^\[site\]/ { in_site=0 }
            in_site && $1 ~ /^[[:space:]]*description[[:space:]]*$/ {
                sub(/^[[:space:]]+/, "", $2)
                sub(/[[:space:]]+$/, "", $2)
                print $2
                exit
            }
        ' "$ini"
    else
        echo ""
    fi
}

site_domain() {
    local base="$1"
    local result=""

    result=$(
        grep -Ril "DocumentRoot[[:space:]]\+$base" "$APACHE_SITES_AVAILABLE" 2>/dev/null \
        | while read -r conf; do
            awk '/^[[:space:]]*ServerName[[:space:]]+/ { print $2; exit }' "$conf"
          done \
        | head -n 1
    )

    echo "${result:-}"
}

site_url() {
    local site="$1"
    local domain="$2"

    if [ -n "$domain" ]; then
        echo "https://$domain"
    else
        echo "https://$SERVER_IP/$site/"
    fi
}

print_header() {
    printf "%-22s %-10s %-35s %-28s %-50s\n" \
        "SITE" "TYPE" "URL" "DOMAIN" "DESCRIPTION"

    printf "%-22s %-10s %-35s %-28s %-50s\n" \
        "----------------------" \
        "----------" \
        "-----------------------------------" \
        "----------------------------" \
        "--------------------------------------------------"
}

FOUND=0
print_header

for base in "$WWW_ROOT"/*; do
    [ -d "$base" ] || continue

    site="$(basename "$base")"

    case "$site" in
        html|certs)
            continue
            ;;
    esac

    FOUND=1

    type="$(site_type "$base")"
    domain="$(site_domain "$base")"
    url="$(site_url "$site" "$domain")"
    desc="$(site_desc "$base")"

    printf "%-22s %-10s %-35s %-28s %-50s\n" \
        "$site" \
        "$type" \
        "$url" \
        "${domain:--}" \
        "$desc"
done

if [ "$FOUND" -eq 0 ]; then
    echo "No websites found in $WWW_ROOT."
fi
EOF

chmod +x "$LIB_DIR/sites.sh"


#########################################################
# MODULE: create-website
#########################################################

cat > "$LIB_DIR/create-website.sh" <<'EOF'
#!/bin/bash

###############################################################################
# ${APP_NAME} module
# create-website
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

SERVER_IP="$(get_server_ip)"
SITE="${1:-}"
DESC="${2:-}"

SITE="${SITE#/}"
SITE="${SITE%/}"
CREATED_AT="$(date '+%d/%m/%Y às %H:%M:%S')"

if [ -z "$SITE" ]; then
    echo "How to Use: lampdeck create-website <site-name> [description]"
    exit 1
fi

BASE="$WWW_ROOT/$SITE"

if [ -e "$BASE" ]; then
    echo
    echo "Error: website folder already exists:"
    echo "  $BASE"
    echo
    echo "Creation ABORTED to avoid changing existing content."
    echo "Rename or remove the folder first, then run the command again."
    echo
    exit 1
fi

if [ ! -f "$SUBSITES_CONF" ]; then
    touch "$SUBSITES_CONF"
fi

mkdir -p "$BASE"

if ! grep -q "Alias /$SITE/" "$SUBSITES_CONF" 2>/dev/null; then
    cat >> "$SUBSITES_CONF" <<EOT

RedirectMatch 302 ^/$SITE$ /$SITE/

Alias /$SITE/ $BASE/

<Directory $BASE/>
    AllowOverride All
    Require all granted
    DirectoryIndex index.php index.html
</Directory>

EOT
fi

#===xxx HTML for new website
cat > "$BASE/index.php" <<'EOPHP'
<?php
$site='__SITE__';
$desc='__DESC__';
$createdAt='__DATA__';
$lampVersion='__VERSAO__';
$path='__PATH__';

function h($v){
    return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?=h($site)?> | LAMP Deck</title>

<link rel="stylesheet" href="/assets/css/style.css">

</head>

<body>

<div class="container">

<div class="card">

<div class="header">

<div class="logo">
<img src="/assets/images/logo.webp" alt="LAMP Deck">
</div>

<div class="header-text">

<div class="badge">
New Website
</div>

<h1><?=h($site)?></h1>

</div>
</div>

<div class="subtitle">

Your website was created successfully and is ready for development.

</div>

<?php if(trim($desc)!==''): ?>

<div class="desc">

<?=nl2br(h($desc))?>

</div>

<?php endif; ?>

<div class="grid">

<div class="info">
<div class="label">
Status
</div>

<div class="value">
Ready to customize
</div>
</div>

<div class="info">
<div class="label">
Created at
</div>

<div class="value">
<?=h($createdAt)?>
</div>
</div>

<div class="info">
<div class="label">
Website path
</div>

<div class="value">
<?=h($path)?>
</div>
</div>

</div>

<div class="footer">

Generated by LAMP Deck v<?=h($lampVersion)?>

</div>

</div>
</div>

</body>
</html>
EOPHP


sed -i "s|__SITE__|$SITE|g" "$BASE/index.php"
sed -i "s|__DESC__|$DESC|g" "$BASE/index.php"
sed -i "s|__DATA__|$CREATED_AT|g" "$BASE/index.php"
sed -i "s|__VERSAO__|__APP_VERSION__|g" "$BASE/index.php"
sed -i "s|__PATH__|$BASE|g" "$BASE/index.php"


cat > "$BASE/lampdeck.ini" <<EOLDINI
[app]
type = html
name = HTML/PHP
has_db = 0

[admin]
path =
label =

[site]
description = ${DESC:-}
EOLDINI


chown -R www-data:www-data "$BASE"

systemctl reload apache2


echo
echo "============================================"
echo "WEBSITE AREA CREATED"
echo "URL: https://$SERVER_IP/$SITE/"
echo "============================================"
echo

EOF

sed -i "s|__APP_VERSION__|$APP_VERSION|g" "$LIB_DIR/create-website.sh"

chmod +x "$LIB_DIR/create-website.sh"

#########################################################
# MODULE: create-domain
#########################################################

cat > $LIB_DIR/create-domain.sh <<'EOF'
#!/bin/bash

###############################################################################
# create-domain
#
# Description:
# Creates a new domain for an existing site
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

if [ $# -lt 2 ]; then
    echo "How to Use: lampdeck create-domain <domain> <folder>"
    echo "e.g. lampdeck create-domain acme.local acme"
    exit 1
fi

DOMAIN="$1"
SITE="$2"
BASE="$WWW_ROOT/$SITE"
CONF="$APACHE_SITES_AVAILABLE/$DOMAIN.conf"
FRONTPAGE_HTTP_CONF="$APACHE_SITES_AVAILABLE/000-lampdeck.conf"
FRONTPAGE_HTTPS_CONF="$APACHE_SITES_AVAILABLE/000-lampdeck-ssl.conf"

if [ ! -d "$BASE" ]; then
    echo "Error: folder $BASE does not exist."
    exit 1
fi

###############################################################################
# Ensure LampDeck Frontpage remains the default root for IP access
###############################################################################

cat > "$FRONTPAGE_HTTP_CONF" <<EOVHOST
<VirtualHost *:80>
    ServerName localhost
    DocumentRoot $WWW_ROOT/html
    DirectoryIndex index.php index.html

    <Directory $WWW_ROOT/html>
        AllowOverride All
        Require all granted
        Options FollowSymLinks
    </Directory>

    ErrorLog \${APACHE_LOG_DIR}/lampdeck-frontpage-error.log
    CustomLog \${APACHE_LOG_DIR}/lampdeck-frontpage-access.log combined
</VirtualHost>
EOVHOST

cat > "$FRONTPAGE_HTTPS_CONF" <<EOVHOST
<IfModule mod_ssl.c>
<VirtualHost *:443>
    ServerName localhost
    DocumentRoot $WWW_ROOT/html
    DirectoryIndex index.php index.html

    <Directory $WWW_ROOT/html>
        AllowOverride All
        Require all granted
        Options FollowSymLinks
    </Directory>

    <FilesMatch \.php$>
        SetHandler "proxy:unix:/run/php/php8.4-fpm.sock|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile $CERT_DIR/server.crt
    SSLCertificateKeyFile $CERT_DIR/server.key

    ErrorLog \${APACHE_LOG_DIR}/lampdeck-frontpage-ssl-error.log
    CustomLog \${APACHE_LOG_DIR}/lampdeck-frontpage-ssl-access.log combined
</VirtualHost>
</IfModule>
EOVHOST

###############################################################################
# Domain vhost for selected site
###############################################################################

cat > "$CONF" <<EOVHOST
<VirtualHost *:80>
    ServerName $DOMAIN
    ServerAlias www.$DOMAIN

    DocumentRoot $BASE
    DirectoryIndex index.php index.html

    <Directory $BASE>
        AllowOverride All
        Require all granted
        Options FollowSymLinks
    </Directory>

    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/\.well-known/acme-challenge/
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]

    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}-error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}-access.log combined
</VirtualHost>

<IfModule mod_ssl.c>
<VirtualHost *:443>
    ServerName $DOMAIN
    ServerAlias www.$DOMAIN

    Protocols h2 http/1.1
    DocumentRoot $BASE
    DirectoryIndex index.php index.html

    <Directory $BASE>
        AllowOverride All
        Require all granted
        Options FollowSymLinks
    </Directory>

    <FilesMatch \.php$>
        SetHandler "proxy:unix:/run/php/php8.4-fpm.sock|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile $CERT_DIR/server.crt
    SSLCertificateKeyFile $CERT_DIR/server.key

    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}-ssl-error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}-ssl-access.log combined
</VirtualHost>
</IfModule>
EOVHOST

a2ensite 000-lampdeck.conf >/dev/null 2>&1 || true
a2ensite 000-lampdeck-ssl.conf >/dev/null 2>&1 || true
a2dissite 000-default.conf >/dev/null 2>&1 || true
a2dissite default-ssl.conf >/dev/null 2>&1 || true
a2ensite "$DOMAIN.conf" >/dev/null

apache2ctl configtest >/dev/null
systemctl reload apache2

SERVER_IP="$(get_server_ip)"

echo
echo "Domain created successfully:"
echo "  Domain: $DOMAIN"
echo "  Folder: $BASE"
echo
echo "General access remains:"
echo "  https://$SERVER_IP/"
echo
echo "Site by IP path remains:"
echo "  https://$SERVER_IP/$SITE/"
echo
echo "Domain access:"
echo "  https://$DOMAIN"
echo
echo "*** IMPORTANT: DON'T FORGET TO configure DNS or local hosts file!"
echo
echo "Then issue a genuine SSL certificate with:"
echo "  lampdeck activate-ssl $DOMAIN"
EOF

chmod +x $LIB_DIR/create-domain.sh

#########################################################
# MODULE: activate-ssl
#########################################################

cat > "$LIB_DIR/activate-ssl.sh" <<'EOF'
#!/bin/bash

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

DOMAIN="${1:-}"

if [ -z "$DOMAIN" ]; then
    echo "How to Use: lampdeck activate-ssl domain.com"
    exit 1
fi

certbot --apache -d "$DOMAIN"
EOF

chmod +x "$LIB_DIR/activate-ssl.sh"


############################################
# Install assets
############################################

echo "== Creating assets"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

ASSETS_SRC="$SCRIPT_DIR/assets"
ASSETS_DST="/var/www/html/assets"

if [ -d "$ASSETS_SRC" ]; then
    mkdir -p "$ASSETS_DST"
    cp -r "$ASSETS_SRC/"* "$ASSETS_DST/"
    echo "Assets installed."
else
    echo "WARNING: assets folder not found."
fi

if [ -d "$ASSETS_DST" ]; then
    chown -R www-data:www-data "$ASSETS_DST"
    find "$ASSETS_DST" -type d -exec chmod 755 {} \;
    find "$ASSETS_DST" -type f -exec chmod 644 {} \;
fi


#########################################################
# FRONTPAGE
#########################################################

mkdir -p /var/www/html

cat > /var/www/html/index.php <<'EOF'

<?php
/*
===============================================================================
 LAMP Deck v2.x
 ------------------------------------------------------------------------------
 Author: Aurélio Barreto
 E-mail: aurelio@aureliobarreto.com
 Project: https://github.com/albarreto/lampdeck-v2

 Copyright (C) 2026 Aurélio Barreto

 License
 -----------------------------------------------------------------------------
 GNU General Public License v3.0

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License,
 or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 See the GNU General Public License for more details:
 https://www.gnu.org/licenses/gpl-3.0.en.html
===============================================================================
*/

$dirs = array_filter(
    scandir('/var/www'),
    function ($d) {
        if (!isset($d[0]) || $d[0] === '.') {
            return false;
        }

        if (in_array($d, ['html', 'certs'])) {
            return false;
        }

        return is_dir('/var/www/' . $d);
    }
);

sort($dirs);

$serverName = $_SERVER['HTTP_HOST'] ?? 'Servidor';
$totalSites = count($dirs);

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function lampdeck_meta($site) {
    static $cache = [];

    if (isset($cache[$site])) {
        return $cache[$site];
    }

    $file = "/var/www/$site/lampdeck.ini";

    if (!is_file($file) || !is_readable($file)) {
        return $cache[$site] = [];
    }

    $meta = parse_ini_file($file, true, INI_SCANNER_TYPED);

    return $cache[$site] = (is_array($meta) ? $meta : []);
}

function site_desc($site) {
    $meta = lampdeck_meta($site);
    return trim((string)($meta['site']['description'] ?? ''));
}

function detect_app_type($site) {
    $meta = lampdeck_meta($site);
    return strtolower(trim((string)($meta['app']['type'] ?? 'unknown')));
}

function app_type_display_name($type) {
    switch ($type) {
        case 'html':
            return 'HTML/PHP';
        case 'unknown':
            return 'Unknown';
        default:
            return ucfirst($type);
    }
}

function site_icon($site) {
    $type = detect_app_type($site);
    $relative = "/assets/icons/icon-{$type}.webp";
    $absolute = $_SERVER['DOCUMENT_ROOT'] . $relative;

    if (is_file($absolute)) {
        return $relative;
    }

    return "/assets/icons/icon-html.webp";
}

function site_type_label($site) {
    $meta = lampdeck_meta($site);
    $name = trim((string)($meta['app']['name'] ?? 'Unknown'));
    return $name . ' site';
}

function site_admin_path($site) {
    $meta = lampdeck_meta($site);
    return trim((string)($meta['admin']['path'] ?? ''));
}

function site_admin_label($site) {
    $meta = lampdeck_meta($site);
    return trim((string)($meta['admin']['label'] ?? ''));
}

function cmd($command) {
    $out = @shell_exec($command . ' 2>/dev/null');
    return is_string($out) ? trim($out) : '';
}

function format_bytes($bytes) {
    $bytes = (float)$bytes;
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;

    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }

    return number_format($bytes, ($i >= 2 ? 1 : 0), ',', '.') . ' ' . $units[$i];
}

function get_meminfo() {
    $data = @file('/proc/meminfo', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $mem = [];

    if ($data) {
        foreach ($data as $line) {
            if (preg_match('/^([A-Za-z_]+):\s+(\d+)/', $line, $m)) {
                $mem[$m[1]] = (int)$m[2] * 1024;
            }
        }
    }

    $total = $mem['MemTotal'] ?? 0;
    $available = $mem['MemAvailable'] ?? ($mem['MemFree'] ?? 0);
    $used = max(0, $total - $available);

    return [
        'total'   => $total,
        'used'    => $used,
        'free'    => $available,
        'percent' => $total > 0 ? round(($used / $total) * 100) : 0
    ];
}

function get_diskinfo($path = '/') {
    $total = @disk_total_space($path) ?: 0;
    $free  = @disk_free_space($path) ?: 0;
    $used  = max(0, $total - $free);

    return [
        'total'   => $total,
        'used'    => $used,
        'free'    => $free,
        'percent' => $total > 0 ? round(($used / $total) * 100) : 0
    ];
}

function service_status($service) {
    $status = cmd('systemctl is-active ' . escapeshellarg($service));
    return $status !== '' ? $status : 'unknown';
}

function status_class($status) {
    switch ($status) {
        case 'active':
            return 'ok';
        case 'inactive':
        case 'failed':
            return 'bad';
        default:
            return 'warn';
    }
}

function normalize_version($service, $version) {
    $version = trim((string)$version);

    if ($version === '') {
        return '';
    }

    switch ($service) {
        case 'mariadb':
            if (preg_match('/([0-9]+\.[0-9]+\.[0-9]+)/', $version, $m)) {
                return $m[1];
            }
            return rtrim(str_replace('MariaDB', '', $version), ' ,');

        default:
            return rtrim($version, ' ,');
    }
}

function service_version($service) {
    switch ($service) {
        case 'apache2':
            $v = cmd("apache2 -v | awk -F'/' '/Server version/ {print \$2}' | awk '{print \$1}'");
            return normalize_version($service, $v);

        case 'php8.4-fpm':
            return normalize_version($service, PHP_VERSION);

        case 'redis-server':
            $v = cmd("redis-server --version | awk '{for(i=1;i<=NF;i++) if(\$i ~ /^v=/){sub(/^v=/,\"\",\$i); print \$i}}'");
            return normalize_version($service, $v);

        case 'mariadb':
            $v = cmd("mariadb --version");
            return normalize_version($service, $v);

        default:
            return '';
    }
}

$memInfo  = get_meminfo();
$diskInfo = get_diskinfo('/');

$services = [
    ['label' => 'Apache',  'unit' => 'apache2'],
    ['label' => 'PHP',     'unit' => 'php8.4-fpm'],
    ['label' => 'Redis',   'unit' => 'redis-server'],
    ['label' => 'MariaDB', 'unit' => 'mariadb']
];

$appTypes = [];

foreach ($dirs as $d) {
    $type = detect_app_type($d);
    if ($type !== '') {
        $appTypes[$type] = true;
    }
}

ksort($appTypes);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LAMP Deck v__VERSAO__</title>
    <style>
        :root {
            --bg: #0f172a;
            --card: rgba(255,255,255,0.06);
            --card-2: rgba(255,255,255,0.04);
            --border: rgba(255,255,255,0.10);
            --text: #e5e7eb;
            --muted: #94a3b8;
            --primary: #38bdf8;
            --shadow: 0 20px 50px rgba(0,0,0,0.35);
            --ok: #22c55e;
            --bad: #ef4444;
            --warn: #f59e0b;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(14,165,233,0.18), transparent 30%),
                radial-gradient(circle at top left, rgba(34,197,94,0.12), transparent 25%),
                linear-gradient(180deg, var(--bg), #020617);
            color: var(--text);
            min-height: 100vh;
        }

        .container {
            max-width: 1180px;
            margin: 0 auto;
            padding: 28px 18px 42px;
        }

        .hero {
            background: linear-gradient(135deg, rgba(56,189,248,0.16), rgba(255,255,255,0.04));
            border: 1px solid var(--border);
            border-radius: 22px;
            padding: 26px;
            box-shadow: var(--shadow);
        }

        .hero-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 18px;
            flex-wrap: wrap;
        }

        .hero-title {
            min-width: 240px;
            flex: 1 1 280px;
        }

        .hero-title-group {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .hero-text {
            display: flex;
            flex-direction: column;
        }

        .ld-logo {
            height: 50px;
            width: auto;
            object-fit: contain;
        }

        h1 {
            margin: 0;
            font-size: 34px;
            line-height: 1.1;
        }

        .subtitle-mini {
            margin-top: 6px;
            color: var(--muted);
            font-size: 12px;
            letter-spacing: .03em;
        }

        .service-mini-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(120px, 1fr));
            gap: 10px;
            width: min(100%, 560px);
            flex: 0 1 560px;
        }

        .service-mini {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 10px 12px;
            box-shadow: var(--shadow);
            min-height: 58px;
        }

        .service-mini-head {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 4px;
        }

        .service-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            flex: 0 0 10px;
        }

        .service-dot.ok {
            background: var(--ok);
        }

        .service-dot.bad {
            background: var(--bad);
        }

        .service-dot.warn {
            background: var(--warn);
        }

        .service-mini-name {
            font-size: 14px;
            font-weight: 700;
            line-height: 1.2;
        }

        .service-mini-version {
            font-size: 11px;
            color: var(--muted);
            line-height: 1.2;
            padding-left: 18px;
            word-break: break-word;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
            margin-top: 22px;
        }

        .stat {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 16px;
            box-shadow: var(--shadow);
        }

        .stat.compact {
            padding: 12px 14px;
        }

        .stat .label {
            font-size: 12px;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: .06em;
            margin-bottom: 8px;
        }

        .stat .value {
            font-size: 24px;
            font-weight: 700;
            word-break: break-word;
        }

        .resource-block + .resource-block {
            margin-top: 10px;
        }

        .resource-head {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            align-items: baseline;
            margin-bottom: 5px;
        }

        .resource-name {
            font-size: 12px;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: .05em;
        }

        .resource-value {
            font-size: 12px;
            color: var(--text);
            text-align: right;
            font-weight: 400;
        }

        .resource-value strong {
            font-weight: 700;
        }

        .gauge {
            width: 100%;
            height: 7px;
            border-radius: 999px;
            background: rgba(255,255,255,0.08);
            overflow: hidden;
            border: 1px solid rgba(255,255,255,0.06);
        }

        .gauge-bar {
            height: 100%;
            border-radius: 999px;
        }

        .gauge-bar.mem {
            background: linear-gradient(90deg, #38bdf8, #0ea5e9);
        }

        .gauge-bar.disk {
            background: linear-gradient(90deg, #22c55e, #16a34a);
        }

        .tabs {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 24px;
        }

        .tab-button {
            border: 1px solid var(--border);
            background: var(--card);
            color: var(--text);
            padding: 10px 16px;
            border-radius: 999px;
            cursor: pointer;
            font-size: 14px;
            transition: .18s ease;
        }

        .tab-button:hover,
        .tab-button.active {
            background: rgba(56,189,248,0.16);
            border-color: rgba(56,189,248,0.40);
            color: #dff6ff;
        }

        .tab-panel {
            display: none;
            margin-top: 22px;
        }

        .tab-panel.active {
            display: block;
        }

        .section-title {
            margin: 0 0 12px;
            font-size: 22px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 16px;
        }

        .site-card, .tool-card, .cmd-block {
            display: block;
            text-decoration: none;
            color: inherit;
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 18px;
            padding: 18px;
            box-shadow: var(--shadow);
            transition: transform .18s ease, border-color .18s ease, background .18s ease;
        }

        .site-card:hover,
        .tool-card:hover {
            transform: translateY(-3px);
            border-color: rgba(56,189,248,0.45);
            background: rgba(255,255,255,0.08);
        }

        .tool-title, .cmd-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .site-head {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 6px;
        }

        .site-icon-link,
        .site-name-link {
            text-decoration: none;
            color: inherit;
        }

        .site-icon {
            width: 24px;
            height: 24px;
            object-fit: contain;
            flex: 0 0 24px;
            display: block;
        }

        .site-title-row {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .site-name {
            font-size: 20px;
            font-weight: 700;
            margin: 0;
            line-height: 1.2;
        }

        .site-admin-link {
            font-size: 13px;
            color: var(--primary);
            text-decoration: none;
            opacity: 0.95;
        }

        .site-admin-link:hover {
            text-decoration: underline;
            opacity: 1;
        }

        .site-card:hover .site-name {
            color: #dff6ff;
        }

        .site-meta, .tool-desc, .cmd-desc {
            margin-top: 10px;
            font-size: 14px;
            color: var(--muted);
            line-height: 1.5;
        }

        .empty {
            background: var(--card-2);
            border: 1px dashed var(--border);
            border-radius: 18px;
            padding: 24px;
            color: var(--muted);
        }

        .commands {
            display: grid;
            gap: 14px;
        }

        pre {
            margin: 10px 0 0;
            white-space: pre-wrap;
            word-break: break-word;
            background: rgba(0,0,0,0.25);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 12px;
            padding: 12px;
            color: #dbeafe;
            font-size: 13px;
            overflow: auto;
        }

        code {
            background: rgba(255,255,255,0.08);
            padding: 2px 6px;
            border-radius: 6px;
            color: #dbeafe;
        }

        .footer {
            margin-top: 30px;
            color: var(--muted);
            font-size: 13px;
            text-align: center;
        }

        .footer a {
            color: var(--primary);
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 980px) {
            .service-mini-grid {
                width: 100%;
                grid-template-columns: repeat(2, minmax(140px, 1fr));
                flex: 1 1 100%;
            }
        }

        @media (max-width: 640px) {
            h1 { font-size: 28px; }
            .container { padding: 18px 12px 30px; }
            .hero { padding: 18px; }
            .tabs { gap: 8px; }
            .tab-button { width: 100%; text-align: center; }
            .service-mini-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        .update-badge {
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
            padding: 2px 8px;
            color: #0b5ed7;
            background: #e7f1ff;
            border: 1px solid #b6d4fe;
            border-radius: 999px;
            letter-spacing: 0.2px;
            vertical-align: middle;
            white-space: nowrap;
        }

        .filter-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 0 0 18px;
        }

        .filter-button {
            border: 1px solid var(--border);
            background: var(--card);
            color: var(--text);
            padding: 8px 14px;
            border-radius: 999px;
            cursor: pointer;
            font-size: 13px;
            transition: .18s ease;
        }

        .filter-button:hover,
        .filter-button.active {
            background: rgba(56,189,248,0.16);
            border-color: rgba(56,189,248,0.40);
            color: #dff6ff;
        }
    </style>
</head>
<body>
    <div class="container">
        <section class="hero">
            <div class="hero-top">
                <div class="hero-title">
                    <div class="hero-title-group">
                        <img src="/assets/images/logo.webp" class="ld-logo" alt="LAMP Deck logo">
                        <div class="hero-text">
                            <h1>
                                <a href="/" style="color:inherit;text-decoration:none;">
                                    LAMP Deck
                                </a>
                                __UPDATE_BADGE__
                            </h1>

                            <div class="subtitle-mini">
                                Multisite manager for LAMP Servers
                            </div>
                        </div>
                    </div>
                </div>

                <div class="service-mini-grid">
                    <?php foreach ($services as $svc): ?>
                        <?php
                            $status  = service_status($svc['unit']);
                            $version = service_version($svc['unit']);
                            $class   = status_class($status);
                        ?>
                        <div class="service-mini" title="<?= h($svc['label']) ?> <?= h($version ?: 'Unknown') ?> (<?= h($status) ?>)">
                            <div class="service-mini-head">
                                <span class="service-dot <?= h($class) ?>"></span>
                                <div class="service-mini-name"><?= h($svc['label']) ?></div>
                            </div>
                            <div class="service-mini-version"><?= h($version ?: 'Unknown') ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="stats">
                <div class="stat">
                    <div class="label">Host</div>
                    <div class="value"><?= h($serverName) ?></div>
                </div>

                <div class="stat">
                    <div class="label">Websites</div>
                    <div class="value"><?= $totalSites ?></div>
                </div>

                <div class="stat compact">
                    <div class="resource-block">
                        <div class="resource-head">
                            <div class="resource-name">RAM</div>
                            <div class="resource-value">
                                <strong><?= h($memInfo['percent']) ?>%</strong> (<?= h(format_bytes($memInfo['used'])) ?> de <?= h(format_bytes($memInfo['total'])) ?>)
                            </div>
                        </div>

                        <div class="gauge" title="RAM <?= h(format_bytes($memInfo['used'])) ?> / <?= h(format_bytes($memInfo['total'])) ?>">
                            <div class="gauge-bar mem" style="width: <?= (int)$memInfo['percent'] ?>%;"></div>
                        </div>
                    </div>

                    <div class="resource-block">
                        <div class="resource-head">
                            <div class="resource-name">Disk</div>
                            <div class="resource-value">
                                <strong><?= h($diskInfo['percent']) ?>%</strong> (<?= h(format_bytes($diskInfo['used'])) ?> de <?= h(format_bytes($diskInfo['total'])) ?>)
                            </div>
                        </div>

                        <div class="gauge" title="Disk <?= h(format_bytes($diskInfo['used'])) ?> / <?= h(format_bytes($diskInfo['total'])) ?>">
                            <div class="gauge-bar disk" style="width: <?= (int)$diskInfo['percent'] ?>%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tabs">
                <button class="tab-button active" data-tab="sites">Websites</button>
                <button class="tab-button" data-tab="ferramentas">Tools</button>
                <button class="tab-button" data-tab="instrucoes">Instructions</button>
                <button class="tab-button" data-tab="changelog">Changelog</button>
            </div>
        </section>

        <section id="tab-sites" class="tab-panel active">
            <h2 class="section-title">Available Websites</h2>

            <?php if (empty($dirs)): ?>
                <div class="empty">
                    No website folders were found in <code>/var/www</code>.
                </div>
            <?php else: ?>
                <div class="filter-bar">
                    <button class="filter-button active" data-filter="all">All</button>
                    <?php foreach (array_keys($appTypes) as $type): ?>
                        <button class="filter-button" data-filter="<?= h($type) ?>">
                            <?= h(app_type_display_name($type)) ?>
                        </button>
                    <?php endforeach; ?>
                </div>

                <div class="grid">
                    <?php foreach ($dirs as $d): ?>
                        <?php
                            $icon = site_icon($d);
                            $appType = detect_app_type($d);
                            $desc = site_desc($d);
                            $typeLabel = site_type_label($d);
                            $adminPath = site_admin_path($d);
                            $adminLabel = site_admin_label($d);
                        ?>
                        <div class="site-card" data-app-type="<?= h($appType) ?>">
                            <div class="site-head">
                                <a class="site-icon-link" href="/<?= rawurlencode($d) ?>/" target="_blank" rel="noopener noreferrer">
                                    <img
                                        class="site-icon"
                                        src="<?= h($icon) ?>"
                                        alt="<?= h($typeLabel) ?>"
                                        title="<?= h($typeLabel) ?>"
                                    >
                                </a>

                                <div class="site-title-row">
                                    <a class="site-name-link" href="/<?= rawurlencode($d) ?>/" target="_blank" rel="noopener noreferrer">
                                        <div class="site-name"><?= h($d) ?></div>
                                    </a>

                                    <?php if ($adminPath !== ''): ?>
                                        <a
                                            class="site-admin-link"
                                            href="/<?= rawurlencode($d) ?>/<?= h($adminPath) ?>/"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                        >(<?= h($adminLabel) ?>)</a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if ($desc !== ''): ?>
                                <div class="site-meta"><?= h($desc) ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section id="tab-ferramentas" class="tab-panel">
            <h2 class="section-title">Tools</h2>
            <div class="grid">
                <a class="tool-card" href="/phpmyadmin/" target="_blank" rel="noopener noreferrer">
                    <div class="tool-title">phpMyAdmin</div>
                    <div class="tool-desc">Access MariaDB through the browser.</div>
                </a>

                <a class="tool-card" href="/info.php" target="_blank" rel="noopener noreferrer">
                    <div class="tool-title">phpinfo()</div>
                    <div class="tool-desc">Check PHP modules, directives and environment details.</div>
                </a>
            </div>
        </section>

        <section id="tab-instrucoes" class="tab-panel">
            <h2 class="section-title">Instructions</h2>

            <div class="commands">
                <div class="cmd-block">
                    <div class="cmd-title">Create a simple subsite</div>
                    <div class="cmd-desc">Accepts an optional description to be shown on the main page.</div>
                    <pre>lampdeck create-website site1 "Internal system"</pre>
                </div>

                <div class="cmd-block">
                    <div class="cmd-title">Create a full WordPress site</div>
                    <div class="cmd-desc">Also accepts an optional description for the site card.</div>
                    <pre>lampdeck install wordpress wp-site "Corporate WordPress website"</pre>
                </div>

                <div class="cmd-block">
                    <div class="cmd-title">Configure a domain for an existing folder</div>
                    <div class="cmd-desc">Creates Apache vhost for an existing site.</div>
                    <pre>lampdeck create-domain site1.com site1</pre>
                </div>

                <div class="cmd-block">
                    <div class="cmd-title">Enable valid SSL with Let's Encrypt</div>
                    <div class="cmd-desc">Use when the domain is already pointing to the server IP.</div>
                    <pre>lampdeck activate-ssl site1.com</pre>
                </div>
            </div>
        </section>

<!-- xxx -->

        <section id="tab-changelog" class="tab-panel">
            <h2 class="section-title">Changelog</h2>
            <div class="cmd-block">
                <pre>

Version 2.4.2 - 2026-04-17
- Fixed site type detection in "lampdeck sites"

Version 2.4.1 - 2026-04-17
- Standardized app installers using shared app-common.sh
- Unified structure for apps with and without database
- Simplified creation of new app scripts (minimal variables required)
- Unified extraction process using /tmp/app-<slug>-XXXXXX
- Added daily cache to avoid re-downloading packages on the same day
- Improved rollback when installation is cancelled or fails
- Fixed site folder removal when database overwrite is declined
- Fixed Joomla installation path after extraction
- Fixed loading of shared functions from app-common
- Renamed frontpage tab from HTML to HTML/PHP
- Updated frontpage new version alert text

Version 2.4.0 - 2026-04-16
- Frontpage filter by app type (HTML, WordPress, Joomla)
- Improved error message for unsupported apps
- Added confirmation prompt before replacing an existing database
- Existing database is only dropped after user confirmation
- Site folder is now removed if installation is cancelled during database overwrite

Version 2.3.2 - 2026-04-16
- Dashboard notification when a newer version of LAMP Deck is available.

Version 2.3.1 - 2026-04-16
- Fixed MariaDB root password prompt bug
- New optional `-d <domain>` flag in `lampdeck install` to create the domain during app installation.

Version 2.3.0 - 2026-04-15
- Added Joomla installer
- Shared DB validation library for apps
- Improved validation rules for site names
- Admin link support (WordPress, Joomla)
- Improved create-website layout
- Consistent typography in site info cards

Version 2.2.1 - 2026-04-15
- Simplified changelog
- Shared validation and DB logic across apps
- Prevent unnecessary DB password prompt when site exists

Version 2.2.0 - 2026-04-14
- Modular app architecture
- WordPress installer moved to apps/wordpress.sh
- New command: lampdeck install wordpress
- Improved frontpage app detection using .app-type markers
- Improved install flow validation
- Cached WordPress download reused when available

Version 2.1.5 - 2026-04-14
- Frontpage is always preserved when accessing the server by IP
- Domains no longer override the main frontpage
- Improved multisite behavior
- Prevents modification when website folder already exists
- More reliable domain creation
- Improved default website template (light layout)
- Version command now shows Apache, PHP, MariaDB and Redis versions
- Fixed installation phpmyadmin in upgrades
- Fixed logo size in Frontpage
- Fixed phpmyadmin installation
- Fixed installation PHP8.4 packages for Ubuntu releases

Version 2.1.0 - 2026-04-12
- Support for Ubuntu 20.04 LTS (Jammy), 24.04 LTS (Noble)
- Support for Alpine 3.x

Version 2.0.0 - 2026-04-11
- Initial release

                </pre>
            </div>
        </section>

        <div class="footer">
            LAMP Deck v__VERSAO__ (__ID__ __VERSION_CODENAME__)
             <strong>__UPDATE_NOTICE__</strong>
            · © 2026 Aurélio Barreto ·
            <a href="https://github.com/albarreto/lampdeck-v2" target="_blank" rel="noopener noreferrer">GitHub</a>
        </div>
    </div>

    <script>
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabPanels = document.querySelectorAll('.tab-panel');

    tabButtons.forEach((button) => {
        button.addEventListener('click', () => {
            const target = button.dataset.tab;

            tabButtons.forEach((b) => b.classList.remove('active'));
            tabPanels.forEach((p) => p.classList.remove('active'));

            button.classList.add('active');
            document.getElementById('tab-' + target).classList.add('active');
        });
    });

    const filterButtons = document.querySelectorAll('.filter-button');
    const siteCards = document.querySelectorAll('.site-card[data-app-type]');

    filterButtons.forEach((button) => {
        button.addEventListener('click', () => {
            const target = button.dataset.filter;

            filterButtons.forEach((b) => b.classList.remove('active'));
            button.classList.add('active');

            siteCards.forEach((card) => {
                const appType = card.dataset.appType;

                if (target === 'all' || appType === target) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
    </script>
</body>
</html>

EOF

#=== Checking LP for updates

LATEST_VERSION_URL="https://raw.githubusercontent.com/albarreto/lampdeck-v2/main/latest/VERSION"

LATEST_VERSION="$(curl -fsSL "$LATEST_VERSION_URL" 2>/dev/null || true)"

UPDATE_BADGE=""
UPDATE_NOTICE=""

normalize_version() {
    echo "$1" | sed 's/-rc\..*//'
}

LOCAL_BASE="$(normalize_version "$APP_VERSION")"
REMOTE_BASE="$(normalize_version "$LATEST_VERSION")"

if [ -n "$LATEST_VERSION" ]; then

    if [ "$LOCAL_BASE" != "$REMOTE_BASE" ]; then

        LATEST="$(printf '%s\n' "$LOCAL_BASE" "$REMOTE_BASE" | sort -V | tail -n1)"

        if [ "$LATEST" = "$REMOTE_BASE" ]; then
            UPDATE_BADGE="<a href='https://github.com/albarreto/lampdeck-v2' target='_blank''><span class=\"update-badge\">NEW UPDATE AVAILABLE ${LATEST_VERSION}</span></a>"
            UPDATE_NOTICE=" · NEW VERSION AVAILABLE: $LATEST_VERSION"
        fi

    fi
fi

sed -i "s/__VERSAO__/${APP_VERSION}/g" /var/www/html/index.php
sed -i "s/__ID__/${ID}/g" /var/www/html/index.php
sed -i "s/__VERSION_CODENAME__/${VERSION_CODENAME}/g" /var/www/html/index.php
sed -i "s/__UPDATE_NOTICE__/${UPDATE_NOTICE}/g" /var/www/html/index.php
ESCAPED_BADGE=$(printf '%s\n' "$UPDATE_BADGE" | sed 's/[&/\]/\\&/g')
sed -i "s|__UPDATE_BADGE__|${ESCAPED_BADGE}|g" /var/www/html/index.php


#########################################################
# INFO PHP
#########################################################

echo "<?php phpinfo();" > /var/www/html/info.php

#########################################################
# BASH COMPLETION
#########################################################

mkdir -p /etc/bash_completion.d
cat > /etc/bash_completion.d/lampdeck <<'EOF'
_lampdeck_completions()
{
    local cur prev prev2 cmd
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    prev2="${COMP_WORDS[COMP_CWORD-2]}"
    cmd="${COMP_WORDS[1]}"

    local commands="create-website install create-domain activate-ssl sites version help"

    _lampdeck_list_sites()
    {
        if [ -d /var/www ]; then
            find /var/www -mindepth 1 -maxdepth 1 -type d 2>/dev/null \
                | xargs -r -n1 basename \
                | grep -vE '^(html|certs)$'
        fi
    }

    _lampdeck_list_domains()
    {
        if [ -d /etc/apache2/sites-available ]; then
            find /etc/apache2/sites-available -maxdepth 1 -type f -name '*.conf' 2>/dev/null \
                | xargs -r -n1 basename \
                | sed 's/\.conf$//' \
                | grep -vE '^(000-default|default-ssl)$'
        fi
    }

    if [ "$COMP_CWORD" -eq 1 ]; then
        COMPREPLY=( $(compgen -W "$commands" -- "$cur") )
        return 0
    fi

    case "$cmd" in
        create-domain)
            if [ "$COMP_CWORD" -eq 3 ]; then
                COMPREPLY=( $(compgen -W "$(_lampdeck_list_sites)" -- "$cur") )
                return 0
            fi
            ;;
        activate-ssl)
            if [ "$COMP_CWORD" -eq 2 ]; then
                COMPREPLY=( $(compgen -W "$(_lampdeck_list_domains)" -- "$cur") )
                return 0
            fi
            ;;
    esac
}

complete -F _lampdeck_completions lampdeck
EOF

#########################################################
# DISABLE DEFAULT APACHE PAGE
#########################################################

if [ -f /var/www/html/index.html ] && [ ! -f /var/www/html/index_apache.html ]; then
    mv /var/www/html/index.html /var/www/html/index_apache.html
fi

echo
echo "#############################################################"
echo "CONGRATULATIONS!!! ${APP_NAME} v${APP_VERSION} was installed/upgraded."
echo "#############################################################"
echo
echo "How to access:"
echo "  https://${SERVER_IP}/"
echo "  https://${SERVER_IP}/phpmyadmin/"
echo
echo "Installed Commands:"
echo "  lampdeck create-website site1 \"Internal System\""
echo "  lampdeck install wordpress site1 \"Company WordPress Website\""
echo "  lampdeck create-domain site1.com site1"
echo "  lampdeck activate-ssl site1.com"
echo "  lampdeck sites"
echo "  lampdeck version"
echo "  lampdeck help"
echo
echo "Autocompletation for lampdeck was installed."
echo "NOTE: To enable it in the current shell, run: source /etc/bash_completion.d/lampdeck"
echo "      or close and reopen terminal"
echo

