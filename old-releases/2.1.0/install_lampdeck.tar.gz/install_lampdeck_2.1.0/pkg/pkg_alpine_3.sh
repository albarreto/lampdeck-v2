#!/bin/sh

###############################################################################
# LAMP Deck package installer
# Target: Alpine Linux 3.19+
#
# Description:
#   Installs the package set required by LAMP Deck on Alpine Linux
#
# Installs:
#   Apache2
#   PHP-FPM (auto-detected: php84/php83...)
#   MariaDB
#   Redis
#   Certbot
#   phpMyAdmin
#
# Project:
#   LAMP Deck
#   https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
#   GPL-3.0-or-later
###############################################################################

set -eu

install_alpine_packages() {

    export DEBIAN_FRONTEND=noninteractive

    timezone="${TIMEZONE:-America/Maceio}"
    app_version="${APP_VERSION:-2.0.0}"
    hostname_fqdn="${HOSTNAME_FQDN:-server.local}"

    echo "== Updating system"
    apk update
    apk upgrade

    #########################################################
    # BASE
    #########################################################

    echo "== Base packages"
    apk add \
        bash \
        ca-certificates \
        curl \
        wget \
        gnupg \
        unzip \
        zip \
        rsync \
        nano \
        vim \
        htop \
        tar \
        openssl \
        tzdata

    #########################################################
    # TIMEZONE
    #########################################################

    if [ -f "/usr/share/zoneinfo/$timezone" ]; then
        cp "/usr/share/zoneinfo/$timezone" /etc/localtime
        echo "$timezone" > /etc/timezone
    fi

    #########################################################
    # APACHE
    #########################################################

    echo "== Installing Apache"
    apk add apache2 apache2-ssl apache2-proxy

    mkdir -p /run/apache2
    rc-update add apache2 default

    #########################################################
    # PHP (AUTO-DETECT)
    #########################################################

    echo "== Detecting PHP version available"

    PHP_PKG="$(apk search -e 'php8*-fpm' | sort -V | tail -n1 | sed 's/-fpm$//')"

    if [ -z "$PHP_PKG" ]; then
        echo "Error: no supported PHP-FPM package found in Alpine repositories."
        exit 1
    fi

    PHP_SUFFIX="$(echo "$PHP_PKG" | sed 's/^php//')"
    PHP_ETC_DIR="/etc/$PHP_PKG"
    PHP_FPM_SERVICE="php-fpm$PHP_SUFFIX"
    PHP_FPM_SOCK="/run/$PHP_FPM_SERVICE.sock"

    echo "== Using $PHP_PKG"

    apk add \
        "$PHP_PKG" \
        "${PHP_PKG}-fpm" \
        "${PHP_PKG}-opcache" \
        "${PHP_PKG}-mysqli" \
        "${PHP_PKG}-pdo_mysql" \
        "${PHP_PKG}-curl" \
        "${PHP_PKG}-gd" \
        "${PHP_PKG}-intl" \
        "${PHP_PKG}-mbstring" \
        "${PHP_PKG}-xml" \
        "${PHP_PKG}-zip" \
        "${PHP_PKG}-bcmath" \
        "${PHP_PKG}-soap" \
        "${PHP_PKG}-phar" \
        "${PHP_PKG}-session" \
        "${PHP_PKG}-fileinfo" \
        "${PHP_PKG}-tokenizer" \
        "${PHP_PKG}-ctype" \
        "${PHP_PKG}-openssl" \
        "${PHP_PKG}-redis"

    apk add "${PHP_PKG}-pecl-imagick" || true

    rc-update add "$PHP_FPM_SERVICE" default

    #########################################################
    # REDIS
    #########################################################

    echo "== Installing Redis"
    apk add redis
    rc-update add redis default

    #########################################################
    # CERTBOT
    #########################################################

    echo "== Installing Certbot"
    apk add certbot certbot-apache

    #########################################################
    # MARIADB
    #########################################################

    echo "== Installing MariaDB"
    apk add mariadb mariadb-client

    rc-update add mariadb default

    mariadb-install-db --user=mysql --datadir=/var/lib/mysql >/dev/null 2>&1 || true
    mysql_install_db --user=mysql --datadir=/var/lib/mysql >/dev/null 2>&1 || true

    #########################################################
    # START DB ONCE FOR PASSWORD SETUP
    #########################################################

    rc-service mariadb start || true

    #########################################################
    # SET ROOT PASSWORD
    #########################################################

    if [ -n "${DB_ROOT_PASS:-}" ]; then
        echo "== Configuring MariaDB root password"

        mariadb <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT_PASS}';
FLUSH PRIVILEGES;
EOF
    fi

    #########################################################
    # PHP PERFORMANCE
    #########################################################

    PHP_INI_FPM="$PHP_ETC_DIR/php.ini"
    PHP_INI_CLI="$PHP_ETC_DIR/php.ini"

    if [ -f "$PHP_INI_FPM" ]; then
        sed -i 's/^memory_limit = .*/memory_limit = 512M/' "$PHP_INI_FPM" || true
        sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 256M/' "$PHP_INI_FPM" || true
        sed -i 's/^post_max_size = .*/post_max_size = 256M/' "$PHP_INI_FPM" || true
        sed -i 's/^max_execution_time = .*/max_execution_time = 300/' "$PHP_INI_FPM" || true
        sed -i 's/^max_input_vars = .*/max_input_vars = 5000/' "$PHP_INI_FPM" || true
        grep -q "^date.timezone" "$PHP_INI_FPM" \
            && sed -i "s#^date.timezone.*#date.timezone = ${timezone}#" "$PHP_INI_FPM" \
            || echo "date.timezone = ${timezone}" >> "$PHP_INI_FPM"
    fi

    if [ -f "$PHP_INI_CLI" ]; then
        grep -q "^date.timezone" "$PHP_INI_CLI" \
            && sed -i "s#^date.timezone.*#date.timezone = ${timezone}#" "$PHP_INI_CLI" \
            || echo "date.timezone = ${timezone}" >> "$PHP_INI_CLI"
    fi

    #########################################################
    # OPCACHE
    #########################################################

    mkdir -p "$PHP_ETC_DIR/conf.d"

    cat > "$PHP_ETC_DIR/conf.d/00_lampdeck_opcache.ini" <<EOF
zend_extension=opcache
opcache.enable=1
opcache.enable_cli=0
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=40000
opcache.validate_timestamps=1
opcache.revalidate_freq=2
opcache.save_comments=1
EOF

    #########################################################
    # PHP-FPM POOL
    #########################################################

    POOL="$PHP_ETC_DIR/php-fpm.d/www.conf"

    if [ -f "$POOL" ]; then
        sed -i 's/^pm = .*/pm = dynamic/' "$POOL" || true
        sed -i 's/^pm.max_children = .*/pm.max_children = 40/' "$POOL" || true
        sed -i 's/^pm.start_servers = .*/pm.start_servers = 4/' "$POOL" || true
        sed -i 's/^pm.min_spare_servers = .*/pm.min_spare_servers = 2/' "$POOL" || true
        sed -i 's/^pm.max_spare_servers = .*/pm.max_spare_servers = 6/' "$POOL" || true
        grep -q '^pm.max_requests' "$POOL" || echo 'pm.max_requests = 500' >> "$POOL"
        grep -q '^listen =' "$POOL" \
            && sed -i "s#^listen =.*#listen = $PHP_FPM_SOCK#" "$POOL" \
            || echo "listen = $PHP_FPM_SOCK" >> "$POOL"
    fi

    #########################################################
    # MYSQL TUNING
    #########################################################

    mkdir -p /etc/my.cnf.d

    cat > /etc/my.cnf.d/60-wp.cnf <<EOF
[mysqld]

character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

max_connections = 150

innodb_buffer_pool_size = 512M
innodb_log_file_size = 128M
innodb_flush_method = O_DIRECT

table_open_cache = 4000
thread_cache_size = 100

tmp_table_size = 64M
max_heap_table_size = 64M
EOF

    #########################################################
    # WWW BASE
    #########################################################

    mkdir -p /var/www/html
    mkdir -p /var/www/certs

    #########################################################
    # PHPMYADMIN
    #########################################################

    echo "== Installing phpMyAdmin"
    apk add phpmyadmin

    #########################################################
    # SERVERNAME GLOBAL + APACHE CONFIG
    #########################################################

    cat > /etc/apache2/httpd.conf <<EOF
ServerName localhost

LoadModule mpm_event_module modules/mod_mpm_event.so
LoadModule authn_core_module modules/mod_authn_core.so
LoadModule authz_core_module modules/mod_authz_core.so
LoadModule authz_host_module modules/mod_authz_host.so
LoadModule dir_module modules/mod_dir.so
LoadModule mime_module modules/mod_mime.so
LoadModule alias_module modules/mod_alias.so
LoadModule rewrite_module modules/mod_rewrite.so
LoadModule headers_module modules/mod_headers.so
LoadModule expires_module modules/mod_expires.so
LoadModule deflate_module modules/mod_deflate.so
LoadModule env_module modules/mod_env.so
LoadModule setenvif_module modules/mod_setenvif.so
LoadModule ssl_module modules/mod_ssl.so
LoadModule socache_shmcb_module modules/mod_socache_shmcb.so
LoadModule proxy_module modules/mod_proxy.so
LoadModule proxy_fcgi_module modules/mod_proxy_fcgi.so
LoadModule http2_module modules/mod_http2.so

User apache
Group apache

ServerRoot /var/www
DocumentRoot "/var/www/html"

<Directory "/var/www/html">
    AllowOverride All
    Require all granted
    DirectoryIndex index.php index.html
</Directory>

Alias /phpmyadmin /usr/share/webapps/phpmyadmin

<Directory "/usr/share/webapps/phpmyadmin">
    AllowOverride All
    Require all granted
    DirectoryIndex index.php
</Directory>

<FilesMatch \.php$>
    SetHandler "proxy:unix:$PHP_FPM_SOCK|fcgi://localhost/"
</FilesMatch>

Listen 80
Listen 443

IncludeOptional /etc/apache2/conf.d/*.conf
EOF

    mkdir -p /etc/apache2/conf.d

    #########################################################
    # SSL SELF-SIGNED
    #########################################################

    echo "== Checking default self-signed certificate"

    if [ ! -f /var/www/certs/server.crt ] || [ ! -f /var/www/certs/server.key ]; then
        echo "== Generating default self-signed certificate"

        openssl req -x509 -nodes -days 825 \
            -newkey rsa:2048 \
            -keyout /var/www/certs/server.key \
            -out /var/www/certs/server.crt \
            -subj "/C=BR/ST=SE/L=Aracaju/O=Local/CN=$hostname_fqdn"
    else
        echo "== Existing default certificate found. Keeping current files."
    fi

    #########################################################
    # VHOSTS PADRÃO
    #########################################################

    cat > /etc/apache2/conf.d/lampdeck-default.conf <<EOF
<VirtualHost *:80>
    DocumentRoot /var/www/html

    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/\.well-known/acme-challenge/
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
</VirtualHost>

<IfModule mod_ssl.c>
<VirtualHost *:443>
    Protocols h2 http/1.1
    DocumentRoot /var/www/html
    DirectoryIndex index.php index.html

    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch \.php$>
        SetHandler "proxy:unix:$PHP_FPM_SOCK|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile /var/www/certs/server.crt
    SSLCertificateKeyFile /var/www/certs/server.key
</VirtualHost>
</IfModule>
EOF

    #########################################################
    # ALIAS SUBSITES
    #########################################################

    : > /etc/apache2/conf.d/subsites-aliases.conf

    #########################################################
    # PERMISSÕES
    #########################################################

    chown -R apache:apache /var/www

    #########################################################
    # RESTART
    #########################################################

    rc-service redis restart || rc-service redis start
    rc-service "$PHP_FPM_SERVICE" restart || rc-service "$PHP_FPM_SERVICE" start
    rc-service apache2 restart || rc-service apache2 start
    rc-service mariadb restart || rc-service mariadb start

    echo
    echo "============================================"
    echo "Alpine package stack installed."
    echo "============================================"
    echo
}
