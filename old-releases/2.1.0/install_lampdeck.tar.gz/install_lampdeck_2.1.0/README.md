# LAMP Deck

Lightweight multisite manager for LAMP servers.

**LAMP Deck** installs and manages a complete LAMP environment with a
simple dashboard and CLI helpers for fast website deployment.

Focused on simplicity, reproducibility and low resource usage.

<p align="center">
  <img src="https://raw.githubusercontent.com/albarreto/lampdeck-v2/main/screenshots/frontpage.png" width="900">
</p>

## Stack

-   Apache2 (event MPM)
-   PHP 8.4 (FPM)
-   MariaDB
-   Redis
-   phpMyAdmin


## Features

### Core

-   One-command installation
-   Multisite structure in `/var/www`
-   Automatic website listing
-   Lightweight dashboard
-   Minimal resource usage
-   Predictable directory structure

### Site management

-   Fast creation of HTML websites
-   Automatic WordPress installation
-   Automatic database creation for WordPress
-   Optional site description via `.siteinfo`
-   Automatic detection of site type:
    -   HTML
    -   WordPress
-   Direct WP-Admin link in dashboard
-   Optional domain association
-   Optional SSL via Let's Encrypt

### CLI helpers

Examples:

``` bash
lampdeck create-website mysite "Example description"

lampdeck create-wp blog "Company blog"

lampdeck create-domain site1.com site1

lampdeck activate-ssl site1.com
```

### Dashboard

Accessible via server IP:

https://SERVER-IP/

Features:

-   lists all sites in `/var/www`
-   shows description from `.siteinfo`
-   identifies site type automatically
-   quick links to sites
-   quick access to WP-Admin
-   system status indicators

## Requirements

Supported distributions:

-   Debian 12 (Bookworm)
-   Debian 13 (Trixie)
-   Ubuntu 22.04 (Jammy)
-   Ubuntu 24.04 (Noble)
-   Alpine 3.19+

Minimum requirements:

-   root access
-   internet connection
-   recommended clean OS installation


## Installation

Download installer package:

``` bash
wget https://github.com/albarreto/lampdeck-v2/raw/main/latest/install_lampdeck.tar.gz

tar -xzf install_lampdeck.tar.gz

cd install_lampdeck

chmod +x install_lampdeck*.sh

sudo ./install_lampdeck*.sh
```


## Example workflow

Install environment:

``` bash
sudo ./install_lampdeck_*.sh
```

Create HTML website:

``` bash
lampdeck create-website company "Company institutional website"
```

Create WordPress website:

``` bash
lampdeck create-wp blog "Company blog"
```

Access dashboard:

https://SERVER-IP/


## Philosophy

LAMP Deck is designed to be:

-   lightweight
-   fast
-   simple to operate
-   predictable
-   script-friendly
-   easy to maintain
-   easy to automate

Suitable for:

-   development environments
-   small VPS servers
-   multisite WordPress hosting
-   internal tools
-   lab environments
-   self-hosted services

