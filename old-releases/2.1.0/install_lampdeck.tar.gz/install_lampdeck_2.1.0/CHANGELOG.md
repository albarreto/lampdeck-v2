# Changelog

## 2.1.0 - 2026-04-12
- Support for Ubuntu 20.04 LTS (Jammy), 24.04 LTS (Noble)
- Support for Alpine 3.x

## 2.0.0 - 2026-04-11
- Initial release
