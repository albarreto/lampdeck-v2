#!/bin/bash

###############################################################################
# LAMP Deck app module
# wordpress
#
# Description:
# Installs and configures a WordPress site inside the LAMP Deck environment.
# Includes:
# - site name validation
# - database creation
# - WordPress download and extraction
# - wp-config.php configuration
# - Apache rewrite rules
# - permissions setup
#
# Usage:
# lampdeck install wordpress <site-name> [description]
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"

SERVER_IP="$(get_server_ip)"

SITE="$(normalize_site_name "${1:-}")"
DESC="${2:-}"

validate_required_site_name \
    "$SITE" \
    "Usage: lampdeck install wordpress <site-name> [description]" \
    || exit 1

validate_site_name_format "$SITE" || exit 1

DB_NAME="$SITE"
DB_USER="$SITE"
DB_PASS="$(openssl rand -base64 18 | tr -dc 'a-zA-Z0-9' | head -c16)"
BASE="$WWW_ROOT/$SITE"

validate_site_not_exists "$BASE" || exit 1

echo
echo "============================================"
echo "Installing WordPress: $SITE"
echo "============================================"
echo

DB_ROOT_PASS="$(db_prompt_root_password)"

db_validate_root "$DB_ROOT_PASS" || {
    echo "ABORTING installation."
    exit 1
}

echo "Creating base website..."
/usr/local/bin/lampdeck create-website "$SITE" "$DESC"
echo

if ! db_create_database "$DB_ROOT_PASS" "$DB_NAME" "$DB_USER" "$DB_PASS"; then
    echo
    echo "Installation aborted."
    remove_site "$SITE"
    exit 1
fi

unset DB_ROOT_PASS

cd /tmp || exit 1
rm -rf /tmp/wordpress

TMP_TAR="/tmp/wordpress-latest.tar.gz"
DOWNLOAD_WP=1

if [ -f "$TMP_TAR" ] && find "$TMP_TAR" -mtime 0 | grep -q .; then
    DOWNLOAD_WP=0
    echo "Using cached WordPress package (downloaded today)"
fi

if [ "$DOWNLOAD_WP" = "1" ]; then
    echo "Downloading WordPress..."
    cd /tmp || exit 1

    wget \
        --no-use-server-timestamps \
        -O "$TMP_TAR" \
        https://wordpress.org/latest.tar.gz
fi

echo "Extracting WordPress package..."
tar xf "$TMP_TAR"

echo "Copying WordPress files to $BASE..."
rsync -a --delete /tmp/wordpress/ "$BASE/"

cp \
    "$BASE/wp-config-sample.php" \
    "$BASE/wp-config.php"

sed -i "s|database_name_here|$DB_NAME|g" "$BASE/wp-config.php"
sed -i "s|username_here|$DB_USER|g" "$BASE/wp-config.php"
sed -i "s|password_here|$DB_PASS|g" "$BASE/wp-config.php"
sed -i "s|localhost|127.0.0.1|g" "$BASE/wp-config.php"

cat >> "$BASE/wp-config.php" <<EOCFG

define('WP_HOME', 'https://$SERVER_IP/$SITE');
define('WP_SITEURL', 'https://$SERVER_IP/$SITE');
define('WP_REDIS_HOST', '127.0.0.1');

EOCFG

cat > "$BASE/.htaccess" <<EOHT
RewriteEngine On

RewriteBase /$SITE/

RewriteRule ^index\.php$ - [L]

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d

RewriteRule . /$SITE/index.php [L]
EOHT

if [ -n "$DESC" ]; then
    echo "$DESC" > "$BASE/.siteinfo"
fi

echo "wordpress" > "$BASE/.app-type"

chown -R www-data:www-data "$BASE"

find "$BASE" -type d -exec chmod 755 {} \;
find "$BASE" -type f -exec chmod 644 {} \;

chmod -R 775 "$BASE/wp-content"

apache2ctl configtest >/dev/null

systemctl reload apache2

echo
echo "=============================================="
echo "WORDPRESS WEBSITE CREATED"
echo "URL: https://$SERVER_IP/$SITE/"
echo "DB NAME: $DB_NAME"
echo "DB USER: $DB_USER"
echo "PASSWORD: $DB_PASS"
echo
echo "NOTE: Finish installation in the browser"
echo "============================================="
