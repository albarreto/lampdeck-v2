#!/bin/bash

###############################################################################
# LAMP Deck app module
# joomla
#
# Description:
# Installs and configures a Joomla site inside the LAMP Deck environment.
# Includes:
# - site name validation
# - database creation
# - Joomla download and extraction
# - Joomla database pre-configuration
# - permissions setup
#
# Usage:
# lampdeck install joomla <site-name> [description]
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"

SERVER_IP="$(get_server_ip)"

SITE="$(normalize_site_name "${1:-}")"
DESC="${2:-}"

validate_required_site_name \
    "$SITE" \
    "Usage: lampdeck install joomla <site-name> [description]" \
    || exit 1

validate_site_name_format "$SITE" || exit 1

DB_NAME="$SITE"
DB_USER="$SITE"
DB_PASS="$(openssl rand -base64 18 | tr -dc 'a-zA-Z0-9' | head -c16)"
BASE="$WWW_ROOT/$SITE"

validate_site_not_exists "$BASE" || exit 1

echo
echo "============================================"
echo "Installing Joomla: $SITE"
echo "============================================"
echo

DB_ROOT_PASS="$(db_prompt_root_password)"

db_validate_root "$DB_ROOT_PASS" || {
    echo "ABORTING installation."
    exit 1
}

echo "Creating base website..."
/usr/local/bin/lampdeck create-website "$SITE" "$DESC"
echo

db_create_database \
    "$DB_ROOT_PASS" \
    "$DB_NAME" \
    "$DB_USER" \
    "$DB_PASS"

unset DB_ROOT_PASS

#########################################
# download package
#########################################

cd /tmp || exit 1

rm -rf /tmp/joomla

TMP_TAR="/tmp/joomla-latest.tar.gz"
DOWNLOAD_JOOMLA=1

if [ -f "$TMP_TAR" ] && find "$TMP_TAR" -mtime 0 | grep -q .; then
    DOWNLOAD_JOOMLA=0
    echo "Using cached Joomla package (downloaded today)"
fi

if [ "$DOWNLOAD_JOOMLA" = "1" ]; then
    echo "Downloading Joomla..."

    wget \
        --no-use-server-timestamps \
        -O "$TMP_TAR" \
        "https://downloads.joomla.org/cms/joomla6/6-1-0/Joomla_6-1-0-Stable-Full_Package.tar.gz?format=gz"
fi

#########################################
# extract
#########################################

echo "Extracting Joomla package..."
mkdir -p /tmp/joomla
tar xf "$TMP_TAR" -C /tmp/joomla

#########################################
# install files
#########################################

echo "Copying Joomla files to $BASE..."
rsync -a --delete /tmp/joomla/ "$BASE/"

#########################################
# metadata
#########################################

if [ -n "$DESC" ]; then
    echo "$DESC" > "$BASE/.siteinfo"
fi

echo "joomla" > "$BASE/.app-type"

#########################################
# permissions
#########################################

chown -R www-data:www-data "$BASE"

find "$BASE" -type d -exec chmod 755 {} \;
find "$BASE" -type f -exec chmod 644 {} \;

for d in cache administrator/cache images tmp logs; do
    if [ -d "$BASE/$d" ]; then
        chmod -R 775 "$BASE/$d"
    fi
done

#########################################
# apache reload
#########################################

apache2ctl configtest >/dev/null
systemctl reload apache2

#########################################
# output
#########################################

echo
echo "=============================================="
echo "JOOMLA WEBSITE CREATED"
echo "URL: https://$SERVER_IP/$SITE/"
echo "DB NAME: $DB_NAME"
echo "DB USER: $DB_USER"
echo "PASSWORD: $DB_PASS"
echo
echo "NOTE: Finish installation in the browser"
echo "============================================="
