#!/bin/bash

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")" && pwd)}"

source "$LIB_DIR/common.sh"

SITE="${1:-}"

if [ -z "$SITE" ]; then
    echo "Usage: lampdeck recover <site>"
    exit 1
fi

BASE="$WWW_ROOT/$SITE"

if [ ! -d "$BASE" ]; then
    echo "Error: site not found: $SITE"
    exit 1
fi

if grep -q "Alias /$SITE/" "$SUBSITES_CONF" 2>/dev/null; then
    echo "Alias already exists for $SITE"
    exit 0
fi

{
    echo "RedirectMatch 301 ^/$SITE\$ /$SITE/"
    echo "Alias /$SITE/ $BASE/"
    echo
    echo "<Directory $BASE>"
    echo "    AllowOverride All"
    echo "    Require all granted"
    echo "    Options FollowSymLinks"
    echo "</Directory>"
    echo
} >> "$SUBSITES_CONF"

apache_reload

echo
echo "Site recovered successfully:"
echo "  https://${HOSTNAME_FQDN:-$(get_server_ip)}/$SITE/"
echo
