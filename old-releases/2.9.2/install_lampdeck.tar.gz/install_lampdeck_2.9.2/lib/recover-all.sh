#!/bin/bash

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")" && pwd)}"

source "$LIB_DIR/common.sh"

FOUND=0

for base in "$WWW_ROOT"/*; do

    [ -d "$base" ] || continue

    site="$(basename "$base")"

    case "$site" in
        html|certs|localhost|logs|run|modules|*.disabled)
            continue
            ;;
    esac

    FOUND=1

    if grep -q "Alias /$site/" "$SUBSITES_CONF" 2>/dev/null; then
        echo "SKIPPED: $site (already exists)"
        continue
    fi

    {
        echo "RedirectMatch 301 ^/$site\$ /$site/"
        echo "Alias /$site/ $base/"
        echo
        echo "<Directory $base>"
        echo "    AllowOverride All"
        echo "    Require all granted"
        echo "    Options FollowSymLinks"
        echo "</Directory>"
        echo
    } >> "$SUBSITES_CONF"

    echo "RECOVERED: $site"

done

if [ "$FOUND" -eq 0 ]; then
    echo "No websites found."
    exit 0
fi

apache_reload

echo
echo "All missing aliases were recovered successfully."
echo
