#!/bin/bash

###############################################################################
# LAMP Deck app module
# moodle
#
# Description:
# Installs and configures a Moodle LMS instance
#
# Usage:
# lampdeck install moodle <site-name> [description]
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="moodle"
APP_NAME="Moodle"
APP_HAS_DB="1"
APP_CATEGORY="Education"
APP_WEBROOT="public"
APP_ADMIN_PATH="admin"
APP_ADMIN_LABEL="Admin"

# Moodle stable branch
APP_CACHE_FILE="/tmp/moodle-latest.zip"
APP_DOWNLOAD_URL="https://packaging.moodle.org/stable502/moodle-latest-502.zip"

#########################################
# supported PHP versions
#########################################

MOODLE_MIN_PHP="8.2"
MOODLE_MAX_PHP="8.4"

PHP_VERSION="${PHP_RUNTIME_VERSION:-$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')}"

version_ge() {
    [ "$(printf '%s\n' "$2" "$1" | sort -V | head -n1)" = "$2" ]
}

version_le() {
    [ "$(printf '%s\n' "$1" "$2" | sort -V | head -n1)" = "$1" ]
}

if ! version_ge "$PHP_VERSION" "$MOODLE_MIN_PHP" || \
   ! version_le "$PHP_VERSION" "$MOODLE_MAX_PHP"; then

    echo
    echo "ERROR: Moodle is currently incompatible with this PHP version."
    echo
    echo "Detected PHP version : $PHP_VERSION"
    echo "Supported range      : $MOODLE_MIN_PHP to $MOODLE_MAX_PHP"
    echo
    echo "This limitation comes from current Moodle upstream compatibility."
    echo "Support for newer PHP versions may be added in future Moodle releases."
    echo
    exit 1
fi

#########################################
# PREPARE
#########################################

app_prepare_with_db "${1:-}" "${2:-}"

#########################################
# package
#########################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"

app_init_tmp_dir
app_extract_archive "moodle"
app_copy_files_to_base

echo "Installing Composer dependencies..."

if command -v apt >/dev/null 2>&1; then
    apt install -y composer
elif command -v apk >/dev/null 2>&1; then
    apk add composer
fi

cd "$BASE"

COMPOSER_ALLOW_SUPERUSER=1 composer install \
    --no-dev \
    --classmap-authoritative \
    --no-interaction \
    --prefer-dist

#########################################
# moodle config
#########################################

MOODLEDATA="$BASE/moodledata"

mkdir -p "$MOODLEDATA"

cat > "$BASE/config.php" <<EOF
<?php
unset(\$CFG);
global \$CFG;
\$CFG = new stdClass();

\$CFG->dbtype    = 'mariadb';
\$CFG->dblibrary = 'native';
\$CFG->dbhost    = 'localhost';
\$CFG->dbname    = '$DB_NAME';
\$CFG->dbuser    = '$DB_USER';
\$CFG->dbpass    = '$DB_PASS';
\$CFG->prefix    = 'mdl_';

\$CFG->dboptions = array(
    'dbpersist' => false,
    'dbport' => '',
    'dbsocket' => '',
    'dbcollation' => 'utf8mb4_unicode_ci',
);

\$CFG->wwwroot   = 'https://' . \$_SERVER['HTTP_HOST'] . '/$SITE';

\$CFG->dataroot  = '$MOODLEDATA';

\$CFG->admin     = 'admin';

\$CFG->directorypermissions = 02770;

require_once(__DIR__ . '/public/lib/setup.php');
EOF

#########################################
# language packs
#########################################

echo "Installing Moodle language packs..."

mkdir -p "$BASE/lang"

MOODLE_LANGS=(
    pt_br
    es
    fr
    de
)

cd /tmp

for lang in "${MOODLE_LANGS[@]}"
do
    echo "Downloading language pack: $lang"
    wget -q -O "${lang}.zip" \
        "https://download.moodle.org/download.php/direct/langpack/5.2/${lang}.zip"
    unzip -oq "${lang}.zip" -d "$MOODLEDATA/lang"
    rm -f "${lang}.zip"
    echo "...done"
done

#########################################
# permissions
#########################################

echo "Applying permissions..."

app_apply_default_permissions

chown -R "$WEB_USER:$WEB_GROUP" "$MOODLEDATA"

chmod -R 770 "$MOODLEDATA"

app_apply_rw_permissions "$MOODLEDATA"


#########################################
# metadata
#########################################

app_write_metadata "$APP_SLUG"

#########################################
# cron
#########################################

echo "Configuring Moodle cron..."

MOODLE_CRON="$BASE/admin/cli/cron.php"

if command -v apt >/dev/null 2>&1; then

    CRON_FILE="/etc/cron.d/lampdeck-moodle-${SITE}"

    cat > "$CRON_FILE" <<EOF
* * * * * $WEB_USER /usr/bin/php $MOODLE_CRON >/dev/null 2>&1
EOF

    chmod 644 "$CRON_FILE"

elif command -v apk >/dev/null 2>&1; then

    mkdir -p /etc/crontabs

    CRON_USER="${WEB_USER:-apache}"
    CRON_FILE="/etc/crontabs/$CRON_USER"

    touch "$CRON_FILE"

    if ! grep -q "$MOODLE_CRON" "$CRON_FILE"; then
        echo "* * * * * /usr/bin/php $MOODLE_CRON >/dev/null 2>&1" >> "$CRON_FILE"
    fi

    rc-update add crond default >/dev/null 2>&1 || true
    rc-service crond start >/dev/null 2>&1 || true
    rc-service crond restart >/dev/null 2>&1 || true

fi

#########################################
# apache reload
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

app_print_success_with_db

echo "Moodle cron configured."
echo

