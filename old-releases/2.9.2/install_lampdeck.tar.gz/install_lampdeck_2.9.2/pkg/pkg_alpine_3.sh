#!/bin/bash

###############################################################################
# LAMP Deck package installer
# Target: Alpine Linux 3.19+
#
# Description:
#   Installs the package set required by LAMP Deck on Alpine Linux
#
# Installs:
#   Apache2
#   PHP-FPM (native from Alpine repositories)
#   MariaDB
#   Redis
#   Certbot
#   phpMyAdmin (temporarily disabled on Alpine)
#
# Project:
#   LAMP Deck
#   https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
#   GPL-3.0-or-later
###############################################################################

set -euo pipefail

PKG_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PKG_SCRIPT_DIR/../lib/pkg_common.sh"

# Alpine uses native PHP packages.
# This value is informational only; the actual installed PHP version comes from apk.
PHP_VERSION="native"

if [ "$PHP_VERSION" = "native" ]; then
    PHP_VERSION="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
fi

### Set PHP version on config
echo "PHP_RUNTIME_VERSION=\"$PHP_VERSION\"" >> /etc/lampdeck/config.sh
    
install_packages() {

    local timezone="${TIMEZONE:-America/Maceio}"
    local app_version="${APP_VERSION:-2.0.0}"
    local hostname_fqdn="${HOSTNAME_FQDN:-server.local}"

    #########################################################
    # APK REPOSITORIES
    #########################################################

    local alpine_branch

    alpine_branch="$(cut -d. -f1,2 /etc/alpine-release)"

    cat > /etc/apk/repositories <<EOF
http://dl-cdn.alpinelinux.org/alpine/v${alpine_branch}/main
http://dl-cdn.alpinelinux.org/alpine/v${alpine_branch}/community
EOF

    echo "== Updating system"
    apk update
    apk upgrade

    #########################################################
    # BASE PACKAGES
    #########################################################

    echo "== Base packages"
    apk add \
        bash \
        bash-completion \
        ca-certificates \
        curl \
        wget \
        gnupg \
        unzip \
        zip \
        bzip2 \
        rsync \
        nano \
        vim \
        htop \
        tar \
        openssl \
        tzdata \
        shadow

        if command -v chsh >/dev/null 2>&1; then
            chsh -s /bin/bash root || true
        fi

    #########################################################
    # TIMEZONE
    #########################################################

    if [ -f "/usr/share/zoneinfo/$timezone" ]; then
        cp "/usr/share/zoneinfo/$timezone" /etc/localtime
        echo "$timezone" > /etc/timezone
    fi

    #########################################################
    # APACHE
    #########################################################

    echo "== Installing Apache"
    apk add \
        apache2 \
        apache2-ssl \
        apache2-proxy \
        apache2-http2

    mkdir -p /run/apache2
    rc-update add apache2 default

    #########################################################
    # PHP NATIVE
    #########################################################

    echo "== Installing PHP from Alpine native repositories"

    apk add \
        php \
        php-cli \
        php-fpm \
        php-opcache \
        php-mysqli \
        php-pdo \
        php-pdo_mysql \
        php-curl \
        php-gd \
        php-intl \
        php-mbstring \
        php-xml \
        php-zip \
        php-bcmath \
        php-soap \
        php-phar \
        php-session \
        php-fileinfo \
        php-tokenizer \
        php-ctype \
        php-openssl \
        php-dom \
        php-xmlreader \
        php-simplexml \
        php-iconv \
        php-redis \
        php-gmp \
        php-apcu \
        php-bz2 \
        php-xmlwriter \
        php-pcntl \
        php-posix \
        php-ldap \
        php-sodium \
        php-exif

    apk add php-pecl-imagick || true

    local php_mm
    local php_etc_dir
    local php_fpm_service
    local php_fpm_sock

    php_mm="$(php -r 'echo PHP_MAJOR_VERSION . PHP_MINOR_VERSION;')"
    php_etc_dir="/etc/php${php_mm}"
    php_fpm_service="php-fpm${php_mm}"
    php_fpm_sock="/run/php-fpm.sock"

    echo "== Using native Alpine PHP php${php_mm}"

    rc-update add "$php_fpm_service" default

    #########################################################
    # CRON
    #########################################################

    echo "== Installing cron"
    apk add dcron
    mkdir -p /etc/cron.d
    rc-update add crond default
    rc-service crond start || true

    #########################################################
    # REDIS
    #########################################################

    echo "== Installing Redis"
    apk add redis
    rc-update add redis default

    #########################################################
    # CERTBOT
    #########################################################

    echo "== Installing Certbot"
    apk add certbot certbot-apache

    #########################################################
    # MARIADB
    #########################################################

    echo "== Installing MariaDB"
    apk add mariadb mariadb-client

    rc-update add mariadb default

    mariadb-install-db --user=mysql --datadir=/var/lib/mysql >/dev/null 2>&1 || true
    mysql_install_db --user=mysql --datadir=/var/lib/mysql >/dev/null 2>&1 || true

    #########################################################
    # START DATABASE FOR INITIAL CONFIGURATION
    #########################################################

    rc-service mariadb start || true

    #########################################################
    # SET ROOT PASSWORD
    #########################################################

    if [ -n "${DB_ROOT_PASS:-}" ]; then
        echo "== Configuring MariaDB root password"

        if mariadb -u root -e "SELECT 1" >/dev/null 2>&1; then
            mariadb -u root <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT_PASS}';
FLUSH PRIVILEGES;
EOF

        elif mariadb -u root -p"${DB_ROOT_PASS}" -e "SELECT 1" >/dev/null 2>&1; then
            echo "MariaDB root password already configured."

        else
            echo "ERROR: Cannot authenticate to MariaDB root."
            echo "Use the current MariaDB root password when reinstalling."
            exit 1
        fi
    fi

    #########################################################
    # AJUSTES PHP PERFORMANCE / ENTERPRISE APPS
    #########################################################

    local php_ini="$php_etc_dir/php.ini"

    if [ -f "$php_ini" ]; then
        sed -i 's/^memory_limit = .*/memory_limit = 512M/' "$php_ini"
        sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 256M/' "$php_ini"
        sed -i 's/^post_max_size = .*/post_max_size = 256M/' "$php_ini"
        sed -i 's/^max_execution_time = .*/max_execution_time = 300/' "$php_ini"
        sed -i 's/^max_input_time = .*/max_input_time = 300/' "$php_ini"
        sed -i 's/^;*max_input_vars = .*/max_input_vars = 5000/' "$php_ini" || true

        grep -q "^date.timezone" "$php_ini" \
            && sed -i "s#^date.timezone.*#date.timezone = ${timezone}#" "$php_ini" \
            || echo "date.timezone = ${timezone}" >> "$php_ini"
    fi

    #########################################################
    # OPCACHE
    #########################################################

    mkdir -p "$php_etc_dir/conf.d"

cat > "$php_etc_dir/conf.d/00_lampdeck_opcache.ini" <<EOF
opcache.enable=1
opcache.enable_cli=0
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=40000
opcache.validate_timestamps=1
opcache.revalidate_freq=2
opcache.save_comments=1
EOF

    #########################################################
    # PHP-FPM POOL
    #########################################################

    local pool="$php_etc_dir/php-fpm.d/www.conf"

    if [ -f "$pool" ]; then
        sed -i "s/^user = .*/user = ${WEB_USER}/" "$pool" || true
        sed -i "s/^group = .*/group = ${WEB_GROUP}/" "$pool" || true
        sed -i "s#^listen = .*#listen = ${php_fpm_sock}#" "$pool" || true
        sed -i 's/^pm = .*/pm = dynamic/' "$pool" || true
        sed -i 's/^pm.max_children = .*/pm.max_children = 40/' "$pool" || true
        sed -i 's/^pm.start_servers = .*/pm.start_servers = 4/' "$pool" || true
        sed -i 's/^pm.min_spare_servers = .*/pm.min_spare_servers = 2/' "$pool" || true
        sed -i 's/^pm.max_spare_servers = .*/pm.max_spare_servers = 6/' "$pool" || true

        grep -q '^pm.max_requests' "$pool" || echo 'pm.max_requests = 500' >> "$pool"
        grep -q '^listen.owner' "$pool" \
            && sed -i "s/^listen.owner = .*/listen.owner = ${WEB_USER}/" "$pool" \
            || echo "listen.owner = ${WEB_USER}" >> "$pool"

        grep -q '^listen.group' "$pool" \
            && sed -i "s/^listen.group = .*/listen.group = ${WEB_GROUP}/" "$pool" \
            || echo "listen.group = ${WEB_GROUP}" >> "$pool"

        grep -q '^listen.mode' "$pool" \
            && sed -i 's/^listen.mode = .*/listen.mode = 0660/' "$pool" \
            || echo 'listen.mode = 0660' >> "$pool"
    fi

    #########################################################
    # MYSQL TUNING
    #########################################################

    mkdir -p /etc/my.cnf.d

    cat > /etc/my.cnf.d/60-wp.cnf <<EOF
[mysqld]

character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

max_connections = 150

innodb_buffer_pool_size = 512M
innodb_log_file_size = 128M
innodb_flush_method = O_DIRECT

table_open_cache = 4000
thread_cache_size = 100

tmp_table_size = 64M
max_heap_table_size = 64M
EOF

    #########################################################
    # WWW BASE
    #########################################################

    mkdir -p /var/www/html
    mkdir -p /var/www/certs
    ln -snf /usr/lib/apache2 /var/www/modules
    ln -snf /var/log/apache2 /var/www/logs
    ln -snf /run/apache2 /var/www/run

    #########################################################
    # PHPMYADMIN
    #########################################################

    echo "== Installing phpMyAdmin"

    local pma_version="5.2.3"
    local pma_file="phpMyAdmin-${pma_version}-all-languages.tar.gz"

    mkdir -p /tmp/lampdeck
    cd /tmp/lampdeck

    if [ ! -f "${pma_file}" ]; then

        wget -O "${pma_file}" \
            "https://files.phpmyadmin.net/phpMyAdmin/${pma_version}/${pma_file}"
    fi

    rm -rf /usr/share/webapps/phpmyadmin

    mkdir -p /usr/share/webapps/phpmyadmin

    tar -xzf "${pma_file}" \
        --strip-components=1 \
        -C /usr/share/webapps/phpmyadmin

    mkdir -p /usr/share/webapps/phpmyadmin/tmp

    cat > /usr/share/webapps/phpmyadmin/config.inc.php <<EOF
<?php

\$cfg['blowfish_secret'] = '$(openssl rand -hex 16)';

\$i = 1;

\$cfg['Servers'][\$i]['auth_type'] = 'cookie';
\$cfg['Servers'][\$i]['host'] = 'localhost';
\$cfg['Servers'][\$i]['compress'] = false;
\$cfg['Servers'][\$i]['AllowNoPassword'] = false;

\$cfg['Servers'][\$i]['pmadb'] = 'phpmyadmin';

\$cfg['Servers'][\$i]['bookmarktable'] = 'pma__bookmark';
\$cfg['Servers'][\$i]['relation'] = 'pma__relation';
\$cfg['Servers'][\$i]['table_info'] = 'pma__table_info';
\$cfg['Servers'][\$i]['table_coords'] = 'pma__table_coords';
\$cfg['Servers'][\$i]['pdf_pages'] = 'pma__pdf_pages';
\$cfg['Servers'][\$i]['column_info'] = 'pma__column_info';
\$cfg['Servers'][\$i]['history'] = 'pma__history';
\$cfg['Servers'][\$i]['table_uiprefs'] = 'pma__table_uiprefs';
\$cfg['Servers'][\$i]['tracking'] = 'pma__tracking';
\$cfg['Servers'][\$i]['userconfig'] = 'pma__userconfig';
\$cfg['Servers'][\$i]['recent'] = 'pma__recent';
\$cfg['Servers'][\$i]['favorite'] = 'pma__favorite';
\$cfg['Servers'][\$i]['users'] = 'pma__users';
\$cfg['Servers'][\$i]['usergroups'] = 'pma__usergroups';
\$cfg['Servers'][\$i]['navigationhiding'] = 'pma__navigationhiding';
\$cfg['Servers'][\$i]['savedsearches'] = 'pma__savedsearches';
\$cfg['Servers'][\$i]['central_columns'] = 'pma__central_columns';
\$cfg['Servers'][\$i]['designer_settings'] = 'pma__designer_settings';
\$cfg['Servers'][\$i]['export_templates'] = 'pma__export_templates';

\$cfg['TempDir'] = '/usr/share/webapps/phpmyadmin/tmp';
EOF

    chown -R ${WEB_USER}:${WEB_GROUP} /usr/share/webapps/phpmyadmin

    chmod 777 /usr/share/webapps/phpmyadmin/tmp

    cat > /etc/apache2/conf.d/phpmyadmin.conf <<EOF
Alias /phpmyadmin /usr/share/webapps/phpmyadmin

<Directory /usr/share/webapps/phpmyadmin>
    AllowOverride All
    Require all granted
</Directory>
EOF

    echo "== Configuring phpMyAdmin database"

    if [ -z "${DB_ROOT_PASS:-}" ]; then

        echo "WARNING: DB_ROOT_PASS not provided."
        echo "Skipping phpMyAdmin internal database configuration."

    else

        local pma_db="phpmyadmin"
        local pma_user="phpmyadmin"
        local pma_pass="${DB_ROOT_PASS}"

        mariadb -u root -p"${DB_ROOT_PASS}" <<EOF
CREATE DATABASE IF NOT EXISTS \`${pma_db}\`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '${pma_user}'@'localhost'
IDENTIFIED BY '${pma_pass}';

ALTER USER '${pma_user}'@'localhost'
IDENTIFIED BY '${pma_pass}';

GRANT ALL PRIVILEGES
ON \`${pma_db}\`.*
TO '${pma_user}'@'localhost';

FLUSH PRIVILEGES;
EOF

        if [ -f /usr/share/webapps/phpmyadmin/sql/create_tables.sql ]; then

            mariadb -u root -p"${DB_ROOT_PASS}" "${pma_db}" \
                < /usr/share/webapps/phpmyadmin/sql/create_tables.sql

        else
            echo "WARNING: phpMyAdmin internal SQL file not found."
        fi

        mkdir -p /etc/phpmyadmin

        cat > /etc/phpmyadmin/config-db.php <<EOF
<?php
\$dbserver='localhost';
\$dbport='';
\$dbuser='${pma_user}';
\$dbpass='${pma_pass}';
\$basepath='';
\$dbname='${pma_db}';
\$dbtype='mysqli';
EOF

    fi


    #########################################################
    # APACHE CONFIG
    #########################################################

    mkdir -p /etc/apache2/conf.d

    rm -f /etc/apache2/conf.d/proxy.conf
    rm -f /etc/apache2/conf.d/ssl.conf
    rm -f /etc/apache2/conf.d/php*-module.conf
    rm -f /etc/apache2/conf.d/lampdeck-*.conf

    sed -i 's#^DocumentRoot ".*"#DocumentRoot "/var/www/html"#' /etc/apache2/httpd.conf || true

    # Normalize Apache listeners. Alpine may not enable 443 by default.
    grep -q '^Listen 80$' /etc/apache2/httpd.conf || echo 'Listen 80' >> /etc/apache2/httpd.conf
    grep -q '^Listen 443$' /etc/apache2/httpd.conf || echo 'Listen 443' >> /etc/apache2/httpd.conf

    # Avoid duplicated module declarations from previous installer runs.
    for module in rewrite proxy proxy_fcgi headers expires ssl deflate alias dir mime env http2; do
        sed -i "/^[#[:space:]]*LoadModule ${module}_module /d" /etc/apache2/httpd.conf || true
    done

    # Alpine Apache module loading required by LAMP Deck.
    apache_load_module_once "LoadModule rewrite_module modules/mod_rewrite.so"
    apache_load_module_once "LoadModule proxy_module modules/mod_proxy.so"
    apache_load_module_once "LoadModule proxy_fcgi_module modules/mod_proxy_fcgi.so"
    apache_load_module_once "LoadModule headers_module modules/mod_headers.so"
    apache_load_module_once "LoadModule expires_module modules/mod_expires.so"
    apache_load_module_once "LoadModule ssl_module modules/mod_ssl.so"
    apache_load_module_once "LoadModule deflate_module modules/mod_deflate.so"
    apache_load_module_once "LoadModule alias_module modules/mod_alias.so"
    apache_load_module_once "LoadModule dir_module modules/mod_dir.so"
    apache_load_module_once "LoadModule mime_module modules/mod_mime.so"
    apache_load_module_once "LoadModule env_module modules/mod_env.so"

    sed -i 's/^#LoadModule mpm_event_module /LoadModule mpm_event_module /' /etc/apache2/httpd.conf || true
    sed -i 's/^LoadModule mpm_prefork_module /#LoadModule mpm_prefork_module /' /etc/apache2/httpd.conf || true

    if ! grep -q '^ServerName ' /etc/apache2/httpd.conf; then
        printf '\nServerName localhost\n' >> /etc/apache2/httpd.conf
    fi

    if ! grep -q '<Directory "/var/www/html">' /etc/apache2/httpd.conf; then
        cat >> /etc/apache2/httpd.conf <<EOF

<Directory "/var/www/html">
    AllowOverride All
    Require all granted
    DirectoryIndex index.php index.html
</Directory>
EOF
    fi

    cat > /etc/apache2/conf.d/lampdeck-php-fpm.conf <<EOF
<FilesMatch \.php$>
    SetHandler "proxy:unix:$php_fpm_sock|fcgi://localhost/"
</FilesMatch>
EOF

    #########################################################
    # SSL SELF-SIGNED DEFAULT CERTIFICATE
    #########################################################

    echo "== Checking default self-signed certificate"

    if [ ! -f /var/www/certs/server.crt ] || [ ! -f /var/www/certs/server.key ]; then
        echo "== Generating default self-signed certificate"

        openssl req -x509 -nodes -days 825 \
            -newkey rsa:2048 \
            -keyout /var/www/certs/server.key \
            -out /var/www/certs/server.crt \
            -subj "/C=BR/ST=SE/L=Aracaju/O=Local/CN=$hostname_fqdn"
    else
        echo "== Existing default certificate found. Keeping current files."
    fi

    #########################################################
    # DEFAULT VHOSTS
    #########################################################

    cat > /etc/apache2/conf.d/000-lampdeck-default.conf <<EOF
<VirtualHost _default_:80>
    ServerName localhost
    DocumentRoot /var/www/html
    DirectoryIndex index.php index.html

    IncludeOptional /etc/apache2/conf.d/subsites-aliases.conf

    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>

<VirtualHost _default_:443>
    ServerName localhost
    DocumentRoot /var/www/html
    DirectoryIndex index.php index.html

        IncludeOptional /etc/apache2/conf.d/subsites-aliases.conf

    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch \.php$>
        SetHandler "proxy:unix:${php_fpm_sock}|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile /var/www/certs/server.crt
    SSLCertificateKeyFile /var/www/certs/server.key
</VirtualHost>
EOF

    #########################################################
    # ALIAS SUBSITES
    #########################################################

    if [ ! -f /etc/apache2/conf.d/subsites-aliases.conf ]; then
        : > /etc/apache2/conf.d/subsites-aliases.conf
    fi

    #########################################################
    # PERMISSIONS
    #########################################################

    chown -R "$WEB_USER:$WEB_GROUP" /var/www

    #########################################################
    # RESTART
    #########################################################

    rc-service mariadb restart || rc-service mariadb start
    rc-service redis restart || rc-service redis start

    mkdir -p /run/php-fpm
    chown ${WEB_USER}:${WEB_GROUP} /run/php-fpm

    rc-service "$php_fpm_service" restart || rc-service "$php_fpm_service" start

    rc-service apache2 restart || rc-service apache2 start

    echo
    echo "============================================"
    echo "Alpine package stack installed."
    echo "============================================"
    echo
}
