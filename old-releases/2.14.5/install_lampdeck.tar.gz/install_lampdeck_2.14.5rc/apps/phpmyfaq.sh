#!/bin/bash

###############################################################################
# LAMP Deck app module
# phpmyfaq
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="phpmyfaq"
APP_NAME="phpMyFAQ"
APP_HAS_DB="1"
APP_CATEGORY="Documentation"
APP_ADMIN_PATH="admin"
APP_ADMIN_LABEL="Admin"
APP_DOWNLOAD_URL="https://download.phpmyfaq.de/phpMyFAQ-4.1.6.tar.gz"

app_prepare_with_db "${1:-}" "${2:-}"

#########################################
# package
#########################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"

app_init_tmp_dir
app_extract_archive

EXTRACTED_DIR="$(find "$APP_TMP_DIR" -mindepth 1 -maxdepth 1 -type d | head -n 1)"

if [ -z "${EXTRACTED_DIR:-}" ]; then
    echo -e "${RED}Error: extracted directory not found${NC}"
    exit 1
fi

cp -a "$EXTRACTED_DIR"/. "$BASE"/

#########################################
# Apache subdirectory configuration
#########################################

if [ -f "$BASE/.htaccess" ]; then
    sed -i \
        "s|^[[:space:]]*RewriteBase[[:space:]].*$|    RewriteBase /$SITE/|" \
        "$BASE/.htaccess"

    sed -i \
        "s|^[[:space:]]*ErrorDocument[[:space:]]\+404[[:space:]]\+/index\.php|    ErrorDocument 404 /$SITE/index.php|" \
        "$BASE/.htaccess"
fi

#########################################
# permissions
#########################################

app_apply_default_permissions

app_apply_rw_permissions \
    "$BASE/content" \
    "$BASE/images" \
    "$BASE/data" \
    "$BASE/attachments"

#########################################
# metadata
#########################################

app_write_metadata "$APP_SLUG"

#########################################
# apache reload
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

app_print_success_with_db

