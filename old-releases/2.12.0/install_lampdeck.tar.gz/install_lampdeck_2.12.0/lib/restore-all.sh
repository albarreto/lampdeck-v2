#!/bin/bash

###############################################################################
# LAMP Deck module
# restore-all
#
# Description:
# Restores the latest backup of all websites.
###############################################################################

set -euo pipefail

BACKUP_ROOT="/var/backups/lampdeck"

echo
echo "============================================"
echo "LAMP Deck Restore-All"
echo "============================================"
echo
echo "WARNING"
echo "------------------------------------------------"
echo
echo "THIS OPERATION MAY DESTROY YOUR DATA"
echo
echo "All websites may be overwritten."
echo "All databases may be overwritten."
echo
echo "------------------------------------------------"
echo

read -r -p "Type RESTORE to continue: " CONFIRM

if [ "$CONFIRM" != "RESTORE" ]; then
    echo
    echo "Restore cancelled."
    exit 0
fi

find "$BACKUP_ROOT" -mindepth 2 -maxdepth 2 -name "*.tar.gz" \
| sort \
| while read -r backup
do
    SITE="$(basename "$(dirname "$backup")")"

    LATEST="$(ls -1 "/var/backups/lampdeck/$SITE"/*.tar.gz 2>/dev/null \
        | sort \
        | tail -n1)"

    [ -n "$LATEST" ] || continue

    lampdeck restore "$LATEST"
done
