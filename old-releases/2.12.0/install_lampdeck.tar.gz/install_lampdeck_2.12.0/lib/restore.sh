#!/bin/bash

###############################################################################
# LAMP Deck module
# restore
#
# Description:
# Restores a website backup created by the LAMP Deck backup command.
#
# WARNING:
# This operation may overwrite existing files and databases.
#
# Usage:
# lampdeck restore <backup-file>
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/db.sh"

BACKUP_FILE="${1:-}"

if [ -z "$BACKUP_FILE" ]; then
    echo "Usage: lampdeck restore <backup-file>"
    exit 1
fi

if [ ! -f "$BACKUP_FILE" ]; then
    echo "Backup file not found:"
    echo "$BACKUP_FILE"
    exit 1
fi

TMP_DIR="$(mktemp -d)"

cleanup() {
    rm -rf "$TMP_DIR"
}

trap cleanup EXIT

tar xzf "$BACKUP_FILE" -C "$TMP_DIR"

INFO_FILE="$TMP_DIR/backup-info.txt"

if [ ! -f "$INFO_FILE" ]; then
    echo "Invalid backup file."
    exit 1
fi

SITE="$(grep '^Site:' "$INFO_FILE" | cut -d':' -f2- | xargs)"
HAS_DB="$(grep '^Has DB:' "$INFO_FILE" | cut -d':' -f2- | xargs)"
DATABASE="$(grep '^Database:' "$INFO_FILE" | cut -d':' -f2- | xargs)"

echo
echo "============================================"
echo "LAMP Deck Restore"
echo "============================================"
echo
echo "Backup file:"
echo "$BACKUP_FILE"
echo
echo "WARNING"
echo "------------------------------------------------"
echo
echo "THIS OPERATION MAY DESTROY YOUR DATA"
echo
echo "Existing website files will be replaced."
echo "Existing database content will be replaced."
echo
echo "Website : $SITE"
echo "Database: ${DATABASE:--}"
echo
echo "------------------------------------------------"
echo

read -r -p "Continue? (y/N): " CONFIRM

if [ "$CONFIRM" != "y" ]; then
    echo "Restore cancelled."
    exit 0
fi

BASE="$WWW_ROOT/$SITE"

echo
echo "Restoring website files..."

rm -rf "$BASE"
mkdir -p "$BASE"

tar xzf "$TMP_DIR/files.tar.gz" -C "$BASE"

if [ "$HAS_DB" = "1" ]; then

    echo
    echo "Database restore requires MariaDB root password."
    echo

    DB_ROOT_PASS="$(db_prompt_root_password)"
    db_validate_root "$DB_ROOT_PASS"

    SQL_FILE="$(find "$TMP_DIR" -name '*.sql' | head -n1)"

    echo "Restoring database..."

    mariadb -u root -p"$DB_ROOT_PASS" < "$SQL_FILE"
fi

echo
echo "============================================"
echo "RESTORE COMPLETED"
echo "============================================"
echo
echo "Website : $SITE"
echo "Database: ${DATABASE:--}"
echo


