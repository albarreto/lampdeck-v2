# Changelog

## Version 2.3.2 - 2026-04-16
- Dashboard notification when a newer version of LAMP Deck is available.

## Version 2.3.1 - 2026-04-16
- Fixed MariaDB root password prompt bug
- New optional `-d <domain>` flag in `lampdeck install` to create the domain during app installation.

## Version 2.3.0 - 2026-04-15
- Added Joomla installer
- Shared DB validation library for apps
- Improved validation rules for site names
- Admin link support (WordPress, Joomla)
- Improved create-website layout
- Consistent typography in site info cards

## Version 2.2.1 - 2026-04-14
- Simplified changelog
- Shared validation and DB logic across apps
- Prevent unnecessary DB password prompt when site exists

## Version 2.2.0 - 2026-04-14
- Modular app architecture
- WordPress installer moved to apps/wordpress.sh
- New command: lampdeck install wordpress
- Improved frontpage app detection using .app-type markers
- Improved install flow validation
- Cached WordPress download reused when available

## Version 2.1.5 - 2026-04-14
- Frontpage is always preserved when accessing the server by IP
- Domains no longer override the main frontpage
- Improved multisite behavior
- Prevents modification when website folder already exists
- More reliable domain creation
- Improved default website template (light layout)
- Version command now shows Apache, PHP, MariaDB and Redis versions
- Fixed phpMyAdmin installation in upgrades
- Fixed logo size in frontpage
- Fixed PHP 8.4 installation for Ubuntu releases

## Version 2.1.0 - 2026-04-12
- Support for Ubuntu 20.04 LTS (Jammy)
- Support for Ubuntu 24.04 LTS (Noble)
- Support for Alpine 3.x

## Version 2.0.0 - 2026-04-11
- Initial release
