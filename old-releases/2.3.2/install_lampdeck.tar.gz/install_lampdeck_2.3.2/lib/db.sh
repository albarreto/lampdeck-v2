#!/bin/bash

###############################################################################
# LAMP Deck library
# db
#
# Description:
# Shared database helpers used by app modules and internal scripts.
# Includes:
# - MariaDB root password prompt
# - MariaDB root authentication test
# - database/user creation and privilege grant
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

db_prompt_root_password() {
    local pass
    read -r -s -p "Enter MariaDB root password: " pass
    printf '\n' >&2
    printf '%s' "$pass"
}

db_validate_root() {
    local pass="$1"

    echo "Validating database access..."

    if ! mariadb -u root -p"$pass" -e "SELECT 1" >/dev/null 2>&1; then
        echo
        echo "ERROR: Cannot authenticate to MariaDB with provided root password."
        return 1
    fi

    echo "Database authentication OK"
    echo
}

db_create_database() {
    local root_pass="$1"
    local db_name="$2"
    local db_user="$3"
    local db_pass="$4"

    echo "Creating database..."

    mariadb -u root -p"$root_pass" <<SQL
CREATE DATABASE IF NOT EXISTS \`${db_name}\`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '${db_user}'@'localhost'
IDENTIFIED BY '${db_pass}';

ALTER USER '${db_user}'@'localhost'
IDENTIFIED BY '${db_pass}';

GRANT ALL PRIVILEGES
ON \`${db_name}\`.*
TO '${db_user}'@'localhost';

FLUSH PRIVILEGES;
SQL

    echo
}
