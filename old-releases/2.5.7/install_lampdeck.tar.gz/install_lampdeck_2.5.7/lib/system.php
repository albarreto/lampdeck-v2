<?php

function get_meminfo() {
    $data = @file('/proc/meminfo', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $mem = [];

    if ($data) {
        foreach ($data as $line) {
            if (preg_match('/^([A-Za-z_]+):\s+(\d+)/', $line, $m)) {
                $mem[$m[1]] = (int)$m[2] * 1024;
            }
        }
    }

    $total = $mem['MemTotal'] ?? 0;
    $available = $mem['MemAvailable'] ?? ($mem['MemFree'] ?? 0);
    $used = max(0, $total - $available);

    return [
        'total'   => $total,
        'used'    => $used,
        'free'    => $available,
        'percent' => $total > 0 ? round(($used / $total) * 100) : 0
    ];
}

function get_diskinfo($path = '/') {
    $total = @disk_total_space($path) ?: 0;
    $free  = @disk_free_space($path) ?: 0;
    $used  = max(0, $total - $free);

    return [
        'total'   => $total,
        'used'    => $used,
        'free'    => $free,
        'percent' => $total > 0 ? round(($used / $total) * 100) : 0
    ];
}

function service_status($service) {
    $status = cmd('systemctl is-active ' . escapeshellarg($service));
    return $status !== '' ? $status : 'unknown';
}

function status_class($status) {
    switch ($status) {
        case 'active':
            return 'ok';
        case 'inactive':
        case 'failed':
            return 'bad';
        default:
            return 'warn';
    }
}

function normalize_version($service, $version) {
    $version = trim((string)$version);

    if ($version === '') {
        return '';
    }

    switch ($service) {
        case 'mariadb':
            if (preg_match('/([0-9]+\.[0-9]+\.[0-9]+)/', $version, $m)) {
                return $m[1];
            }
            return rtrim(str_replace('MariaDB', '', $version), ' ,');

        default:
            return rtrim($version, ' ,');
    }
}

function service_version($service) {
    switch ($service) {
        case 'apache2':
            $v = cmd("apache2 -v | awk -F'/' '/Server version/ {print \$2}' | awk '{print \$1}'");
            return normalize_version($service, $v);

        case 'php8.4-fpm':
            return normalize_version($service, PHP_VERSION);

        case 'redis-server':
            $v = cmd("redis-server --version | awk '{for(i=1;i<=NF;i++) if(\$i ~ /^v=/){sub(/^v=/,\"\",\$i); print \$i}}'");
            return normalize_version($service, $v);

        case 'mariadb':
            $v = cmd("mariadb --version");
            return normalize_version($service, $v);

        default:
            return '';
    }
}
