#!/bin/bash

###############################################################################
# LAMP Deck common library
#
# Shared variables and helpers used by core commands and app modules.
###############################################################################

set -euo pipefail

APP_NAME="${APP_NAME:-LAMP Deck}"
APP_VERSION="${APP_VERSION:-2.5.5}"

WWW_ROOT="/var/www"
CERT_DIR="/var/www/certs"

APACHE_SITES_AVAILABLE="/etc/apache2/sites-available"
APACHE_SITES_ENABLED="/etc/apache2/sites-enabled"
APACHE_CONF_AVAILABLE="/etc/apache2/conf-available"

SUBSITES_CONF="/etc/apache2/conf-available/subsites-aliases.conf"

###############################################################################
# network helpers
###############################################################################

get_server_ip() {

    local ip

    ip="$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')"

    echo "${ip:-127.0.0.1}"

}
