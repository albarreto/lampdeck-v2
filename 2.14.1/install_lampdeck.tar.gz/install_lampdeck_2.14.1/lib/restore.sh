#!/bin/bash

###############################################################################
# LAMP Deck module
# restore
#
# Description:
# Restores a website backup created by the LAMP Deck backup command.
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/db.sh"

BACKUP_FILE=""
FORCE=0

for arg in "$@"; do
    case "$arg" in
        --force)
            FORCE=1
            ;;
        *)
            if [ -z "$BACKUP_FILE" ]; then
                BACKUP_FILE="$arg"
            fi
            ;;
    esac
done

if [ -z "$BACKUP_FILE" ]; then
    echo -e "${YELLOW}Usage: lampdeck restore <backup-file> [--force]${NC}"
    exit 1
fi

if [ ! -f "$BACKUP_FILE" ]; then

    FOUND_BACKUP=""

    if [ -d "/var/backups/lampdeck/$BACKUP_FILE" ]; then
        FOUND_BACKUP="$(find "/var/backups/lampdeck/$BACKUP_FILE" \
            -maxdepth 1 \
            -type f \
            -name "${BACKUP_FILE}_*.tar.gz" \
            | sort \
            | tail -n1)"
    fi

    if [ -z "$FOUND_BACKUP" ]; then
        FOUND_BACKUP="$(find /var/backups/lampdeck \
            -mindepth 2 \
            -maxdepth 2 \
            -type f \
            -name "$BACKUP_FILE" \
            -print -quit 2>/dev/null)"
    fi

    [ -n "$FOUND_BACKUP" ] && BACKUP_FILE="$FOUND_BACKUP"
fi

if [ ! -f "$BACKUP_FILE" ]; then
    echo -e "${RED}Backup file not found:${NC}"
    echo "$BACKUP_FILE"
    exit 1
fi

TMP_PARENT="/var/tmp/lampdeck-restore"
mkdir -p "$TMP_PARENT"
TMP_DIR="$(mktemp -d "$TMP_PARENT/restore.XXXXXX")"

cleanup() {
    rm -rf "$TMP_DIR"
}

trap cleanup EXIT

echo
echo -e "${CYAN}============================================${NC}"
echo -e "${GREEN}LAMP Deck BACKUP RESTORE${NC}"
echo -e "${CYAN}============================================${NC}"
echo
echo -e "${WHITE}Backup file:${NC}"
echo "  $BACKUP_FILE"
echo

echo -e "${CYAN}Extracting backup...${NC}"
tar xzf "$BACKUP_FILE" -C "$TMP_DIR"

INFO_FILE="$TMP_DIR/backup-info.txt"

if [ ! -f "$INFO_FILE" ]; then
    echo -e "${RED}Invalid backup file.${NC}"
    exit 1
fi

SITE="$(grep '^Site:' "$INFO_FILE" | cut -d':' -f2- | xargs)"
HAS_DB="$(grep '^Has DB:' "$INFO_FILE" | cut -d':' -f2- | xargs)"
DATABASE="$(grep '^Database:' "$INFO_FILE" | cut -d':' -f2- | xargs)"

echo
echo -e "${YELLOW}WARNING${NC}"
echo -e "${YELLOW}------------------------------------------------${NC}"
echo
echo -e "${YELLOW}THIS OPERATION MAY DESTROY YOUR DATA${NC}"
echo
echo "Existing website files will be replaced."
echo "Existing database content will be replaced."
echo
echo "Website : $SITE"
echo "Database: ${DATABASE:--}"
echo
echo -e "${YELLOW}------------------------------------------------${NC}"
echo

if [ "$FORCE" -eq 0 ]; then
    read -r -p "Continue? (y/N): " CONFIRM

    if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}Restore cancelled.${NC}"
        exit 0
    fi
fi

BASE="$WWW_ROOT/$SITE"

echo -e "${CYAN}Restoring website files...${NC}"

if [ ! -d "$TMP_DIR/files" ]; then
    echo -e "${RED}ERROR: files directory not found inside backup.${NC}"
    exit 1
fi

rm -rf "$BASE"
mkdir -p "$BASE"

rsync -a "$TMP_DIR/files/" "$BASE/"

echo -e "${CYAN}Applying permissions...${NC}"

validate_web_user

chown -R "$WEB_USER:$WEB_GROUP" "$BASE"
find "$BASE" -type d -exec chmod 755 {} \;
find "$BASE" -type f -exec chmod 644 {} \;

if [ -d "$BASE/moodledata" ]; then
    chmod -R u+rwX,g+rwX "$BASE/moodledata"
fi

if [ "$FORCE" -eq 0 ]; then
    echo -e "${CYAN}Recovering website alias...${NC}"
    lampdeck recover "$SITE" >/dev/null
fi

if [ "$HAS_DB" = "1" ]; then

    echo
    echo -e "${YELLOW}A MariaDB root password is required to recreate${NC}"
    echo -e "${YELLOW}and restore databases from backups that contain MariaDB data.${NC}"
    echo

    if [ -z "${DB_ROOT_PASS:-}" ]; then
        DB_ROOT_PASS="$(db_prompt_root_password)"
        db_validate_root "$DB_ROOT_PASS"
    fi

    SQL_FILE="$(find "$TMP_DIR" -maxdepth 1 -type f -name "${SITE}_*.sql" ! -name "${SITE}_*_user.sql" -print -quit)"

    USER_SQL_FILE="$(find "$TMP_DIR" -maxdepth 1 -type f -name "${SITE}_*_user.sql" -print -quit)"

    if [ -n "${USER_SQL_FILE:-}" ] && [ -f "$USER_SQL_FILE" ]; then

        echo -e "${CYAN}Restoring database user...${NC}"
        echo "User SQL file: $(basename "$USER_SQL_FILE")"

        mariadb -u root -p"$DB_ROOT_PASS" \
            -e "DROP USER IF EXISTS '$SITE'@'localhost';"

        if ! mariadb -u root -p"$DB_ROOT_PASS" < "$USER_SQL_FILE"; then
            echo
            echo -e "${RED}ERROR: database user restore failed for $SITE${NC}"
            echo "SQL file: $USER_SQL_FILE"
            exit 1
        fi
    fi

    echo -e "${CYAN}Restoring database...${NC}"

    if [ -z "${SQL_FILE:-}" ] || [ ! -f "$SQL_FILE" ]; then
        echo -e "${RED}ERROR: database dump not found inside backup.${NC}"
        exit 1
    fi

    echo "SQL file: $(basename "$SQL_FILE")"

    if ! mariadb -u root -p"$DB_ROOT_PASS" < "$SQL_FILE"; then
        echo
        echo -e "${RED}ERROR: database restore failed for $SITE${NC}"
        echo "SQL file: $SQL_FILE"
        exit 1
    fi
fi

echo
echo -e "${CYAN}============================================${NC}"
echo -e "${GREEN}RESTORE COMPLETED FOR $SITE${NC}"
echo -e "${CYAN}============================================${NC}"
echo
