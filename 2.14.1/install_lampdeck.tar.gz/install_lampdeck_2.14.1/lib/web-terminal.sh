#!/bin/bash

###############################################################################
# LAMP Deck Web Terminal
#
# Instala e configura um terminal web interativo restrito aos comandos do
# LAMP Deck.
#
# Arquitetura:
#
#   navegador
#       -> iframe /terminal/
#       -> Apache reverse proxy
#       -> ttyd em 127.0.0.1:7681
#       -> wrapper Python
#       -> /usr/local/bin/lampdeck
#
# O ttyd fornece o pseudo-terminal (PTY), WebSocket e suporte aos comandos
# interativos. O wrapper não abre um shell Linux: todos os argumentos digitados
# são enviados diretamente ao executável "lampdeck".
###############################################################################

set -euo pipefail

###############################################################################
# Configuração
###############################################################################

# Porta TCP usada internamente pelo ttyd.
TERMINAL_PORT="7681"

# O ttyd escuta apenas no loopback. A porta não deve ser publicada diretamente
# na rede; o acesso externo ocorre exclusivamente pelo Apache.
TERMINAL_BIND="127.0.0.1"

# Caminho público utilizado pelo iframe e pelo reverse proxy.
TERMINAL_BASE_PATH="/terminal"

# Wrapper executado pelo ttyd. Ele aceita somente comandos do LAMP Deck.
TERMINAL_WRAPPER="/usr/local/sbin/lampdeck-terminal-shell"

# Nome utilizado pelo serviço systemd ou OpenRC.
TERMINAL_SERVICE="lampdeck-terminal"

# Versão fixa do binário estático. Fixar a versão evita que uma atualização
# inesperada do upstream altere o comportamento durante uma instalação.
TTYD_STATIC_VERSION="1.7.7"

# Destino usado quando o ttyd é instalado por download do binário estático.
TTYD_STATIC_BIN="/usr/local/bin/ttyd"


###############################################################################
# Instalação do ttyd
###############################################################################
install_ttyd_static() {
    local machine
    local asset
    local download_url
    local temp_file

    machine="$(uname -m)"
    temp_file="$(mktemp /tmp/ttyd.XXXXXX)"

    # Seleciona o binário oficial correspondente à arquitetura.
    case "$machine" in
        x86_64|amd64)
            asset="ttyd.x86_64"
            ;;

        aarch64|arm64)
            asset="ttyd.aarch64"
            ;;

        armv7l|armhf)
            asset="ttyd.armhf"
            ;;

        i386|i486|i586|i686)
            asset="ttyd.i686"
            ;;

        *)
            echo -e "${RED}Error: unsupported architecture for ttyd: $machine${NC}"
            rm -f "$temp_file"
            return 1
            ;;
    esac

    download_url="https://github.com/tsl0922/ttyd/releases/download/${TTYD_STATIC_VERSION}/${asset}"

    echo -e "${CYAN}Downloading ttyd ${TTYD_STATIC_VERSION} for ${machine}...${NC}"

    # Usa curl quando disponível e wget como alternativa.
    if command -v curl >/dev/null 2>&1; then
        if ! curl \
            --fail \
            --location \
            --retry 3 \
            --connect-timeout 15 \
            --output "$temp_file" \
            "$download_url"; then

            echo -e "${RED}Error: failed to download ttyd.${NC}"
            rm -f "$temp_file"
            return 1
        fi

    elif command -v wget >/dev/null 2>&1; then
        if ! wget \
            --tries=3 \
            --timeout=15 \
            --output-document="$temp_file" \
            "$download_url"; then

            echo -e "${RED}Error: failed to download ttyd.${NC}"
            rm -f "$temp_file"
            return 1
        fi

    else
        echo -e "${RED}Error: curl or wget is required to download ttyd.${NC}"
        rm -f "$temp_file"
        return 1
    fi

    # Instala o binário fora da árvore gerenciada pelo apt/apk.
    if ! install \
        -o root \
        -g root \
        -m 755 \
        "$temp_file" \
        "$TTYD_STATIC_BIN"; then

        echo -e "${RED}Error: failed to install ttyd.${NC}"
        rm -f "$temp_file"
        return 1
    fi

    # O arquivo temporário não é mais necessário.
    rm -f "$temp_file"

    # Confirma que o binário instalado pode ser executado.
    if ! "$TTYD_STATIC_BIN" -v >/dev/null 2>&1; then
        echo -e "${RED}Error: downloaded ttyd binary could not be executed.${NC}"
        rm -f "$TTYD_STATIC_BIN"
        return 1
    fi

    echo -e "${GREEN}ttyd installed at ${TTYD_STATIC_BIN}.${NC}"
}


###############################################################################
# Instalação do ttyd conforme a distribuição
###############################################################################

install_ttyd() {

    # Se o ttyd já estiver instalado e disponível no PATH, não reinstala.
    if command -v ttyd >/dev/null 2>&1; then
        echo -e "${GREEN}ttyd is already installed: $(command -v ttyd)${NC}"
        return 0
    fi

    case "${DIST_ID:-}" in

        debian)
            # O Debian 12 Bookworm não oferece o pacote ttyd nos repositórios
            # oficiais. Por isso, instala o binário estático publicado pelo
            # projeto.
            if [ "${DIST_VERSION_ID:-}" = "12" ]; then
                install_ttyd_static
                return
            fi

            # Em versões mais novas do Debian, tenta inicialmente o pacote.
            apt-get update

            if apt-get install -y ttyd; then
                return 0
            fi

            echo -e "${YELLOW}ttyd package unavailable. Using static binary.${NC}"
            install_ttyd_static
            ;;

        ubuntu)
            # No Ubuntu, o pacote pode depender do repositório Universe.
            # Caso não exista candidato, usa o binário estático.
            apt-get update

            if apt-get install -y ttyd; then
                return 0
            fi

            echo -e "${YELLOW}ttyd package unavailable. Using static binary.${NC}"
            install_ttyd_static
            ;;

        alpine)
            # No Alpine, o ttyd normalmente está no repositório community.
            if apk add ttyd; then
                return 0
            fi

            echo -e "${YELLOW}ttyd package unavailable. Using static binary.${NC}"
            install_ttyd_static
            ;;

        *)
            # Distribuições não tratadas utilizam o binário estático.
            install_ttyd_static
            ;;
    esac
}

###############################################################################
# Wrapper restrito
###############################################################################

install_web_terminal_wrapper() {
    echo -e "${CYAN}Creating restricted LAMP Deck terminal wrapper...${NC}"

    mkdir -p "$(dirname "$TERMINAL_WRAPPER")"

    cat > "$TERMINAL_WRAPPER" <<'PYEOF'
#!/usr/bin/env python3

"""
Terminal interativo restrito aos comandos do LAMP Deck.

O programa não abre Bash e não usa shell=True. A linha digitada é separada
com shlex e os argumentos são enviados diretamente ao executável lampdeck.
Assim, caracteres como ";", "&&" e "|" não são interpretados por um shell.
"""

import os
import shlex
import subprocess
import sys


LAMPDECK_BIN = "/usr/local/bin/lampdeck"


def print_banner() -> None:
    """Exibe as instruções iniciais da sessão."""
    print()
    print("======================================================")
    print(" LAMP Deck Web Terminal")
    print("======================================================")
    print()
    print("Only LAMP Deck commands are accepted. Administrative shell: su -")
    print()
    print("Examples:")
    print("  sites --all")
    print("  version")
    print('  install wordpress my-site "My WordPress website"')
    print()
    print("You may also type the complete form:")
    print("  lampdeck sites")
    print()
    print("Internal commands:")
    print("  clear")
    print("  exit")
    print()


def parse_command(line: str) -> list[str]:
    """
    Converte a linha digitada em uma lista de argumentos.

    O prefixo "lampdeck" é opcional porque o wrapper já executa exclusivamente
    /usr/local/bin/lampdeck.
    """
    try:
        args = shlex.split(line, posix=True)
    except ValueError as exc:
        print(f"Invalid command: {exc}")
        return []

    if not args:
        return []

    if args[0] == "lampdeck":
        args = args[1:]

    return args


def run_lampdeck(args: list[str]) -> None:
    """Executa o LAMP Deck diretamente, preservando o terminal interativo."""
    if not args:
        subprocess.run([LAMPDECK_BIN, "help"], check=False)
        return

    try:
        subprocess.run(
            [LAMPDECK_BIN, *args],
            stdin=sys.stdin,
            stdout=sys.stdout,
            stderr=sys.stderr,
            check=False,
        )
    except KeyboardInterrupt:
        # Permite cancelar o comando atual com Ctrl+C sem encerrar a sessão.
        print()
    except FileNotFoundError:
        print(f"Error: {LAMPDECK_BIN} was not found.")
    except OSError as exc:
        print(f"Error executing LAMP Deck: {exc}")


def main() -> int:
    """
    Mantém o prompt ativo até que o usuário solicite a saída.

    O serviço roda como root porque vários comandos do LAMP Deck alteram Apache,
    bancos de dados, sites e arquivos de configuração do sistema.
    """
    if os.geteuid() != 0:
        print("Error: this terminal must run as root.")
        return 1

    if not os.path.isfile(LAMPDECK_BIN):
        print(f"Error: {LAMPDECK_BIN} was not found.")
        return 1

    print_banner()

    while True:
        try:
            line = input("lampdeck> ").strip()
        except EOFError:
            print()
            return 0
        except KeyboardInterrupt:
            print()
            continue

        if not line:
            continue

        if line in {"exit", "quit", "logout"}:
            return 0

        if line == "clear":
            print("\033[2J\033[H", end="", flush=True)
            continue

        if line == "su -":
            try:
                subprocess.run(
                    ["su", "-"],
                    stdin=sys.stdin,
                    stdout=sys.stdout,
                    stderr=sys.stderr,
                    check=False,
                )
            except KeyboardInterrupt:
                print()

            print()
            continue

        args = parse_command(line)

        if not args:
            continue

        run_lampdeck(args)
        print()


if __name__ == "__main__":
    raise SystemExit(main())
PYEOF

    chown root:root "$TERMINAL_WRAPPER"
    chmod 755 "$TERMINAL_WRAPPER"
}


###############################################################################
# Serviço systemd
###############################################################################

install_web_terminal_systemd() {
    local ttyd_bin

    ttyd_bin="$(command -v ttyd || true)"

    if [ -z "$ttyd_bin" ]; then
        echo -e "${RED}Error: ttyd executable not found.${NC}"
        return 1
    fi

    echo -e "${CYAN}Creating LAMP Deck terminal systemd service...${NC}"

    cat > "/etc/systemd/system/${TERMINAL_SERVICE}.service" <<EOF
[Unit]
Description=LAMP Deck restricted web terminal
After=network.target
Wants=network.target

[Service]
Type=simple

# O terminal precisa de root porque os comandos lampdeck administram o servidor.
User=root
Group=root

# O ttyd escuta somente no loopback e executa exclusivamente o wrapper restrito.
ExecStart=${ttyd_bin} \\
    --interface ${TERMINAL_BIND} \\
    --port ${TERMINAL_PORT} \\
    --base-path ${TERMINAL_BASE_PATH} \\
    --writable \\
    ${TERMINAL_WRAPPER}

Restart=on-failure
RestartSec=3

# Restrições adicionais do serviço. NoNewPrivileges não impede o processo que
# já inicia como root de executar os comandos administrativos do LAMP Deck.
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true

[Install]
WantedBy=multi-user.target
EOF

    ###############################################################################
    # Disable any previously installed generic ttyd service
    #
    # Ubuntu may ship a generic ttyd.service listening on TCP 7681.
    # It must be stopped before starting the LAMP Deck service.
    ###############################################################################

    if systemctl list-unit-files | grep -q '^ttyd\.service'; then
        systemctl disable --now ttyd.service >/dev/null 2>&1 || true
    fi

    ###############################################################################
    # Stop previous LAMP Deck instance
    ###############################################################################

    systemctl stop "$TERMINAL_SERVICE" >/dev/null 2>&1 || true

    ###############################################################################
    # Kill any remaining ttyd process still listening on the terminal port
    ###############################################################################

    if command -v fuser >/dev/null 2>&1; then
        fuser -k "${TERMINAL_PORT}/tcp" >/dev/null 2>&1 || true
    else
        pkill -f "ttyd.*${TERMINAL_PORT}" >/dev/null 2>&1 || true
    fi

    systemctl daemon-reload
    systemctl enable --now "$TERMINAL_SERVICE"
}


###############################################################################
# Serviço OpenRC
###############################################################################

install_web_terminal_openrc() {
    local ttyd_bin

    ttyd_bin="$(command -v ttyd || true)"

    if [ -z "$ttyd_bin" ]; then
        echo -e "${RED}Error: ttyd executable not found.${NC}"
        return 1
    fi

    echo -e "${CYAN}Creating LAMP Deck terminal OpenRC service...${NC}"

    cat > "/etc/init.d/${TERMINAL_SERVICE}" <<EOF
#!/sbin/openrc-run

name="LAMP Deck restricted web terminal"
description="Restricted web terminal for LAMP Deck commands"

command="${ttyd_bin}"

# O terminal fica restrito ao loopback e executa apenas o wrapper do LAMP Deck.
command_args="--interface ${TERMINAL_BIND}
--port ${TERMINAL_PORT}
--base-path ${TERMINAL_BASE_PATH}
--writable
${TERMINAL_WRAPPER}"

command_background="yes"
pidfile="/run/${TERMINAL_SERVICE}.pid"

depend() {
    need net
    after apache2
}
EOF

    chmod 755 "/etc/init.d/${TERMINAL_SERVICE}"

    rc-update add "$TERMINAL_SERVICE" default >/dev/null 2>&1 || true
    rc-service "$TERMINAL_SERVICE" restart
}


###############################################################################
# Apache — Debian e Ubuntu
###############################################################################

install_web_terminal_apache_debian() {

    echo -e "${CYAN}Configuring Apache WebSocket proxy...${NC}"

    # Módulos necessários para reverse proxy HTTP e WebSocket.
    a2enmod proxy >/dev/null 2>&1 || true
    a2enmod proxy_http >/dev/null 2>&1 || true
    a2enmod proxy_wstunnel >/dev/null 2>&1 || true

    cat > /etc/apache2/conf-available/lampdeck-terminal.conf <<EOF
###############################################################################
# LAMP Deck Web Terminal
#
# O ttyd escuta somente em 127.0.0.1:${TERMINAL_PORT}.
# O Apache publica o terminal em ${TERMINAL_BASE_PATH}/.
###############################################################################

ProxyPreserveHost On

###############################################################################
# WebSocket
#
# Esta regra precisa aparecer antes do proxy HTTP genérico.
###############################################################################

ProxyPass \
    "${TERMINAL_BASE_PATH}/ws" \
    "ws://${TERMINAL_BIND}:${TERMINAL_PORT}${TERMINAL_BASE_PATH}/ws"

ProxyPassReverse \
    "${TERMINAL_BASE_PATH}/ws" \
    "ws://${TERMINAL_BIND}:${TERMINAL_PORT}${TERMINAL_BASE_PATH}/ws"

###############################################################################
# HTTP
###############################################################################

ProxyPass \
    "${TERMINAL_BASE_PATH}/" \
    "http://${TERMINAL_BIND}:${TERMINAL_PORT}${TERMINAL_BASE_PATH}/"

ProxyPassReverse \
    "${TERMINAL_BASE_PATH}/" \
    "http://${TERMINAL_BIND}:${TERMINAL_PORT}${TERMINAL_BASE_PATH}/"

###############################################################################
# Authentication
###############################################################################

<Location "${TERMINAL_BASE_PATH}/">

    # Quando a autenticação do Frontpage já foi habilitada, reutiliza
    # o mesmo arquivo de usuários e senhas.
    <IfFile "/etc/apache2/.htpasswd">
        AuthType Basic
        AuthName "LAMP Deck"
        AuthUserFile /etc/apache2/.htpasswd
        Require valid-user
    </IfFile>

    # Quando o arquivo ainda não existe, bloqueia o acesso ao terminal.
    # Isso evita o erro HTTP 500 causado pelo AuthUserFile inexistente.
    <IfFile "!/etc/apache2/.htpasswd">
        Require all denied
    </IfFile>

</Location>
EOF

    a2enconf lampdeck-terminal >/dev/null 2>&1 || true
}

###############################################################################
# Apache — Alpine
###############################################################################

install_web_terminal_apache_alpine() {
    local apache_conf="/etc/apache2/httpd.conf"
    local apache_tmp
    local module_file
    local required_module

    echo -e "${CYAN}Configuring Apache WebSocket proxy...${NC}"

    ###########################################################################
    # Instala os módulos de proxy
    ###########################################################################

    if ! apk info -e apache2-proxy >/dev/null 2>&1; then
        echo -e "${CYAN}Installing Apache proxy modules...${NC}"
        apk add apache2-proxy
    fi

    ###########################################################################
    # Confirma que os módulos existem
    ###########################################################################

    for module_file in \
        /usr/lib/apache2/mod_proxy.so \
        /usr/lib/apache2/mod_proxy_http.so \
        /usr/lib/apache2/mod_proxy_wstunnel.so
    do
        if [ ! -f "$module_file" ]; then
            echo -e "${RED}Error: Apache module not found: $module_file${NC}"
            return 1
        fi
    done

    ###########################################################################
    # Corrige a ordem dos módulos
    #
    # mod_proxy precisa ser carregado antes de todos os submódulos.
    ###########################################################################

    apache_tmp="$(mktemp /tmp/lampdeck-httpd.XXXXXX)"

    awk '
        /^[[:space:]]*LoadModule[[:space:]]+proxy_module[[:space:]]+/ {
            next
        }

        /^[[:space:]]*LoadModule[[:space:]]+proxy_http_module[[:space:]]+/ {
            next
        }

        /^[[:space:]]*LoadModule[[:space:]]+proxy_wstunnel_module[[:space:]]+/ {
            next
        }

        /^[[:space:]]*LoadModule[[:space:]]+proxy_fcgi_module[[:space:]]+/ {
            if (!proxy_inserted) {
                print "LoadModule proxy_module modules/mod_proxy.so"
                print "LoadModule proxy_http_module modules/mod_proxy_http.so"
                print "LoadModule proxy_wstunnel_module modules/mod_proxy_wstunnel.so"
                proxy_inserted=1
            }

            print
            next
        }

        {
            print
        }

        END {
            if (!proxy_inserted) {
                print ""
                print "# LAMP Deck Web Terminal proxy modules"
                print "LoadModule proxy_module modules/mod_proxy.so"
                print "LoadModule proxy_http_module modules/mod_proxy_http.so"
                print "LoadModule proxy_wstunnel_module modules/mod_proxy_wstunnel.so"
            }
        }
    ' "$apache_conf" > "$apache_tmp"

    chown root:root "$apache_tmp"
    chmod 644 "$apache_tmp"
    mv "$apache_tmp" "$apache_conf"

    ###########################################################################
    # Validação dos módulos
    ###########################################################################

    if ! httpd -t; then
        echo -e "${RED}Error: Apache proxy modules could not be loaded.${NC}"
        return 1
    fi

    for required_module in \
        proxy_module \
        proxy_http_module \
        proxy_wstunnel_module
    do
        if ! httpd -M 2>/dev/null | grep -q "$required_module"; then
            echo -e "${RED}Error: Apache module not loaded: $required_module${NC}"
            return 1
        fi
    done

    ###########################################################################
    # Reverse proxy HTTP e WebSocket
    ###########################################################################

    cat > /etc/apache2/conf.d/lampdeck-terminal.conf <<EOF
###############################################################################
# LAMP Deck Web Terminal
###############################################################################

ProxyPreserveHost On

# WebSocket — deve aparecer antes do proxy HTTP genérico.
ProxyPass \
    "${TERMINAL_BASE_PATH}/ws" \
    "ws://${TERMINAL_BIND}:${TERMINAL_PORT}${TERMINAL_BASE_PATH}/ws"

ProxyPassReverse \
    "${TERMINAL_BASE_PATH}/ws" \
    "ws://${TERMINAL_BIND}:${TERMINAL_PORT}${TERMINAL_BASE_PATH}/ws"

# HTTP
ProxyPass \
    "${TERMINAL_BASE_PATH}/" \
    "http://${TERMINAL_BIND}:${TERMINAL_PORT}${TERMINAL_BASE_PATH}/"

ProxyPassReverse \
    "${TERMINAL_BASE_PATH}/" \
    "http://${TERMINAL_BIND}:${TERMINAL_PORT}${TERMINAL_BASE_PATH}/"

# Authentication
<Location "${TERMINAL_BASE_PATH}/">

    <IfFile "/etc/apache2/.htpasswd">
        AuthType Basic
        AuthName "LAMP Deck"
        AuthUserFile /etc/apache2/.htpasswd
        Require valid-user
    </IfFile>

    <IfFile "!/etc/apache2/.htpasswd">
        Require all denied
    </IfFile>

</Location>
EOF

    if ! httpd -t; then
        echo -e "${RED}Error: invalid Apache Web Terminal configuration.${NC}"
        return 1
    fi
}

###############################################################################
# Instalação principal
###############################################################################

install_web_terminal() {
    echo
    echo -e "${CYAN}============================================${NC}"
    echo -e "${GREEN}Installing LAMP Deck Web Terminal${NC}"
    echo -e "${CYAN}============================================${NC}"
    echo

    # Instala pelo gerenciador de pacotes quando possível e usa binário estático
    # como fallback, inclusive no Debian 12 Bookworm.
    install_ttyd

    if ! command -v python3 >/dev/null 2>&1; then
        echo -e "${RED}Error: python3 is not installed.${NC}"
        return 1
    fi

    # O CLI principal precisa existir antes da criação e inicialização do serviço.
    if [ ! -x /usr/local/bin/lampdeck ]; then
        echo -e "${RED}Error: /usr/local/bin/lampdeck was not found.${NC}"
        echo "Install the Web Terminal after creating the main LAMP Deck CLI."
        return 1
    fi

    install_web_terminal_wrapper

    if [ "${DIST_ID:-}" = "alpine" ]; then
        install_web_terminal_apache_alpine
        install_web_terminal_openrc
    else
        install_web_terminal_apache_debian
        install_web_terminal_systemd
    fi

    # O Apache referencia o arquivo mesmo quando a autenticação ainda não foi
    # ativada. Nesse caso, o terminal permanece indisponível até auth-enable.
    if [ ! -f /etc/apache2/.htpasswd ]; then
        echo
        echo -e "${YELLOW}WARNING: frontpage authentication is not enabled.${NC}"
        echo
        echo "The Web Terminal requires authentication."
        echo "After installation, enable it with:"
        echo
        echo "  lampdeck auth-enable"
        echo
    fi

    # Valida e recarrega o Apache por meio da função comum do LAMP Deck.
    apache_reload

    echo -e "${GREEN}LAMP Deck Web Terminal installed.${NC}"
    echo
}
