#!/bin/bash

###############################################################################
# LAMP Deck library
# remove-site
#
# Description:
# Shared site removal helpers used for rollback and future uninstall features.
###############################################################################

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

set -euo pipefail

remove_site() {
    local site="$1"
    local base="$WWW_ROOT/$site"

    if [ -z "$site" ]; then
        echo -e "${RED}Error: remove_site requires a site name${NC}"
        return 1
    fi

    echo "Removing website files..."

    if [ -d "$base" ]; then
        rm -rf "$base"
    fi

    if [ -f "$SUBSITES_CONF" ]; then
        sed -i "/RedirectMatch 302 \\^\\/$site\\$ \\/$site\\//,/^$/d" "$SUBSITES_CONF" 2>/dev/null || true
    fi

    apache_reload || true

    echo "Website rollback completed."
}
