#!/bin/bash

###############################################################################
# LAMP Deck package common library
#
# Shared helpers used by package installers.
###############################################################################

set -euo pipefail

detect_php_fpm_socket() {

    local preferred_version="${1:-}"
    local socket=""

    # Debian / Ubuntu preferred version
    if [ -n "$preferred_version" ]; then

        socket="/run/php/php${preferred_version}-fpm.sock"

        if [ -S "$socket" ]; then
            echo "$socket"
            return 0
        fi
    fi

    # Common Debian/Ubuntu sockets
    for socket in /run/php/php*-fpm.sock; do
        if [ -S "$socket" ]; then
            echo "$socket"
            return 0
        fi
    done

    # Alpine
    if [ -S /run/php-fpm/php-fpm.sock ]; then
        echo "/run/php-fpm/php-fpm.sock"
        return 0
    fi

    # Generic fallback
    if [ -S /run/php-fpm.sock ]; then
        echo "/run/php-fpm.sock"
        return 0
    fi

    echo -e "${RED}ERROR: PHP-FPM socket not found.${NC}"
    return 1
}
