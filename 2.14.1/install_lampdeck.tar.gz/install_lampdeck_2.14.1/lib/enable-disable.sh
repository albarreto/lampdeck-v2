#!/bin/bash

###############################################################################
# LAMP Deck app common helpers
#
# Shared helpers for app enable/disable
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"

ACTION="${1:-}"
SITE_RAW="${2:-}"

SITE="$(normalize_site_name "$SITE_RAW")"

if [ -z "$ACTION" ] || [ -z "$SITE" ]; then
    echo -e "${YELLOW}Usage:${NC}"
    echo "  lampdeck enable <site>"
    echo "  lampdeck disable <site>"
    exit 1
fi

case "$ACTION" in
    disable)
        BASE="$WWW_ROOT/$SITE"
        TARGET="$WWW_ROOT/$SITE.disabled"

        if [ ! -d "$BASE" ]; then
            echo -e "${RED}Error: site not found: $BASE${NC}"
            exit 1
        fi

        if [ -d "$TARGET" ]; then
            echo -e "${RED}Error: disabled target already exists: $TARGET${NC}"
            exit 1
        fi

        echo
        echo "You are about to DISABLE this site:"
        echo "  $SITE"
        echo
        echo "Folder will be renamed to:"
        echo "  $TARGET"
        echo
        read -r -p "Confirm? (y/N): " confirm

        if [ "$confirm" != "y" ]; then
            echo "Operation cancelled."
            exit 0
        fi

        mv "$BASE" "$TARGET"

        apache_reload

        echo
        echo "Site disabled successfully:"
        echo "  $SITE -> $(basename "$TARGET")"
        echo
        ;;

    enable)
        BASE="$WWW_ROOT/$SITE"
        SOURCE="$WWW_ROOT/$SITE.disabled"

        if [ -d "$BASE" ]; then
            echo -e "${RED}Error: enabled target already exists: $BASE${NC}"
            exit 1
        fi

        if [ ! -d "$SOURCE" ]; then
            echo -e "${RED}Error: disabled site not found: $SOURCE${NC}"
            exit 1
        fi

        echo
        echo "You are about to ENABLE this site:"
        echo "  $(basename "$SOURCE")"
        echo
        echo "Folder will be renamed to:"
        echo "  $BASE"
        echo
        read -r -p "Confirm? (y/N): " confirm

        if [ "$confirm" != "y" ]; then
            echo "Operation cancelled."
            exit 0
        fi

        mv "$SOURCE" "$BASE"

        apache_reload

        echo
        echo "Site enabled successfully:"
        echo "  $(basename "$SOURCE") -> $SITE"
        echo
        ;;

    *)
        echo -e "${RED}Error: invalid action: $ACTION${NC}"
        echo -e "${YELLOW}Usage:${NC}"
        echo "  lampdeck enable <site>"
        echo "  lampdeck disable <site>"
        exit 1
        ;;
esac    
