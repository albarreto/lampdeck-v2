#!/bin/bash

###############################################################################
# LAMP Deck app module
# mediawiki
#
# Usage:
# lampdeck install mediawiki <site-name> [description]
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="mediawiki"
APP_NAME="MediaWiki"
APP_HAS_DB="1"
APP_CATEGORY="Documentation"
APP_ADMIN_PATH="index.php/Special:UserLogin"
APP_ADMIN_LABEL="Login"
APP_DOWNLOAD_URL="https://releases.wikimedia.org/mediawiki/1.45/mediawiki-1.45.3.tar.gz"

app_prepare_with_db "${1:-}" "${2:-}"

#########################################
# package
#########################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"
app_init_tmp_dir
app_extract_archive

EXTRACTED_DIR="$(find "$APP_TMP_DIR" -mindepth 1 -maxdepth 1 -type d | head -n 1)"

if [ -z "${EXTRACTED_DIR:-}" ]; then
    echo -e "${RED}Error: extracted directory not found${NC}"
    exit 1
fi

echo "Copying $APP_NAME files to $BASE..."
rsync -a "$EXTRACTED_DIR"/ "$BASE"/

#== Harden MediaWiki uploads directory

mkdir -p "$BASE/images"

UPLOADS_CONF="$APACHE_CONF_AVAILABLE/lampdeck-${SITE}-mediawiki-uploads.conf"

a2enmod headers >/dev/null 2>&1 || true

cat > "$UPLOADS_CONF" <<EOF
<Directory "$BASE/images">
    AllowOverride None
    Require all granted

    Header always set X-Content-Type-Options "nosniff"

    AddType text/plain .html .htm .shtml .phtml

    <FilesMatch "\\.ph(p[0-9]?|tml|ar)?$">
        Require all denied
    </FilesMatch>
</Directory>
EOF

a2enconf "lampdeck-${SITE}-mediawiki-uploads" >/dev/null 2>&1 || true

#########################################
# app config
#########################################

cat > "$BASE/.htaccess" <<EOF
DirectoryIndex index.php

RewriteEngine On
RewriteBase /$SITE/

RewriteRule ^$ index.php [L]
EOF

#########################################
# metadata
#########################################

app_write_metadata

#########################################
# permissions
#########################################

app_apply_default_permissions
app_apply_rw_permissions \
    "$BASE/images" \
    "$BASE/cache"

#########################################
# apache reload
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

app_print_success_with_db

echo "Next steps:"
echo "1. Open: https://$HOSTNAME_FQDN/$SITE/"
echo "2. Run the MediaWiki web installer"
echo "3. Use MariaDB/MySQL with the credentials above"
echo "4. After installation, move the generated LocalSettings.php to:"
echo "   $BASE/LocalSettings.php"
echo "============================================"
echo
