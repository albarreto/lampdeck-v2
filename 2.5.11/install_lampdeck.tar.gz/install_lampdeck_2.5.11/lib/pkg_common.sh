#!/bin/bash

###############################################################################
# LAMP Deck package common library
#
# Shared helpers used by package installers.
###############################################################################

set -euo pipefail

LAMPDECK_PHP_SOCKET="/run/lampdeck/php-fpm.sock"

detect_php_fpm_socket() {
    local preferred_version="${1:-}"
    local socket=""

    if [ -n "$preferred_version" ]; then
        socket="/run/php/php${preferred_version}-fpm.sock"

        if [ -S "$socket" ]; then
            echo "$socket"
            return 0
        fi
    fi

    find /run /var/run -type s \
        \( -name "php*-fpm.sock" -o -name "php-fpm.sock" -o -name "www.sock" \) \
        2>/dev/null \
        | sort -V \
        | tail -n 1
}

setup_lampdeck_php_socket() {
    echo "== Configuring LAMP Deck PHP-FPM socket"

    local preferred_version="${1:-}"
    local detected_socket=""

    detected_socket="$(detect_php_fpm_socket "$preferred_version")"

    if [ -z "$detected_socket" ]; then
        echo "ERROR: PHP-FPM socket not found."
        return 1
    fi

    mkdir -p /run/lampdeck
    ln -sfn "$detected_socket" "$LAMPDECK_PHP_SOCKET"

    echo "Detected PHP-FPM socket: $detected_socket"
    echo "LAMP Deck PHP-FPM socket: $LAMPDECK_PHP_SOCKET"
}

update_apache_php_socket_refs() {
    echo "== Updating Apache PHP-FPM socket references"

    [ -d /etc/apache2 ] || return 0

    find /etc/apache2/sites-available /etc/apache2/conf-available \
        -type f -name "*.conf" 2>/dev/null \
        -exec sed -i -E \
        's|/run/php/[^|"]*fpm\.sock|/run/lampdeck/php-fpm.sock|g; s|/var/run/php/[^|"]*fpm\.sock|/run/lampdeck/php-fpm.sock|g' {} \;
}

configure_lampdeck_php_fpm() {
    local preferred_version="${1:-}"

    setup_lampdeck_php_socket "$preferred_version"
    update_apache_php_socket_refs
}
