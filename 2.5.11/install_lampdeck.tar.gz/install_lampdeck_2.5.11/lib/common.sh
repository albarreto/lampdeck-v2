#!/bin/bash

###############################################################################
# LAMP Deck common library
#
# Shared variables and helpers used by core commands and app modules.
###############################################################################

set -euo pipefail

APP_NAME="${APP_NAME:-LAMP Deck}"
APP_VERSION="${APP_VERSION:-2.5.11}"

WWW_ROOT="/var/www"
CERT_DIR="/var/www/certs"

APACHE_SITES_AVAILABLE="/etc/apache2/sites-available"
APACHE_SITES_ENABLED="/etc/apache2/sites-enabled"
APACHE_CONF_AVAILABLE="/etc/apache2/conf-available"

SUBSITES_CONF="/etc/apache2/conf-available/subsites-aliases.conf"

###############################################################################
# network helpers
###############################################################################

get_server_ip() {

    local ip

    ip="$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')"

    echo "${ip:-127.0.0.1}"

}

get_php_fpm_socket() {
    if [ -L /run/lampdeck/php-fpm.sock ]; then
        readlink -f /run/lampdeck/php-fpm.sock
        return 0
    fi

    grep -Rho "/run/php/php[0-9]\+\.[0-9]\+-fpm.sock" \
        /etc/apache2/sites-enabled /etc/apache2/conf-enabled 2>/dev/null \
        | head -n1
}

get_php_fpm_minor() {
    local socket
    socket="$(get_php_fpm_socket)"

    if [ -n "$socket" ]; then
        echo "$socket" | sed -E 's|.*/php([0-9]+\.[0-9]+)-fpm\.sock|\1|'
    fi
}

get_php_fpm_version() {
    local minor
    local bin

    minor="$(get_php_fpm_minor)"

    if [ -z "$minor" ]; then
        return 0
    fi

    bin="$(command -v "php$minor" 2>/dev/null || true)"

    if [ -n "$bin" ]; then
        "$bin" -r 'echo PHP_VERSION;' 2>/dev/null
    else
        echo "$minor"
    fi
}
