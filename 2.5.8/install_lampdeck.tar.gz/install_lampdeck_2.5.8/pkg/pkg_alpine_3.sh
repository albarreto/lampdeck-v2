#!/bin/sh

###############################################################################
# LAMP Deck package installer
# Target: Alpine Linux 3.19+
#
# Description:
#   Installs the package set required by LAMP Deck on Alpine Linux
#
# Installs:
#   Apache2
#   PHP-FPM (native from Alpine repositories)
#   MariaDB
#   Redis
#   Certbot
#   phpMyAdmin
#
# Project:
#   LAMP Deck
#   https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
#   GPL-3.0-or-later
###############################################################################

set -eu

install_alpine_packages() {

    timezone="${TIMEZONE:-America/Maceio}"
    app_version="${APP_VERSION:-2.0.0}"
    hostname_fqdn="${HOSTNAME_FQDN:-server.local}"

    #########################################################
    # APK REPOSITORIES
    #########################################################

    ALPINE_BRANCH="$(cut -d. -f1,2 /etc/alpine-release)"

    cat > /etc/apk/repositories <<EOF
http://dl-cdn.alpinelinux.org/alpine/v${ALPINE_BRANCH}/main
http://dl-cdn.alpinelinux.org/alpine/v${ALPINE_BRANCH}/community
EOF

    echo "== Updating system"
    apk update
    apk upgrade

    #########################################################
    # BASE
    #########################################################

    echo "== Base packages"
    apk add \
        bash \
        ca-certificates \
        curl \
        wget \
        gnupg \
        unzip \
        zip \
        rsync \
        nano \
        vim \
        htop \
        tar \
        openssl \
        tzdata

    #########################################################
    # TIMEZONE
    #########################################################

    if [ -f "/usr/share/zoneinfo/$timezone" ]; then
        cp "/usr/share/zoneinfo/$timezone" /etc/localtime
        echo "$timezone" > /etc/timezone
    fi

    #########################################################
    # APACHE
    #########################################################

    echo "== Installing Apache"
    apk add apache2 apache2-ssl apache2-proxy

    mkdir -p /run/apache2
    rc-update add apache2 default

    rm -f /etc/apache2/conf.d/proxy.conf
    rm -f /etc/apache2/conf.d/ssl.conf

    #########################################################
    # PHP (NATIVE FROM DISTRO)
    #########################################################

    echo "== Installing PHP (native version from Alpine repo)"

    apk add \
        php \
        php-fpm \
        php-opcache \
        php-mysqli \
        php-pdo \
        php-pdo_mysql \
        php-curl \
        php-gd \
        php-intl \
        php-mbstring \
        php-xml \
        php-zip \
        php-bcmath \
        php-soap \
        php-phar \
        php-session \
        php-fileinfo \
        php-tokenizer \
        php-ctype \
        php-openssl \
        php-dom \
        php-xmlreader \
        php-simplexml \
        php-redis

    apk add php-pecl-imagick || true

    rm -f /etc/apache2/conf.d/php*-module.conf

    PHP_MM="$(php -r 'echo PHP_MAJOR_VERSION . PHP_MINOR_VERSION;')"

    PHP_ETC_DIR="/etc/php${PHP_MM}"
    PHP_FPM_SERVICE="php-fpm${PHP_MM}"
    PHP_FPM_SOCK="/run/${PHP_FPM_SERVICE}.sock"

    echo "== Using native Alpine PHP (php${PHP_MM})"

    rc-update add "$PHP_FPM_SERVICE" default

    #########################################################
    # REDIS
    #########################################################

    echo "== Installing Redis"
    apk add redis
    rc-update add redis default

    #########################################################
    # CERTBOT
    #########################################################

    echo "== Installing Certbot"
    apk add certbot certbot-apache

    #########################################################
    # MARIADB
    #########################################################

    echo "== Installing MariaDB"
    apk add mariadb mariadb-client

    rc-update add mariadb default

    mariadb-install-db --user=mysql --datadir=/var/lib/mysql >/dev/null 2>&1 || true
    mysql_install_db --user=mysql --datadir=/var/lib/mysql >/dev/null 2>&1 || true

    #########################################################
    # START DB ONCE FOR PASSWORD SETUP
    #########################################################

    rc-service mariadb start || true

    #########################################################
    # SET ROOT PASSWORD
    #########################################################

    if [ -n "${DB_ROOT_PASS:-}" ]; then
        echo "== Configuring MariaDB root password"

        mariadb <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT_PASS}';
FLUSH PRIVILEGES;
EOF
    fi

    #########################################################
    # PHP PERFORMANCE
    #########################################################

    PHP_INI_FPM="$PHP_ETC_DIR/php.ini"
    PHP_INI_CLI="$PHP_ETC_DIR/php.ini"

    if [ -f "$PHP_INI_FPM" ]; then
        sed -i 's/^memory_limit = .*/memory_limit = 512M/' "$PHP_INI_FPM" || true
        sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 256M/' "$PHP_INI_FPM" || true
        sed -i 's/^post_max_size = .*/post_max_size = 256M/' "$PHP_INI_FPM" || true
        sed -i 's/^max_execution_time = .*/max_execution_time = 300/' "$PHP_INI_FPM" || true
        sed -i 's/^max_input_vars = .*/max_input_vars = 5000/' "$PHP_INI_FPM" || true
        grep -q "^date.timezone" "$PHP_INI_FPM" \
            && sed -i "s#^date.timezone.*#date.timezone = ${timezone}#" "$PHP_INI_FPM" \
            || echo "date.timezone = ${timezone}" >> "$PHP_INI_FPM"
    fi

    if [ -f "$PHP_INI_CLI" ]; then
        grep -q "^date.timezone" "$PHP_INI_CLI" \
            && sed -i "s#^date.timezone.*#date.timezone = ${timezone}#" "$PHP_INI_CLI" \
            || echo "date.timezone = ${timezone}" >> "$PHP_INI_CLI"
    fi

    #########################################################
    # OPCACHE
    #########################################################

    mkdir -p "$PHP_ETC_DIR/conf.d"

    cat > "$PHP_ETC_DIR/conf.d/00_lampdeck_opcache.ini" <<EOF
zend_extension=opcache
opcache.enable=1
opcache.enable_cli=0
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=40000
opcache.validate_timestamps=1
opcache.revalidate_freq=2
opcache.save_comments=1
EOF

    #########################################################
    # PHP-FPM POOL
    #########################################################

    POOL="$PHP_ETC_DIR/php-fpm.d/www.conf"

    if [ -f "$POOL" ]; then
        sed -i 's/^pm = .*/pm = dynamic/' "$POOL" || true
        sed -i 's/^pm.max_children = .*/pm.max_children = 40/' "$POOL" || true
        sed -i 's/^pm.start_servers = .*/pm.start_servers = 4/' "$POOL" || true
        sed -i 's/^pm.min_spare_servers = .*/pm.min_spare_servers = 2/' "$POOL" || true
        sed -i 's/^pm.max_spare_servers = .*/pm.max_spare_servers = 6/' "$POOL" || true
        grep -q '^pm.max_requests' "$POOL" || echo 'pm.max_requests = 500' >> "$POOL"
        grep -q '^listen =' "$POOL" \
            && sed -i "s#^listen =.*#listen = $PHP_FPM_SOCK#" "$POOL" \
            || echo "listen = $PHP_FPM_SOCK" >> "$POOL"
    fi

    #########################################################
    # MYSQL TUNING
    #########################################################

    mkdir -p /etc/my.cnf.d

    cat > /etc/my.cnf.d/60-wp.cnf <<EOF
[mysqld]

character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

max_connections = 150

innodb_buffer_pool_size = 512M
innodb_log_file_size = 128M
innodb_flush_method = O_DIRECT

table_open_cache = 4000
thread_cache_size = 100

tmp_table_size = 64M
max_heap_table_size = 64M
EOF

    #########################################################
    # WWW BASE
    #########################################################

    mkdir -p /var/www/html
    mkdir -p /var/www/certs

    #########################################################
    # PHPMYADMIN
    #########################################################

    echo "== Installing phpMyAdmin"

    if [ -z "${DB_ROOT_PASS:-}" ]; then
        echo "ERROR: DB_ROOT_PASS is required to configure phpMyAdmin."
        exit 1
    fi

    apk add phpmyadmin

    pma_db="phpmyadmin"
    pma_user="phpmyadmin"
    pma_pass="${DB_ROOT_PASS}"

    echo "== Configuring phpMyAdmin database"

    mariadb -u root -p"${DB_ROOT_PASS}" -e "
CREATE DATABASE IF NOT EXISTS \`${pma_db}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${pma_user}'@'localhost' IDENTIFIED BY '${pma_pass}';
ALTER USER '${pma_user}'@'localhost' IDENTIFIED BY '${pma_pass}';
GRANT ALL PRIVILEGES ON \`${pma_db}\`.* TO '${pma_user}'@'localhost';
FLUSH PRIVILEGES;
"

    if [ -f /usr/share/webapps/phpmyadmin/sql/create_tables.sql ]; then
        if ! mariadb -u root -p"${DB_ROOT_PASS}" -N -s -e "USE \`${pma_db}\`; SHOW TABLES LIKE 'pma__bookmark';" | grep -q 'pma__bookmark'; then
            mariadb -u root -p"${DB_ROOT_PASS}" "${pma_db}" < /usr/share/webapps/phpmyadmin/sql/create_tables.sql
        fi
    else
        echo "WARNING: phpMyAdmin create_tables.sql not found. Advanced storage features may remain disabled."
    fi

    mkdir -p /etc/phpmyadmin

    cat > /etc/phpmyadmin/config.inc.php <<EOF
<?php
\$cfg['blowfish_secret'] = '$(openssl rand -hex 16)';
\$i = 1;
\$cfg['Servers'][\$i]['auth_type'] = 'cookie';
\$cfg['Servers'][\$i]['host'] = 'localhost';
\$cfg['Servers'][\$i]['compress'] = false;
\$cfg['Servers'][\$i]['AllowNoPassword'] = false;
\$cfg['Servers'][\$i]['controluser'] = '${pma_user}';
\$cfg['Servers'][\$i]['controlpass'] = '${pma_pass}';
\$cfg['Servers'][\$i]['pmadb'] = '${pma_db}';
\$cfg['Servers'][\$i]['bookmarktable'] = 'pma__bookmark';
\$cfg['Servers'][\$i]['relation'] = 'pma__relation';
\$cfg['Servers'][\$i]['table_info'] = 'pma__table_info';
\$cfg['Servers'][\$i]['table_coords'] = 'pma__table_coords';
\$cfg['Servers'][\$i]['pdf_pages'] = 'pma__pdf_pages';
\$cfg['Servers'][\$i]['column_info'] = 'pma__column_info';
\$cfg['Servers'][\$i]['history'] = 'pma__history';
\$cfg['Servers'][\$i]['table_uiprefs'] = 'pma__table_uiprefs';
\$cfg['Servers'][\$i]['tracking'] = 'pma__tracking';
\$cfg['Servers'][\$i]['userconfig'] = 'pma__userconfig';
\$cfg['Servers'][\$i]['recent'] = 'pma__recent';
\$cfg['Servers'][\$i]['favorite'] = 'pma__favorite';
\$cfg['Servers'][\$i]['users'] = 'pma__users';
\$cfg['Servers'][\$i]['usergroups'] = 'pma__usergroups';
\$cfg['Servers'][\$i]['navigationhiding'] = 'pma__navigationhiding';
\$cfg['Servers'][\$i]['savedsearches'] = 'pma__savedsearches';
\$cfg['Servers'][\$i]['central_columns'] = 'pma__central_columns';
\$cfg['Servers'][\$i]['designer_settings'] = 'pma__designer_settings';
\$cfg['Servers'][\$i]['export_templates'] = 'pma__export_templates';
EOF

    chown root:root /etc/phpmyadmin/config.inc.php
    chmod 600 /etc/phpmyadmin/config.inc.php

    #########################################################
    # APACHE CONFIG
    #########################################################

    mkdir -p /etc/apache2/conf.d

    rm -f /etc/apache2/conf.d/proxy.conf
    rm -f /etc/apache2/conf.d/ssl.conf
    rm -f /etc/apache2/conf.d/php*-module.conf

    sed -i 's#^DocumentRoot ".*"#DocumentRoot "/var/www/html"#' /etc/apache2/httpd.conf || true
    sed -i 's/^#LoadModule mpm_event_module /LoadModule mpm_event_module /' /etc/apache2/httpd.conf || true
    sed -i 's/^LoadModule mpm_prefork_module /#LoadModule mpm_prefork_module /' /etc/apache2/httpd.conf || true

    if ! grep -q '^ServerName ' /etc/apache2/httpd.conf; then
        printf '\nServerName localhost\n' >> /etc/apache2/httpd.conf
    fi

    if ! grep -q '<Directory "/var/www/html">' /etc/apache2/httpd.conf; then
cat >> /etc/apache2/httpd.conf <<EOF

<Directory "/var/www/html">
    AllowOverride All
    Require all granted
    DirectoryIndex index.php index.html
</Directory>
EOF
    fi

    cat > /etc/apache2/conf.d/lampdeck-php-fpm.conf <<EOF
<FilesMatch \.php$>
    SetHandler "proxy:unix:$PHP_FPM_SOCK|fcgi://localhost/"
</FilesMatch>
EOF

    cat > /etc/apache2/conf.d/lampdeck-phpmyadmin.conf <<EOF
Alias /phpmyadmin /usr/share/webapps/phpmyadmin

<Directory "/usr/share/webapps/phpmyadmin">
    AllowOverride All
    Require all granted
    DirectoryIndex index.php
</Directory>
EOF

    cat > /etc/apache2/conf.d/lampdeck-modules.conf <<EOF
LoadModule rewrite_module modules/mod_rewrite.so
EOF

    #########################################################
    # SSL SELF-SIGNED
    #########################################################

    echo "== Checking default self-signed certificate"

    if [ ! -f /var/www/certs/server.crt ] || [ ! -f /var/www/certs/server.key ]; then
        echo "== Generating default self-signed certificate"

        openssl req -x509 -nodes -days 825 \
            -newkey rsa:2048 \
            -keyout /var/www/certs/server.key \
            -out /var/www/certs/server.crt \
            -subj "/C=BR/ST=SE/L=Aracaju/O=Local/CN=$hostname_fqdn"
    else
        echo "== Existing default certificate found. Keeping current files."
    fi

    #########################################################
    # VHOSTS PADRÃO
    #########################################################

    cat > /etc/apache2/conf.d/lampdeck-default.conf <<EOF
<VirtualHost *:80>
    DocumentRoot /var/www/html

    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/\.well-known/acme-challenge/
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
</VirtualHost>

<IfModule mod_ssl.c>
<VirtualHost *:443>
    Protocols http/1.1
    DocumentRoot /var/www/html
    DirectoryIndex index.php index.html

    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch \.php$>
        SetHandler "proxy:unix:$PHP_FPM_SOCK|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile /var/www/certs/server.crt
    SSLCertificateKeyFile /var/www/certs/server.key
</VirtualHost>
</IfModule>
EOF

    #########################################################
    # ALIAS SUBSITES
    #########################################################

    : > /etc/apache2/conf.d/subsites-aliases.conf

    #########################################################
    # PERMISSÕES
    #########################################################

    chown -R apache:apache /var/www

    #########################################################
    # RESTART
    #########################################################

    rc-service mariadb restart || rc-service mariadb start
    rc-service redis restart || rc-service redis start
    rc-service "$PHP_FPM_SERVICE" restart || rc-service "$PHP_FPM_SERVICE" start
    rc-service apache2 restart || rc-service apache2 start

    echo
    echo "============================================"
    echo "Alpine package stack installed."
    echo "============================================"
    echo
}
