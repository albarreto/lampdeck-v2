#!/bin/bash

###############################################################################
# LAMP Deck package installer
# Target: Ubuntu 24.04.4 LTS (Noble)
#
# Description:
#   Installs the package set required by LAMP Deck on Ubuntu 24.04 LTS
#
# Installs:
#   Apache2
#   PHP 8.3 (FPM)
#   MariaDB 10.11 (native)
#   Redis
#   Certbot
#   phpMyAdmin
#
# Project:
#   LAMP Deck
#   https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
#   GPL-3.0-or-later
###############################################################################

set -euo pipefail

install_ubuntu_24_04_packages() {

    export DEBIAN_FRONTEND=noninteractive

    local timezone="${TIMEZONE:-America/Maceio}"
    local hostname_fqdn="${HOSTNAME_FQDN:-server.local}"

    echo "== Updating system"
    apt update
    apt upgrade -y

    echo "== Base packages"
    apt install -y \
        ca-certificates \
        curl \
        wget \
        gnupg \
        lsb-release \
        apt-transport-https \
        unzip \
        zip \
        rsync \
        nano \
        vim \
        htop \
        tar \
        openssl

    #########################################################
    # APACHE
    #########################################################

    echo "== Installing Apache"
    apt install -y apache2 apache2-utils

    a2dismod mpm_prefork 2>/dev/null || true
    a2enmod mpm_event proxy_fcgi setenvif rewrite headers expires ssl http2 deflate alias env dir mime

    systemctl enable apache2

    #########################################################
    # PHP 8.3 (native Ubuntu Noble)
    #########################################################

    local php_version="8.3"

    echo "== Installing native PHP ${php_version}"

    apt install -y \
        php${php_version}-fpm \
        php${php_version}-cli \
        php${php_version}-common \
        php${php_version}-mysql \
        php${php_version}-curl \
        php${php_version}-gd \
        php${php_version}-intl \
        php${php_version}-mbstring \
        php${php_version}-xml \
        php${php_version}-zip \
        php${php_version}-bcmath \
        php${php_version}-soap \
        php${php_version}-opcache \
        php${php_version}-readline \
        php${php_version}-redis

    echo "== Installing optional PHP Imagick"

    if ! apt install -y php-imagick; then
        echo "WARNING: php-imagick could not be installed (dependency conflict). Continuing without Imagick."
    fi

    a2enconf php${php_version}-fpm
    systemctl enable php${php_version}-fpm

    #########################################################
    # REDIS
    #########################################################

    echo "== Installing Redis"
    apt install -y redis-server
    systemctl enable redis-server

    #########################################################
    # CERTBOT
    #########################################################

    echo "== Installing Certbot"
    apt install -y certbot python3-certbot-apache

    #########################################################
    # MARIADB NATIVO
    #########################################################

    echo "== Installing MariaDB"
    apt install -y mariadb-server mariadb-client

    systemctl enable mariadb

    #########################################################
    # SET ROOT PASSWORD
    #########################################################

    if [ -n "${DB_ROOT_PASS:-}" ]; then
        echo "== Configuring MariaDB root password"

        mariadb <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT_PASS}';
FLUSH PRIVILEGES;
EOF
    fi

    #########################################################
    # AJUSTES PHP PERFORMANCE WP
    #########################################################

    for ini in /etc/php/${php_version}/fpm/php.ini /etc/php/${php_version}/cli/php.ini
    do
        sed -i 's/^memory_limit = .*/memory_limit = 512M/' "$ini"
        sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 256M/' "$ini"
        sed -i 's/^post_max_size = .*/post_max_size = 256M/' "$ini"
        sed -i 's/^max_execution_time = .*/max_execution_time = 300/' "$ini"
        sed -i 's/^max_input_vars = .*/max_input_vars = 5000/' "$ini" || true

        grep -q "^date.timezone" "$ini" \
            && sed -i "s#^date.timezone.*#date.timezone = ${timezone}#" "$ini" \
            || echo "date.timezone = ${timezone}" >> "$ini"
    done

    #########################################################
    # OPCACHE
    #########################################################

    cat > /etc/php/${php_version}/mods-available/opcache.ini <<EOF
zend_extension=opcache.so
opcache.enable=1
opcache.enable_cli=0
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=40000
opcache.validate_timestamps=1
opcache.revalidate_freq=2
opcache.save_comments=1
EOF

    #########################################################
    # PHP-FPM POOL
    #########################################################

    local pool="/etc/php/${php_version}/fpm/pool.d/www.conf"

    sed -i 's/^pm = .*/pm = dynamic/' "$pool"
    sed -i 's/^pm.max_children = .*/pm.max_children = 40/' "$pool"
    sed -i 's/^pm.start_servers = .*/pm.start_servers = 4/' "$pool"
    sed -i 's/^pm.min_spare_servers = .*/pm.min_spare_servers = 2/' "$pool"
    sed -i 's/^pm.max_spare_servers = .*/pm.max_spare_servers = 6/' "$pool"
    grep -q '^pm.max_requests' "$pool" || echo 'pm.max_requests = 500' >> "$pool"

    #########################################################
    # MYSQL TUNING
    #########################################################

if [ "$DB_ALREADY_INSTALLED" -eq 0 ]; then
    echo "== Installing phpMyAdmin"

    if [ -z "${DB_ROOT_PASS:-}" ]; then
        echo "ERROR: DB_ROOT_PASS is required to configure phpMyAdmin."
        exit 1
    fi

    local pma_db="phpmyadmin"
    local pma_user="phpmyadmin"
    local pma_pass="${DB_ROOT_PASS}"

    echo "phpmyadmin phpmyadmin/dbconfig-install boolean false" | debconf-set-selections
    echo "phpmyadmin phpmyadmin/reconfigure-webserver multiselect apache2" | debconf-set-selections

    apt install -y phpmyadmin

    echo "== Configuring phpMyAdmin database"

    mariadb -u root -p"${DB_ROOT_PASS}" -e "
    CREATE DATABASE IF NOT EXISTS \`${pma_db}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    CREATE USER IF NOT EXISTS '${pma_user}'@'localhost' IDENTIFIED BY '${pma_pass}';
    ALTER USER '${pma_user}'@'localhost' IDENTIFIED BY '${pma_pass}';
    GRANT ALL PRIVILEGES ON \`${pma_db}\`.* TO '${pma_user}'@'localhost';
    FLUSH PRIVILEGES;
    "

    if [ -f /usr/share/phpmyadmin/sql/create_tables.sql ]; then
        mariadb -u root -p"${DB_ROOT_PASS}" "${pma_db}" < /usr/share/phpmyadmin/sql/create_tables.sql
    elif [ -f /usr/share/dbconfig-common/data/phpmyadmin/install/mysql ]; then
        mariadb -u root -p"${DB_ROOT_PASS}" "${pma_db}" < /usr/share/dbconfig-common/data/phpmyadmin/install/mysql
    else
        echo "ERROR: phpMyAdmin internal SQL file not found."
        exit 1
    fi

    cat > /etc/phpmyadmin/config-db.php <<EOF
<?php
\$dbserver='localhost';
\$dbport='';
\$dbuser='${pma_user}';
\$dbpass='${pma_pass}';
\$basepath='';
\$dbname='${pma_db}';
\$dbtype='mysqli';
EOF

    cat > /etc/apache2/conf-available/phpmyadmin.conf <<EOF
Alias /phpmyadmin /usr/share/phpmyadmin

<Directory /usr/share/phpmyadmin>
    Require all granted
    AllowOverride All
</Directory>
EOF

    a2enconf phpmyadmin >/dev/null 2>&1 || true

fi


    #########################################################
    # WWW BASE
    #########################################################

    mkdir -p /var/www/html
    mkdir -p /var/www/certs

    #########################################################
    # SERVERNAME GLOBAL
    #########################################################

    cat > /etc/apache2/conf-available/servername.conf <<EOF
ServerName localhost
EOF

    a2enconf servername >/dev/null 2>&1 || true

    #########################################################
    # SSL SELF-SIGNED PADRÃO
    #########################################################

    echo "== Checking default self-signed certificate"

    if [ ! -f /var/www/certs/server.crt ] || [ ! -f /var/www/certs/server.key ]; then
        echo "== Generating default self-signed certificate"

        openssl req -x509 -nodes -days 825 \
            -newkey rsa:2048 \
            -keyout /var/www/certs/server.key \
            -out /var/www/certs/server.crt \
            -subj "/C=BR/ST=SE/L=Aracaju/O=Local/CN=$hostname_fqdn"
    else
        echo "== Existing default certificate found. Keeping current files."
    fi

    #########################################################
    # VHOSTS PADRÃO
    #########################################################

    cat > /etc/apache2/sites-available/000-default.conf <<EOF
<VirtualHost *:80>
    DocumentRoot /var/www/html

    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/\.well-known/acme-challenge/
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
</VirtualHost>
EOF

    cat > /etc/apache2/sites-available/default-ssl.conf <<EOF
<IfModule mod_ssl.c>
<VirtualHost *:443>
    DocumentRoot /var/www/html
    DirectoryIndex index.php index.html

    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch \.php$>
        SetHandler "proxy:unix:/run/php/php${php_version}-fpm.sock|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile /var/www/certs/server.crt
    SSLCertificateKeyFile /var/www/certs/server.key
</VirtualHost>
</IfModule>
EOF

    a2ensite 000-default >/dev/null 2>&1 || true
    a2ensite default-ssl >/dev/null 2>&1 || true

    #########################################################
    # ALIAS SUBSITES
    #########################################################

    if [ ! -f /etc/apache2/conf-available/subsites-aliases.conf ]; then
        : > /etc/apache2/conf-available/subsites-aliases.conf
    fi

    a2enconf subsites-aliases >/dev/null 2>&1 || true

    #########################################################
    # PERMISSÕES
    #########################################################

    chown -R www-data:www-data /var/www

    #########################################################
    # RESTART
    #########################################################

    systemctl restart php${php_version}-fpm
    systemctl restart mariadb
    systemctl restart apache2
    systemctl restart redis-server

    echo
    echo "============================================"
    echo "Ubuntu 24.04 package stack installed."
    echo "============================================"
    echo
}
