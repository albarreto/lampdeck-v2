#!/bin/bash

###############################################################################
# LAMP Deck package installer
# Target: Debian 13 (Trixie)
#
# Description:
#   Installs the package set required by LAMP Deck on Debian 13 Trixie
#
# Installs:
#   Apache2
#   PHP 8.4 (FPM, native)
#   MariaDB 11 (native)
#   Redis
#   Certbot
#   phpMyAdmin
#
# Project:
#   LAMP Deck
#   https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
#   GPL-3.0-or-later
###############################################################################

set -euo pipefail

install_debian_trixie_packages() {

    export DEBIAN_FRONTEND=noninteractive

    local timezone="${TIMEZONE:-America/Maceio}"
    local app_version="${APP_VERSION:-2.0.0}"
    local hostname_fqdn="${HOSTNAME_FQDN:-server.local}"

    echo "== Updating system"
    apt update
    apt upgrade -y

    echo "== Base packages"
    apt install -y \
        ca-certificates \
        curl \
        wget \
        gnupg \
        lsb-release \
        apt-transport-https \
        unzip \
        zip \
        rsync \
        nano \
        vim \
        htop \
        tar \
        openssl

    #########################################################
    # APACHE
    #########################################################

    echo "== Installing Apache"
    apt install -y apache2 apache2-utils

    a2dismod mpm_prefork 2>/dev/null || true
    a2enmod mpm_event proxy_fcgi setenvif rewrite headers expires ssl http2 deflate alias env dir mime

    systemctl enable apache2

    #########################################################
    # PHP 8.4 NATIVO
    #########################################################

    echo "== Installing PHP 8.4"
    apt install -y \
        php8.4-fpm \
        php8.4-cli \
        php8.4-common \
        php8.4-mysql \
        php8.4-curl \
        php8.4-gd \
        php8.4-intl \
        php8.4-mbstring \
        php8.4-xml \
        php8.4-zip \
        php8.4-bcmath \
        php8.4-soap \
        php8.4-imagick \
        php8.4-opcache \
        php8.4-readline \
        php8.4-redis \
        php8.4-xmlrpc

    a2enconf php8.4-fpm
    systemctl enable php8.4-fpm

    #########################################################
    # REDIS
    #########################################################

    echo "== Installing Redis"
    apt install -y redis-server
    systemctl enable redis-server

    #########################################################
    # CERTBOT
    #########################################################

    echo "== Installing Certbot"
    apt install -y certbot python3-certbot-apache

    #########################################################
    # MARIADB NATIVO
    #########################################################

    echo "== Installing MariaDB"
    apt install -y mariadb-server mariadb-client

    systemctl enable mariadb

    #########################################################
    # SET ROOT PASSWORD
    #########################################################

    if [ -n "${DB_ROOT_PASS:-}" ]; then
        echo "== Configuring MariaDB root password"

        mariadb <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT_PASS}';
FLUSH PRIVILEGES;
EOF
    fi

    #########################################################
    # AJUSTES PHP PERFORMANCE WP
    #########################################################

    for ini in /etc/php/8.4/fpm/php.ini /etc/php/8.4/cli/php.ini
    do
        sed -i 's/^memory_limit = .*/memory_limit = 512M/' "$ini"
        sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 256M/' "$ini"
        sed -i 's/^post_max_size = .*/post_max_size = 256M/' "$ini"
        sed -i 's/^max_execution_time = .*/max_execution_time = 300/' "$ini"
        sed -i 's/^max_input_vars = .*/max_input_vars = 5000/' "$ini" || true

        grep -q "^date.timezone" "$ini" \
            && sed -i "s#^date.timezone.*#date.timezone = ${timezone}#" "$ini" \
            || echo "date.timezone = ${timezone}" >> "$ini"
    done

    #########################################################
    # OPCACHE
    #########################################################

    cat > /etc/php/8.4/mods-available/opcache.ini <<EOF
zend_extension=opcache.so
opcache.enable=1
opcache.enable_cli=0
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=40000
opcache.validate_timestamps=1
opcache.revalidate_freq=2
opcache.save_comments=1
EOF

    #########################################################
    # PHP-FPM POOL
    #########################################################

    local pool="/etc/php/8.4/fpm/pool.d/www.conf"

    sed -i 's/^pm = .*/pm = dynamic/' "$pool"
    sed -i 's/^pm.max_children = .*/pm.max_children = 40/' "$pool"
    sed -i 's/^pm.start_servers = .*/pm.start_servers = 4/' "$pool"
    sed -i 's/^pm.min_spare_servers = .*/pm.min_spare_servers = 2/' "$pool"
    sed -i 's/^pm.max_spare_servers = .*/pm.max_spare_servers = 6/' "$pool"
    grep -q '^pm.max_requests' "$pool" || echo 'pm.max_requests = 500' >> "$pool"

    #########################################################
    # MYSQL TUNING
    #########################################################

    cat > /etc/mysql/mariadb.conf.d/60-wp.cnf <<EOF
[mysqld]

character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

max_connections = 150

innodb_buffer_pool_size = 512M
innodb_log_file_size = 128M
innodb_flush_method = O_DIRECT

table_open_cache = 4000
thread_cache_size = 100

tmp_table_size = 64M
max_heap_table_size = 64M
EOF

    #########################################################
    # WWW BASE
    #########################################################

    mkdir -p /var/www/html
    mkdir -p /var/www/certs

    #########################################################
    # PHPMYADMIN
    #########################################################

if [ "$DB_ALREADY_INSTALLED" -eq 0 ]; then
    echo "== Installing phpMyAdmin"

    if [ -z "${DB_ROOT_PASS:-}" ]; then
        echo "ERROR: DB_ROOT_PASS is required to configure phpMyAdmin."
        exit 1
    fi

    local pma_db="phpmyadmin"
    local pma_user="phpmyadmin"
    local pma_pass="${DB_ROOT_PASS}"

    echo "phpmyadmin phpmyadmin/dbconfig-install boolean false" | debconf-set-selections
    echo "phpmyadmin phpmyadmin/reconfigure-webserver multiselect apache2" | debconf-set-selections

    apt install -y phpmyadmin

    echo "== Configuring phpMyAdmin database"

    mariadb -u root -p"${DB_ROOT_PASS}" -e "
    CREATE DATABASE IF NOT EXISTS \`${pma_db}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    CREATE USER IF NOT EXISTS '${pma_user}'@'localhost' IDENTIFIED BY '${pma_pass}';
    ALTER USER '${pma_user}'@'localhost' IDENTIFIED BY '${pma_pass}';
    GRANT ALL PRIVILEGES ON \`${pma_db}\`.* TO '${pma_user}'@'localhost';
    FLUSH PRIVILEGES;
    "

    if [ -f /usr/share/phpmyadmin/sql/create_tables.sql ]; then
        mariadb -u root -p"${DB_ROOT_PASS}" "${pma_db}" < /usr/share/phpmyadmin/sql/create_tables.sql
    elif [ -f /usr/share/dbconfig-common/data/phpmyadmin/install/mysql ]; then
        mariadb -u root -p"${DB_ROOT_PASS}" "${pma_db}" < /usr/share/dbconfig-common/data/phpmyadmin/install/mysql
    else
        echo "ERROR: phpMyAdmin internal SQL file not found."
        exit 1
    fi

    cat > /etc/phpmyadmin/config-db.php <<EOF
<?php
\$dbserver='localhost';
\$dbport='';
\$dbuser='${pma_user}';
\$dbpass='${pma_pass}';
\$basepath='';
\$dbname='${pma_db}';
\$dbtype='mysqli';
EOF

    cat > /etc/apache2/conf-available/phpmyadmin.conf <<EOF
Alias /phpmyadmin /usr/share/phpmyadmin

<Directory /usr/share/phpmyadmin>
    Require all granted
    AllowOverride All
</Directory>
EOF

    a2enconf phpmyadmin >/dev/null 2>&1 || true

fi

    #########################################################
    # SERVERNAME GLOBAL
    #########################################################

    cat > /etc/apache2/conf-available/servername.conf <<EOF
ServerName localhost
EOF

    a2enconf servername >/dev/null 2>&1 || true

    #########################################################
    # SSL SELF-SIGNED PADRÃO
    #########################################################

    echo "== Checking default self-signed certificate"

    if [ ! -f /var/www/certs/server.crt ] || [ ! -f /var/www/certs/server.key ]; then
        echo "== Generating default self-signed certificate"

        openssl req -x509 -nodes -days 825 \
            -newkey rsa:2048 \
            -keyout /var/www/certs/server.key \
            -out /var/www/certs/server.crt \
            -subj "/C=BR/ST=SE/L=Aracaju/O=Local/CN=$hostname_fqdn"
    else
        echo "== Existing default certificate found. Keeping current files."
    fi

    #########################################################
    # VHOSTS PADRÃO
    #########################################################

    cat > /etc/apache2/sites-available/000-default.conf <<EOF
<VirtualHost *:80>
    DocumentRoot /var/www/html

    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/\.well-known/acme-challenge/
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
</VirtualHost>
EOF

    cat > /etc/apache2/sites-available/default-ssl.conf <<EOF
<IfModule mod_ssl.c>
<VirtualHost *:443>
    DocumentRoot /var/www/html
    DirectoryIndex index.php index.html

    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch \.php$>
        SetHandler "proxy:unix:/run/php/php8.4-fpm.sock|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile /var/www/certs/server.crt
    SSLCertificateKeyFile /var/www/certs/server.key
</VirtualHost>
</IfModule>
EOF

    a2ensite 000-default >/dev/null 2>&1 || true
    a2ensite default-ssl >/dev/null 2>&1 || true

    #########################################################
    # ALIAS SUBSITES
    #########################################################

    if [ ! -f /etc/apache2/conf-available/subsites-aliases.conf ]; then
        : > /etc/apache2/conf-available/subsites-aliases.conf
    fi

    a2enconf subsites-aliases >/dev/null 2>&1 || true

    #########################################################
    # PERMISSÕES
    #########################################################

    chown -R www-data:www-data /var/www

    #########################################################
    # RESTART
    #########################################################

    systemctl restart php8.4-fpm
    systemctl restart mariadb
    systemctl restart apache2
    systemctl restart redis-server

    echo
    echo "============================================"
    echo "Debian Trixie package stack installed."
    echo "============================================"
    echo
}
