#!/bin/bash

###############################################################################
# LAMP Deck app common helpers
#
# Shared helpers for app modules with or without database.
###############################################################################

set -euo pipefail

APP_HAS_DB="${APP_HAS_DB:-0}"
APP_SLUG="${APP_SLUG:-}"             # Example: wordpress
APP_NAME="${APP_NAME:-}"             # Example: WordPress
APP_CACHE_FILE="${APP_CACHE_FILE:-}" # Example: /tmp/wordpress-latest.tar.gz
APP_DOWNLOAD_URL="${APP_DOWNLOAD_URL:-}" # Example: https://wordpress.org/latest.tar.gz

ROLLBACK_NEEDED=0
APP_TMP_DIR=""
DB_ROOT_PASS=""

app_require_metadata() {
    if [ -z "$APP_SLUG" ] || [ -z "$APP_NAME" ]; then
        echo "ERROR: APP_SLUG and APP_NAME must be defined in the app module."
        exit 1
    fi
}

app_set_defaults() {
    APP_CACHE_FILE="${APP_CACHE_FILE:-/tmp/${APP_SLUG}-latest.tar.gz}"
}

app_usage() {
    echo "Usage: lampdeck install $APP_SLUG <site-name> [description]"
}

app_init_site_vars() {
    SITE="$(normalize_site_name "${1:-}")"
    DESC="${2:-}"
    BASE="$WWW_ROOT/$SITE"
    SERVER_IP="$(get_server_ip)"
}

app_init_db_vars() {
    DB_NAME="$SITE"
    DB_USER="$SITE"
    DB_PASS="$(openssl rand -base64 18 | tr -dc 'a-zA-Z0-9' | head -c16)"
}

app_validate_inputs() {
    validate_required_site_name \
        "$SITE" \
        "$(app_usage)" \
        || exit 1

    validate_site_name_format "$SITE" || exit 1
    validate_site_not_exists "$BASE" || exit 1
}

app_cleanup_on_exit() {
    local exit_code=$?

    if [ "$exit_code" -ne 0 ] && [ "$ROLLBACK_NEEDED" = "1" ]; then
        echo
        echo "Installation failed or cancelled. Removing created site..."
        remove_site "$SITE" || true
    fi
}

app_setup_rollback() {
    trap app_cleanup_on_exit EXIT
}

app_enable_rollback() {
    ROLLBACK_NEEDED=1
}

app_disable_rollback() {
    ROLLBACK_NEEDED=0
    trap - EXIT
}

app_print_header() {
    echo
    echo "============================================"
    echo "Installing $APP_NAME: $SITE"
    echo "============================================"
    echo
}

app_prompt_and_validate_db_root() {
    DB_ROOT_PASS="$(db_prompt_root_password)"

    db_validate_root "$DB_ROOT_PASS" || {
        echo "ABORTING installation."
        exit 1
    }
}

app_create_base_site_structure() {

    if [ -e "$BASE" ]; then
        echo
        echo "Error: website folder already exists:"
        echo "  $BASE"
        echo
        echo "Installation ABORTED to avoid overwriting existing content."
        echo
        exit 1
    fi

    mkdir -p "$BASE"

    if [ ! -f "$SUBSITES_CONF" ]; then
        touch "$SUBSITES_CONF"
    fi

    if ! grep -q "Alias /$SITE/" "$SUBSITES_CONF" 2>/dev/null; then

        cat >> "$SUBSITES_CONF" <<EOT

RedirectMatch 302 ^/$SITE$ /$SITE/

Alias /$SITE/ $BASE/

<Directory $BASE/>
    AllowOverride All
    Require all granted
    DirectoryIndex index.php index.html
</Directory>

EOT

    fi

    app_enable_rollback
}

app_create_database_or_abort() {
    if ! db_create_database "$DB_ROOT_PASS" "$DB_NAME" "$DB_USER" "$DB_PASS"; then
        echo
        echo "Installation aborted."
        return 1 2>/dev/null || exit 1
    fi

    unset DB_ROOT_PASS
}

app_prepare_with_db() {

    app_require_metadata
    app_set_defaults

    app_init_site_vars "${1:-}" "${2:-}"
    app_init_db_vars

    app_setup_rollback

    app_validate_inputs

    app_print_header

    app_prompt_and_validate_db_root

    echo "Creating base website..."
    app_create_base_site_structure

    echo
    echo "Preparing database..."

    app_create_database_or_abort
}

app_prepare_no_db() {

    app_require_metadata
    app_set_defaults

    app_init_site_vars "${1:-}" "${2:-}"

    app_setup_rollback

    app_validate_inputs

    app_print_header

    echo "Creating base website..."
    app_create_base_site_structure

    echo
}

app_init_tmp_dir() {
    APP_TMP_DIR="/tmp/${APP_SLUG}"
    rm -rf "$APP_TMP_DIR"
    mkdir -p "$APP_TMP_DIR"
}

app_download_if_needed() {
    local cache_file="$1"
    local download_url="$2"

    if [ -z "$cache_file" ] || [ -z "$download_url" ]; then
        echo "ERROR: cache file and download URL are required."
        exit 1
    fi

    if [ -f "$cache_file" ] && find "$cache_file" -mtime 0 | grep -q .; then
        echo "Using cached $APP_NAME package (downloaded today)"
        return 0
    fi

    echo "Downloading $APP_NAME..."
    wget \
        --no-use-server-timestamps \
        -O "$cache_file" \
        "$download_url"
}

app_extract_archive() {

    local subdir="${1:-}"

    echo "Extracting $APP_NAME package..."

    tar xf "$APP_CACHE_FILE" -C "$APP_TMP_DIR"

    if [ -n "$subdir" ]; then

        if [ ! -d "$APP_TMP_DIR/$subdir" ]; then
            echo "ERROR: expected subdirectory '$subdir' not found in package"
            exit 1
        fi

        APP_EXTRACT_ROOT="$APP_TMP_DIR/$subdir"

    else

        APP_EXTRACT_ROOT="$APP_TMP_DIR"

    fi
}

app_copy_files_to_base() {

    echo "Copying $APP_NAME files to $BASE..."

    rsync -a "$APP_EXTRACT_ROOT/" "$BASE/"

}

app_ini_escape() {
    local value="${1:-}"
    value="${value//\\/\\\\}"
    value="${value//\"/\\\"}"
    printf '"%s"' "$value"
}

app_write_metadata() {
    cat > "$BASE/lampdeck.ini" <<EOF
[app]
type = $(app_ini_escape "${APP_SLUG}")
name = $(app_ini_escape "${APP_NAME}")
category = $(app_ini_escape "${APP_CATEGORY:-Unknown}")
has_db = ${APP_HAS_DB:-0}

[admin]
path = $(app_ini_escape "${APP_ADMIN_PATH:-}")
label = $(app_ini_escape "${APP_ADMIN_LABEL:-}")

[site]
description = $(app_ini_escape "${DESC:-}")
EOF
}

app_apply_default_permissions() {
    chown -R www-data:www-data "$BASE"
    find "$BASE" -type d -exec chmod 755 {} \;
    find "$BASE" -type f -exec chmod 644 {} \;
}

app_apply_rw_permissions() {
    local path

    for path in "$@"; do
        if [ -n "$path" ] && [ -d "$path" ]; then
            chmod -R 775 "$path"
        fi
    done
}

app_reload_apache() {
    apache2ctl configtest >/dev/null
    systemctl reload apache2
}

app_print_success_with_db() {
    echo
    echo "============================================"
    echo "$APP_NAME WEBSITE CREATED"
    echo "URL: https://$SERVER_IP/$SITE/"
    echo "DB NAME: $DB_NAME"
    echo "DB USER: $DB_USER"
    echo "PASSWORD: $DB_PASS"
    echo
    echo "NOTE: Finish installation in the browser"
    echo "============================================"
    echo
}

app_print_success_no_db() {
    echo
    echo "============================================"
    echo "$APP_NAME WEBSITE CREATED"
    echo "URL: https://$SERVER_IP/$SITE/"
    echo
    echo "NOTE: Finish installation in the browser"
    echo "============================================"
    echo
}
