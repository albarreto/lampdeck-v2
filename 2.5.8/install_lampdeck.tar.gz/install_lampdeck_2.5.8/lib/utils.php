<?php

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function format_bytes($bytes) {
    $bytes = (float)$bytes;
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;

    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }

    return number_format($bytes, ($i >= 2 ? 1 : 0), ',', '.') . ' ' . $units[$i];
}

function cmd($command) {
    $out = @shell_exec($command . ' 2>/dev/null');
    return is_string($out) ? trim($out) : '';
}
