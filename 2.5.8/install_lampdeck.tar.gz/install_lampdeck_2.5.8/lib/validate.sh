#!/bin/bash

###############################################################################
# LAMP Deck library
# validate
#
# Description:
# Shared validation helpers used by app modules and internal scripts.
# Includes:
# - bash syntax validation
# - command existence checks
# - site name normalization
# - site name validation
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

validate_bash_syntax() {
    local files=("$@")

    for f in "${files[@]}"; do
        if ! bash -n "$f"; then
            echo "Syntax error: $f"
            return 1
        fi
    done
}

validate_command() {
    local cmd="$1"

    if ! command -v "$cmd" >/dev/null 2>&1; then
        echo "Missing command: $cmd"
        return 1
    fi
}

normalize_site_name() {
    local site="$1"
    site="${site#/}"
    site="${site%/}"
    echo "$site"
}

validate_required_site_name() {
    local site="$1"
    local usage_msg="${2:-Usage: site name is required}"

    if [ -z "$site" ]; then
        echo "$usage_msg"
        return 1
    fi
}

validate_site_name_format() {
    local site="$1"

    if [[ ! "$site" =~ ^[a-zA-Z0-9.-]+$ ]]; then
        echo
        echo "Error: invalid site name"
        echo
        echo "Allowed characters:"
        echo "  letters"
        echo "  numbers"
        echo "  dot (.)"
        echo "  hyphen (-)"
        echo
        return 1
    fi
}

validate_site_not_exists() {
    local base_dir="$1"

    if [ -d "$base_dir" ]; then
        echo
        echo "ERROR: site directory already exists:"
        echo "$base_dir"
        echo
        return 1
    fi
}
