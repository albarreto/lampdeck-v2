#!/bin/bash

###############################################################################
# LAMP Deck library
# db
#
# Description:
# Shared database helpers used by app modules and internal scripts.
# Includes:
# - MariaDB root password prompt
# - MariaDB root authentication test
# - database/user creation and privilege grant
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

db_prompt_root_password() {
    local pass
    read -r -s -p "Enter MariaDB root password: " pass
    printf '\n' >&2
    printf '%s' "$pass"
}

db_validate_root() {
    local pass="$1"

    echo "Validating database access..."

    if ! mariadb -u root -p"$pass" -e "SELECT 1" >/dev/null 2>&1; then
        echo
        echo "ERROR: Cannot authenticate to MariaDB with provided root password."
        return 1
    fi

    echo "Database authentication OK"
    echo
}

db_create_database() {
    local root_pass="$1"
    local db_name="$2"
    local db_user="$3"
    local db_pass="$4"
    local db_exists=""
    local confirm=""

    echo "Preparing database..."

    db_exists="$(mariadb -u root -p"$root_pass" -N -B -e "SHOW DATABASES LIKE '${db_name}';" 2>/dev/null || true)"

    if [ "$db_exists" = "$db_name" ]; then
        echo
        echo "===================================================="
        echo "WARNING: DATABASE \"$db_name\" ALREADY EXISTS!"
        echo "ALL EXISTING DATA IN THIS DATABASE WILL BE LOST."
        echo "===================================================="
        echo
        read -r -p "Do you want to overwrite it? (y/N): " confirm

        if [ "$confirm" != "y" ]; then
            echo "Database overwrite cancelled."
            return 1
        fi

        echo "Removing existing database..."
        mariadb -u root -p"$root_pass" -e "DROP DATABASE \`${db_name}\`;"
    fi

    echo "Creating database..."

    mariadb -u root -p"$root_pass" <<SQL
CREATE DATABASE \`${db_name}\`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '${db_user}'@'localhost'
IDENTIFIED BY '${db_pass}';

ALTER USER '${db_user}'@'localhost'
IDENTIFIED BY '${db_pass}';

GRANT ALL PRIVILEGES
ON \`${db_name}\`.*
TO '${db_user}'@'localhost';

FLUSH PRIVILEGES;
SQL

    echo
}
