#!/bin/bash

###############################################################################
# LAMP Deck library
# remove-site
#
# Description:
# Shared site removal helpers used for rollback and future uninstall features.
###############################################################################

set -euo pipefail

remove_site() {
    local site="$1"
    local base="$WWW_ROOT/$site"

    if [ -z "$site" ]; then
        echo "Error: remove_site() requires a site name"
        return 1
    fi

    echo "Removing website files..."

    if [ -d "$base" ]; then
        rm -rf "$base"
    fi

    if [ -f "$SUBSITES_CONF" ]; then
        sed -i "/RedirectMatch 302 \\^\\/$site\\$ \\/$site\\//,/^$/d" "$SUBSITES_CONF" 2>/dev/null || true
    fi

    systemctl reload apache2 2>/dev/null || true

    echo "Website rollback completed."
}
