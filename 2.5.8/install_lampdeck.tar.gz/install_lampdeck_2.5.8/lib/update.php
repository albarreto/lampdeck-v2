<?php

function normalize_lampdeck_version($version) {
    return preg_replace('/-rc\..*$/', '', trim((string)$version));
}

function latest_lampdeck_version() {
    $url = 'https://raw.githubusercontent.com/albarreto/lampdeck-v2/main/latest/VERSION';
    $cacheFile = '/tmp/lampdeck-latest-version.cache';
    $cacheTtl = 3600;

    if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < $cacheTtl) {
        return trim((string)file_get_contents($cacheFile));
    }

    $latest = '';

    if (function_exists('curl_init')) {
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_TIMEOUT => 3,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => 'LAMP Deck update checker'
        ]);

        $result = curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        if ($httpCode === 200 && is_string($result)) {
            $latest = trim($result);
        }
    }

    if ($latest !== '' && preg_match('/^[0-9]+(\.[0-9]+){1,3}(-rc\.[0-9]+)?$/', $latest)) {
        @file_put_contents($cacheFile, $latest);
        return $latest;
    }

    return '';
}

function lampdeck_update_available($localVersion) {
    $latestVersion = latest_lampdeck_version();

    if ($latestVersion === '') {
        return [
            'available' => false,
            'latest' => ''
        ];
    }

    $localBase = normalize_lampdeck_version($localVersion);
    $remoteBase = normalize_lampdeck_version($latestVersion);

    if ($localBase === $remoteBase) {
        return [
            'available' => false,
            'latest' => $latestVersion
        ];
    }

    return [
        'available' => version_compare($remoteBase, $localBase, '>'),
        'latest' => $latestVersion
    ];
}
