<?php

function list_sites($basePath = '/var/www') {
    $dirs = array_filter(
        scandir($basePath),
        function ($d) use ($basePath) {
            if (!isset($d[0]) || $d[0] === '.') {
                return false;
            }

            if (in_array($d, ['html', 'certs'])) {
                return false;
            }

            return is_dir($basePath . '/' . $d);
        }
    );

    sort($dirs);
    return $dirs;
}

function lampdeck_meta($site) {
    static $cache = [];

    if (isset($cache[$site])) {
        return $cache[$site];
    }

    $file = "/var/www/$site/lampdeck.ini";

    if (!is_file($file) || !is_readable($file)) {
        return $cache[$site] = [];
    }

    $meta = parse_ini_file($file, true, INI_SCANNER_TYPED);

    return $cache[$site] = (is_array($meta) ? $meta : []);
}

function site_desc($site) {
    $meta = lampdeck_meta($site);
    return trim((string)($meta['site']['description'] ?? ''));
}

function detect_app_type($site) {
    $meta = lampdeck_meta($site);
    return strtolower(trim((string)($meta['app']['type'] ?? 'unknown')));
}

function detect_app_category($site) {
    $meta = lampdeck_meta($site);
    return trim((string)($meta['app']['category'] ?? 'unknown'));
}

function site_icon($site) {
    $type = detect_app_type($site);
    $relative = "/assets/icons/icon-{$type}.webp";
    $absolute = $_SERVER['DOCUMENT_ROOT'] . $relative;

    if (is_file($absolute)) {
        return $relative;
    }

    return "/assets/icons/icon-none.webp";
}

function site_type_label($site) {
    $meta = lampdeck_meta($site);
    $name = trim((string)($meta['app']['name'] ?? 'Unknown'));
    return $name . ' site';
}

function site_admin_path($site) {
    $meta = lampdeck_meta($site);
    return trim((string)($meta['admin']['path'] ?? ''));
}

function site_admin_label($site) {
    $meta = lampdeck_meta($site);
    return trim((string)($meta['admin']['label'] ?? ''));
}

function is_disabled_site($site) {
    return substr($site, -9) === '.disabled';
}

function base_site_name($site) {
    return is_disabled_site($site) ? substr($site, 0, -9) : $site;
}

function list_app_categories($dirs) {
    $categories = [];

    foreach ($dirs as $d) {
        $cat = detect_app_category($d);

        if ($cat === '') {
            $cat = 'unknown';
        }

        $categories[$cat] = true;
    }

    ksort($categories);

    return $categories;
}
