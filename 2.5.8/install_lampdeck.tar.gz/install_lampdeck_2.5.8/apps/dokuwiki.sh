#!/bin/bash

###############################################################################
# LAMP Deck app module
# dokuwiki
#
# Usage:
# lampdeck install dokuwiki <site-name> [description]
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="dokuwiki"
APP_NAME="DokuWiki"
APP_HAS_DB="0"
APP_CATEGORY="Wiki"
APP_ADMIN_PATH="doku.php?id=start&do=login"
APP_ADMIN_LABEL="Login"

# versão estável (pode travar depois se quiser versionamento fixo)
APP_DOWNLOAD_URL="https://download.dokuwiki.org/src/dokuwiki/dokuwiki-stable.tgz"

app_prepare_no_db "${1:-}" "${2:-}"

#########################################
# download
#########################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"

#########################################
# extract
#########################################

app_init_tmp_dir
app_extract_archive

EXTRACTED_DIR="$(find "$APP_TMP_DIR" -mindepth 1 -maxdepth 1 -type d | head -n 1)"

if [ -z "${EXTRACTED_DIR:-}" ]; then
    echo "Error: extracted directory not found"
    exit 1
fi

#########################################
# install files
#########################################

mkdir -p "$BASE"

cp -a "$EXTRACTED_DIR"/. "$BASE"/

#########################################
# permissions
#########################################

app_apply_default_permissions

# diretórios que precisam escrita
app_apply_rw_permissions \
    "$BASE/conf" \
    "$BASE/data"

#########################################
# metadata
#########################################

app_write_metadata "$APP_SLUG"

#########################################
# apache
#########################################

app_reload_apache
app_disable_rollback

#########################################
# output
#########################################

cat <<EOF

======================================================
${APP_NAME} named "${1:-}" was installed successfully
======================================================

First access (installer):
http://{URL}/install.php
EOF

app_print_success_no_db


