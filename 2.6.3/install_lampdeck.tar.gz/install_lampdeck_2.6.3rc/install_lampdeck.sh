#!/bin/bash
#
###############################################################################
#
# LAMP Deck Installer
#
# Project: https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# Description
# -----------------------------------------------------------------------------
# Automated installer for a modern LAMP stack optimized for multi-site hosting.
#
# This script installs and configures:
#
#   • Apache 2.4 (event MPM)
#   • PHP-FPM (8.x)
#   • MariaDB
#   • Redis
#   • phpMyAdmin
#   • Certbot (Let's Encrypt)
#
# It also deploys a lightweight management interface that allows:
#
#   • creation of isolated websites under /var/www
#   • automatic Apache alias configuration
#   • rapid apps deployment with database creation
#   • optional domain configuration with HTTPS
#   • centralized overview of hosted sites
#
#
# Features
# -----------------------------------------------------------------------------
#   • Multi-site structure using Apache Alias
#   • WordPress-ready PHP tuning
#   • Redis object cache support
#   • automatic database provisioning
#   • self-signed SSL by default
#   • Let's Encrypt integration
#   • clean and minimal web interface
#   • helper CLI tools:
#
#       create-domain    attach domain to site
#       install          install supported web application
#       activate-ssl     generate valid certificate
#       lamp-version     show stack versions
#
#
# License
# -----------------------------------------------------------------------------
# GNU General Public License v3.0
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License,
# or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See the GNU General Public License for more details:
#
###############################################################################

set -euo pipefail


###############################################################################
# LAMP Deck Installer
###############################################################################

SERVER_IP="$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')"
SERVER_IP="${SERVER_IP:-127.0.0.1}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

LIB_DIR="/usr/lib/lampdeck"
BIN_DIR="/usr/local/bin"
APPS_DIR="$LIB_DIR/apps"
PKG_DIR="$LIB_DIR/pkg"
ASSETS_DST="/var/www/html/assets"

echo "== Installing LAMP Deck core"

# Remove instalação anterior completamente
rm -rf "$LIB_DIR"
rm -rf "$ASSETS_DST"

# Recria estrutura
mkdir -p "$LIB_DIR" "$APPS_DIR" "$PKG_DIR" "$BIN_DIR" "$ASSETS_DST"

# Copia arquivos do pacote
cp -a "$SCRIPT_DIR/lib/." "$LIB_DIR/"
cp -a "$SCRIPT_DIR/apps/." "$APPS_DIR/"
cp -a "$SCRIPT_DIR/pkg/." "$PKG_DIR/"
cp -a "$SCRIPT_DIR/assets/." "$ASSETS_DST/"

# Permissões
chmod +x "$LIB_DIR"/*.sh 2>/dev/null || true
chmod +x "$APPS_DIR"/*.sh 2>/dev/null || true
chmod +x "$PKG_DIR"/*.sh 2>/dev/null || true

source "$LIB_DIR/common.sh"

echo
echo "============================================"
echo "$APP_NAME v$APP_VERSION INSTALLATION"
echo "============================================"
echo
echo "This installer will configure the LAMP Deck environment."
echo "Required components will be installed and configured automatically."
echo

#== Check argument --ignore-install
IGNORE_INSTALL=0

for arg in "$@"; do
    case "$arg" in
        --ignore-install)
            IGNORE_INSTALL=1
            ;;
    esac
done

#== Verify if database setup is needed
DB_ALREADY_INSTALLED=0

if command -v systemctl >/dev/null 2>&1; then

    if systemctl is-active --quiet mariadb >/dev/null 2>&1 \
        || systemctl is-active --quiet mysql >/dev/null 2>&1; then
        DB_ALREADY_INSTALLED=1
    fi

elif command -v rc-service >/dev/null 2>&1; then

    if rc-service mariadb status >/dev/null 2>&1; then
        DB_ALREADY_INSTALLED=1
    fi

fi

if [ "$DB_ALREADY_INSTALLED" -eq 0 ]; then
    echo
    echo "============================================"
    echo "LAMP DECK INSTALLATION"
    echo "============================================"
    echo
    echo "Database configuration is required."
    echo

    while true; do
        read -s -p "Enter MariaDB root password: " DB_ROOT_PASS
        echo
        read -s -p "Confirm MariaDB root password: " DB_ROOT_PASS_CONFIRM
        echo

        if [ "$DB_ROOT_PASS" != "$DB_ROOT_PASS_CONFIRM" ]; then
            echo "Passwords do not match. Try again."
            echo
            continue
        fi

        if [ -z "$DB_ROOT_PASS" ]; then
            echo "Password cannot be empty."
            echo
            continue
        fi

        break
    done

    export DB_ROOT_PASS
else
    echo
    echo "Existing MariaDB installation detected."
    echo "Keeping current MariaDB root configuration."
    echo
fi

###############################################################################
# Packages Installer
###############################################################################

echo "== Detecting Linux distribution"

if [ ! -r /etc/os-release ]; then
    echo "Error: cannot detect Linux distribution."
    exit 1
fi

. /etc/os-release

DIST_ID="${ID:-unknown}"
DIST_VERSION_ID="${VERSION_ID:-unknown}"
DIST_CODENAME="${VERSION_CODENAME:-unknown}"

echo "Detected:"
echo "  ID=$DIST_ID"
echo "  VERSION_ID=$DIST_VERSION_ID"
echo "  VERSION_CODENAME=$DIST_CODENAME"
echo

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ "$IGNORE_INSTALL" -eq 1 ]; then
    echo "== Skipping package verification/installation (--ignore-install)"
else
    case "$DIST_ID:$DIST_VERSION_ID:$DIST_CODENAME" in

        #########################################################
        # DEBIAN
        #########################################################

        debian:12:*|debian:*:bookworm)
            source "$SCRIPT_DIR/pkg/pkg_debian_bookworm.sh"
            install_debian_bookworm_packages
            ;;

        debian:13:*|debian:*:trixie)
            source "$SCRIPT_DIR/pkg/pkg_debian_trixie.sh"
            install_debian_trixie_packages
            ;;

        #########################################################
        # UBUNTU
        #########################################################

        ubuntu:22.04:*|ubuntu:*:jammy)
            source "$SCRIPT_DIR/pkg/pkg_ubuntu_jammy.sh"
            install_ubuntu_22_04_packages
            ;;

        ubuntu:24.04:*|ubuntu:*:noble)
            source "$SCRIPT_DIR/pkg/pkg_ubuntu_noble.sh"
            install_ubuntu_24_04_packages
            ;;

        ubuntu:26.04:*|ubuntu:*:resolute)
            source "$SCRIPT_DIR/pkg/pkg_ubuntu_resolute.sh"
            install_ubuntu_26_04_packages
            ;;

        #########################################################
        # ALPINE
        #########################################################

        alpine:*:*)
            source "$SCRIPT_DIR/pkg/pkg_alpine_3.sh"
            install_alpine_packages
            ;;

        #########################################################
        # DEFAULT
        #########################################################

        *)
            echo "Error: unsupported distribution/version."
            echo
            echo "Supported:"
            echo "  Alpine 3.19+ (soon)"
            echo "  Debian 12 (bookworm)"
            echo "  Debian 13 (trixie)"
            echo "  Ubuntu 22.04 (jammy)"
            echo "  Ubuntu 24.04 (noble)"
            echo
            exit 1
            ;;

    esac
fi

validate_web_user

#########################################################
# INSTALL SHARED LIBS
#########################################################

if compgen -G "$SCRIPT_DIR/lib/*.sh" > /dev/null; then
    cp "$SCRIPT_DIR"/lib/*.sh "$LIB_DIR"/
    chmod +x "$LIB_DIR"/*.sh
    echo "== Shared libraries installed."
else
    echo "== WARNING: no shared library scripts found in $SCRIPT_DIR/lib."
fi

#########################################################
# INSTALL APP MODULES
#########################################################

if compgen -G "$SCRIPT_DIR/apps/*.sh" > /dev/null; then
    cp "$SCRIPT_DIR"/apps/*.sh "$APPS_DIR"/
    chmod +x "$APPS_DIR"/*.sh
    echo "== Apps installed."
else
    echo "== WARNING: no app modules found in $SCRIPT_DIR/apps."
fi

#########################################################
# MAIN CLI
#########################################################
cat > "$BIN_DIR/lampdeck" <<'EOF'
#!/bin/bash

###############################################################################
# LAMP Deck - main CLI
# Description: Central command line interface for LAMP Deck
#
# Project: https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="__LIB_DIR__"

run_module() {
    local module="${1-}"

    if [ -z "$module" ]; then
        echo "Error: run_module() called without module name"
        exit 1
    fi

    shift || true

    local target="$LIB_DIR/$module"

    if [ ! -f "$target" ]; then
        if [[ "$module" == apps/*\.sh ]]; then
            local app_name

            local SUPPORTED_APPS=("html" "php" "wordpress" "joomla" "grav" "dokuwiki" "mediawiki" "dolibarr")

            app_name="$(basename "$module" .sh)"

            echo "Error: unsupported app \"$app_name\"."
            echo "Currently supported apps:"
            for app in "${SUPPORTED_APPS[@]}"; do
                echo "- $app"
            done
        else    
            echo "Error: module not found: $target"
        fi
        exit 1
    fi

    if [ ! -x "$target" ]; then
        chmod +x "$target" 2>/dev/null || true
    fi

    "$target" "$@"
}

if [ ! -d "$LIB_DIR" ]; then
    echo "Error: auxiliary directory not found: $LIB_DIR"
    echo "LAMP Deck is not correctly installed."
    exit 1
fi

CMD="${1:-}"

case "$CMD" in
    install)
        shift
        APP="${1:-}"

        if [ -z "$APP" ]; then
            echo "Usage: lampdeck install <app> <site> [description] [-d <domain>]"
            exit 1
        fi

        shift

        SITE=""
        DOMAIN=""
        DESCRIPTION_PARTS=()

        while [ $# -gt 0 ]; do
            case "$1" in
                -d)
                    if [ -n "$DOMAIN" ]; then
                        echo "Error: domain already informed."
                        exit 1
                    fi

                    shift

                    if [ $# -eq 0 ] || [ -z "${1:-}" ] || [[ "$1" == -* ]]; then
                        echo "Error: option -d requires a domain."
                        echo "Usage: lampdeck install <app> <site> [description] [-d <domain>]"
                        exit 1
                    fi

                    DOMAIN="$1"
                    ;;
                -*)
                    echo "Error: unknown option: $1"
                    echo "Usage: lampdeck install <app> <site> [description] [-d <domain>]"
                    exit 1
                    ;;
                *)
                    if [ -z "$SITE" ]; then
                        SITE="$1"
                    else
                        DESCRIPTION_PARTS+=("$1")
                    fi
                    ;;
            esac
            shift
        done

        if [ -z "$SITE" ]; then
            echo "Usage: lampdeck install <app> <site> [description] [-d <domain>]"
            exit 1
        fi

        DESCRIPTION="${DESCRIPTION_PARTS[*]}"

        run_module "apps/$APP.sh" "$SITE" "$DESCRIPTION"

        if [ -n "$DOMAIN" ]; then
            "$LIB_DIR/create-domain.sh" "$DOMAIN" "$SITE"
        fi
        ;;

    create-domain)
        shift
        run_module "create-domain.sh" "$@"
        ;;

    activate-ssl)
        shift
        run_module "activate-ssl.sh" "$@"
        ;;

    sites)
        shift
        run_module "sites.sh" "$@"
        ;;

    version)
        shift
        run_module "version.sh" "$@"
        ;;

    --help|-h|help|"")
        shift || true
        run_module "help.sh" "$@"
        ;;

    enable)
        shift
        run_module "enable-disable.sh" "enable" "$@"
        ;;

    disable)
        shift
        run_module "enable-disable.sh" "disable" "$@"
        ;;

    *)
        echo "Unknown command: $CMD"
        echo
        run_module "help.sh"
        exit 1
        ;;
esac
EOF

sed -i "s|__LIB_DIR__|$LIB_DIR|g" "$BIN_DIR/lampdeck"
chmod +x "$BIN_DIR/lampdeck"


#########################################################
# MODULE: help
#########################################################

cat > $LIB_DIR/help.sh <<EOF
#!/bin/bash

###############################################################################
# ${APP_NAME} module
# help
#
# Description:
# Displays command usage information
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License:
# GPL-3.0-or-later
###############################################################################

cat <<HELP

${APP_NAME} v${APP_VERSION}
Multisite manager for LAMP servers

USAGE
  lampdeck <command> [options]

ALSO
  lampdeck help
  lampdeck -h
  lampdeck --help

COMMANDS

  install <app> <site> [description] [-d <domain>]
      Install a supported web application
      -d <domain>   Create and configure a domain for the installed site

  create-domain <domain> <site>
      Configure Apache vhost for an existing site

  activate-ssl <domain>
      Enable Let's Encrypt SSL certificate

  sites
      List installed sites

  version (or -h --help)
      Show installed version

  disable <site>
      Disable a site by renaming its folder to <site>.disabled

  enable <site>
      Re-enable a previously disabled site

EXAMPLES

  lampdeck install html "Static Page"
  lampdeck install php "Internal PHP system"
  lampdeck install wordpress blog "Corporate website"
  lampdeck create-domain blog.example.com blog
  lampdeck activate-ssl blog.example.com
  lampdeck disable blog
  lampdeck enable blog

SUPPORTED APPS
  HTML
  PHP
  Wordpress
  Joomla
  Grav
  DokuWiki
  MediaWiki

PROJECT
  https://github.com/albarreto/lampdeck-v2

HELP

EOF

chmod +x $LIB_DIR/help.sh

#########################################################
# MODULE: version
#########################################################

cat > "$LIB_DIR/version.sh" <<'EOF'
#!/bin/bash

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

echo
echo "${APP_NAME} v${APP_VERSION}"
echo

# OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    echo "OS Release: $PRETTY_NAME"
fi

# WebServer
if command -v apache2 >/dev/null 2>&1; then
    APACHE_VERSION="$(apache2 -v | awk -F': ' '/Server version/ {print $2}')"
    echo "WebServer:  $APACHE_VERSION"

elif command -v httpd >/dev/null 2>&1; then
    APACHE_VERSION="$(httpd -v | awk -F': ' '/Server version/ {print $2}')"
    echo "WebServer:  $APACHE_VERSION"
fi

# PHP
PHP_VERSION="$(get_php_fpm_version)"

if [ -n "$PHP_VERSION" ]; then
    PHP_VERSION="$(echo "$PHP_VERSION" | sed -E 's/^([0-9]+\.[0-9]+\.[0-9]+).*/\1/')"
    echo "PHP:        $PHP_VERSION"
fi

# MariaDB / MySQL
if command -v mariadb >/dev/null 2>&1 || command -v mysql >/dev/null 2>&1; then
    DB_VERSION="$(mariadb -N -B -e "SELECT VERSION();" 2>/dev/null || true)"

    if [ -z "$DB_VERSION" ] && command -v mariadb >/dev/null 2>&1; then
        DB_VERSION="$(mariadb --version | sed -E 's/.* ([0-9]+\.[0-9]+\.[0-9]+[-A-Za-z0-9\.]*).*/\1/')"
    fi

    if [ -z "$DB_VERSION" ] && command -v mysql >/dev/null 2>&1; then
        DB_VERSION="$(mysql --version | sed -E 's/.*Distrib ([0-9]+\.[0-9]+\.[0-9]+).*/\1/')"
    fi

    if [ -n "$DB_VERSION" ]; then
        echo "MariaDB:    $DB_VERSION"
    fi
fi

# Redis
if command -v redis-server >/dev/null 2>&1; then
    REDIS_VERSION="$(redis-server --version | awk '{print $3}' | cut -d= -f2)"
    echo "Redis:      $REDIS_VERSION"
fi

echo
EOF

chmod +x "$LIB_DIR/version.sh"

#########################################################
# MODULE: sites
#########################################################

cat > "$LIB_DIR/sites.sh" <<'EOF'
#!/bin/bash

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

SERVER_IP="$(get_server_ip)"

if [ ! -d "$WWW_ROOT" ]; then
    echo "Error: $WWW_ROOT not found."
    exit 1
fi

site_type() {
    local base="$1"
    local ini="$base/lampdeck.ini"

    if [ -f "$ini" ]; then
        awk -F '=' '
            function clean(v) {
                gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
                gsub(/^"/, "", v)
                gsub(/"$/, "", v)
                return tolower(v)
            }

            /^\[app\]/ { in_app=1; next }
            /^\[/ && !/^\[app\]/ { in_app=0 }

            in_app && $1 ~ /^[[:space:]]*type[[:space:]]*$/ {
                print clean($2)
                exit
            }
        ' "$ini"
    else
        echo "unknown"
    fi
}

site_desc() {
    local base="$1"
    local ini="$base/lampdeck.ini"

    if [ -f "$ini" ]; then
        awk -F '=' '
            function clean(v) {
                gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
                gsub(/^"/, "", v)
                gsub(/"$/, "", v)
                return v
            }

            /^\[site\]/ { in_site=1; next }
            /^\[/ && !/^\[site\]/ { in_site=0 }

            in_site && $1 ~ /^[[:space:]]*description[[:space:]]*$/ {
                print clean($2)
                exit
            }
        ' "$ini"
    else
        echo ""
    fi
}

site_domain() {
    local base="$1"
    local result=""

    result=$(
        grep -Ril "DocumentRoot[[:space:]]\+$base" "$APACHE_SITES_AVAILABLE" 2>/dev/null \
        | while read -r conf; do
            awk '/^[[:space:]]*ServerName[[:space:]]+/ { print $2; exit }' "$conf"
          done \
        | head -n 1
    )

    echo "${result:-}"
}

site_url() {
    local site="$1"
    local domain="$2"

    if [ -n "$domain" ]; then
        echo "https://$domain"
    else
        echo "https://$SERVER_IP/$site/"
    fi
}

print_header() {
    printf "%-22s %-10s %-35s %-28s %-50s\n" \
        "SITE" "TYPE" "URL" "DOMAIN" "DESCRIPTION"

    printf "%-22s %-10s %-35s %-28s %-50s\n" \
        "----------------------" \
        "----------" \
        "-----------------------------------" \
        "----------------------------" \
        "--------------------------------------------------"
}

FOUND=0
print_header

for base in "$WWW_ROOT"/*; do
    [ -d "$base" ] || continue

    site="$(basename "$base")"

    case "$site" in
        html|certs|localhost|logs|run|modules|*.disabled)
            continue
            ;;
    esac

    FOUND=1

    type="$(site_type "$base")"
    domain="$(site_domain "$base")"
    url="$(site_url "$site" "$domain")"
    desc="$(site_desc "$base")"

    printf "%-22s %-10s %-35s %-28s %-50s\n" \
        "$site" \
        "$type" \
        "$url" \
        "${domain:--}" \
        "$desc"
done

if [ "$FOUND" -eq 0 ]; then
    echo "No websites found in $WWW_ROOT."
fi
EOF

chmod +x "$LIB_DIR/sites.sh"



#########################################################
# MODULE: create-domain
#########################################################

cat > $LIB_DIR/create-domain.sh <<'EOF'
#!/bin/bash

###############################################################################
# create-domain
#
# Description:
# Creates a new domain for an existing site
#
# Project:
# https://github.com/albarreto/lampdeck-v2
#
# Copyright (C) 2026 Aurélio Barreto
#
# License
# -----------------------------------------------------------------------------
# SPDX-License-Identifier: GPL-3.0-or-later
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

PHP_FPM_SOCKET="$(get_php_fpm_socket)"

if [ -z "$PHP_FPM_SOCKET" ]; then
    echo "Error: PHP-FPM socket not found."
    exit 1
fi

if [ $# -lt 2 ]; then
    echo "How to Use: lampdeck create-domain <domain> <folder>"
    echo "e.g. lampdeck create-domain acme.local acme"
    exit 1
fi

DOMAIN="$1"
SITE="$2"
BASE="$WWW_ROOT/$SITE"

if [ ! -d "$BASE" ]; then
    echo "Error: folder $BASE does not exist."
    exit 1
fi

CONF="$APACHE_SITES_AVAILABLE/$DOMAIN.conf"

grep -q "Alias /$SITE/" "$SUBSITES_CONF" 2>/dev/null || {
    {
        echo "RedirectMatch 301 ^/$SITE\$ /$SITE/"
        echo "Alias /$SITE/ $BASE/"
        echo
        echo "<Directory $BASE>"
        echo "    AllowOverride All"
        echo "    Require all granted"
        echo "    Options FollowSymLinks"
        echo "</Directory>"
        echo
    } >> "$SUBSITES_CONF"
}


###############################################################################
# Domain vhost for selected site
###############################################################################

cat > "$CONF" <<EOVHOST
<VirtualHost *:80>
    ServerName $DOMAIN
    ServerAlias www.$DOMAIN

    DocumentRoot $BASE
    DirectoryIndex index.php index.html

    <Directory $BASE>
        AllowOverride All
        Require all granted
        Options FollowSymLinks
    </Directory>

    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/\.well-known/acme-challenge/
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]

    ErrorLog ${APACHE_LOG_DIR}/${DOMAIN}-error.log
    CustomLog ${APACHE_LOG_DIR}/${DOMAIN}-access.log combined
</VirtualHost>

<VirtualHost *:443>
    ServerName $DOMAIN
    ServerAlias www.$DOMAIN

    Protocols h2 http/1.1
    DocumentRoot $BASE
    DirectoryIndex index.php index.html

    <Directory $BASE>
        AllowOverride All
        Require all granted
        Options FollowSymLinks
    </Directory>

    <FilesMatch \.php$>
        SetHandler "proxy:unix:$PHP_FPM_SOCKET|fcgi://localhost/"
    </FilesMatch>

    SSLEngine on
    SSLCertificateFile $CERT_DIR/server.crt
    SSLCertificateKeyFile $CERT_DIR/server.key

    ErrorLog ${APACHE_LOG_DIR}/${DOMAIN}-ssl-error.log
    CustomLog ${APACHE_LOG_DIR}/${DOMAIN}-ssl-access.log combined
</VirtualHost>
EOVHOST

apache_enable_site "$DOMAIN.conf" >/dev/null 2>&1 || true


apache_reload

SERVER_IP="$(get_server_ip)"

echo
echo "Domain created successfully:"
echo "  Domain: $DOMAIN"
echo "  Folder: $BASE"
echo
echo "General access remains:"
echo "  https://$SERVER_IP/"
echo
echo "Site by IP path remains:"
echo "  https://$SERVER_IP/$SITE/"
echo
echo "Domain access:"
echo "  https://$DOMAIN"
echo
echo "*** IMPORTANT: DON'T FORGET TO configure DNS or local hosts file!"
echo
echo "Then issue a genuine SSL certificate with:"
echo "  lampdeck activate-ssl $DOMAIN"
EOF

chmod +x $LIB_DIR/create-domain.sh

#########################################################
# MODULE: activate-ssl
#########################################################

cat > "$LIB_DIR/activate-ssl.sh" <<'EOF'
#!/bin/bash

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(dirname "$(realpath "$0")")}"
source "$LIB_DIR/common.sh"

DOMAIN="${1:-}"

if [ -z "$DOMAIN" ]; then
    echo "How to Use: lampdeck activate-ssl domain.com"
    exit 1
fi

certbot --apache -d "$DOMAIN"
EOF

chmod +x "$LIB_DIR/activate-ssl.sh"


############################################
# Install assets
############################################

echo "== Creating assets"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

ASSETS_SRC="$SCRIPT_DIR/assets"
ASSETS_DST="/var/www/html/assets"

if [ -d "$ASSETS_SRC" ]; then
    mkdir -p "$ASSETS_DST"
    cp -r "$ASSETS_SRC/"* "$ASSETS_DST/"
    echo "Assets installed."
else
    echo "WARNING: assets folder not found."
fi

if [ -d "$ASSETS_DST" ]; then
    validate_web_user
    chown -R "$WEB_USER:$WEB_GROUP" "$ASSETS_DST"
    find "$ASSETS_DST" -type d -exec chmod 755 {} \;
    find "$ASSETS_DST" -type f -exec chmod 644 {} \;
fi


#########################################################
# FRONTPAGE
#########################################################

mkdir -p /var/www/html

cat > /var/www/html/index.php <<'EOF'

<?php
/*
===============================================================================
 LAMP Deck v2.x
 ------------------------------------------------------------------------------
 Author: Aurélio Barreto
 E-mail: aurelio@aureliobarreto.com
 Project: https://github.com/albarreto/lampdeck-v2

 Copyright (C) 2026 Aurélio Barreto

 License
 -----------------------------------------------------------------------------
 GNU General Public License v3.0

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License,
 or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 See the GNU General Public License for more details:
 https://www.gnu.org/licenses/gpl-3.0.en.html
===============================================================================
*/

require_once '__LIB_DIR__/utils.php';
require_once '__LIB_DIR__/sites.php';
require_once '__LIB_DIR__/system.php';
require_once '__LIB_DIR__/update.php';

$dirs = list_sites();

$serverName = $_SERVER['HTTP_HOST'] ?? 'Servidor';
$totalSites = count($dirs);

$memInfo  = get_meminfo();
$diskInfo = get_diskinfo('/');

$services = [
    ['label' => 'Apache',  'unit' => 'apache2'],
    ['label' => 'PHP', 'unit' => detect_php_fpm_unit()],
    ['label' => 'Redis',   'unit' => 'redis-server'],
    ['label' => 'MariaDB', 'unit' => 'mariadb']
];

$appCategories = list_app_categories($dirs);
$updateInfo = lampdeck_update_available('__VERSAO__');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LAMP Deck v__VERSAO__</title>
    <link rel="stylesheet" href="/assets/css/frontpage.css">
    <script src="/assets/js/functions.js" defer></script>
</head>
<body>
    <div class="container">
        <section class="hero">
            <div class="hero-top">
                <div class="hero-title">
                    <div class="hero-title-group">
                        <img src="/assets/images/logo.webp" class="ld-logo" alt="LAMP Deck logo">
                        <div class="hero-text">
                            <h1>
                                <a href="/" style="color:inherit;text-decoration:none;">
                                    LAMP Deck
                                </a>
                                <?php if ($updateInfo['available']): ?>
                                    <a href="https://github.com/albarreto/lampdeck-v2" target="_blank" rel="noopener noreferrer">
                                        <span class="update-badge">UPDATE AVAILABLE: <?= h($updateInfo['latest']) ?></span>
                                    </a>
                                <?php endif; ?>
                            </h1>

                            <div class="subtitle-mini">
                                Multisite manager for LAMP Servers
                            </div>
                        </div>
                    </div>
                </div>

                <div class="service-mini-grid">
                    <?php foreach ($services as $svc): ?>
                        <?php
                            $status  = service_status($svc['unit']);
                            $version = service_version($svc['unit']);
                            $class   = status_class($status);
                        ?>
                        <div class="service-mini" title="<?= h($svc['label']) ?> <?= h($version ?: 'Unknown') ?> (<?= h($status) ?>)">
                            <div class="service-mini-head">
                                <span class="service-dot <?= h($class) ?>"></span>
                                <div class="service-mini-name"><?= h($svc['label']) ?></div>
                            </div>
                            <div class="service-mini-version"><?= h($version ?: 'Unknown') ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="stats">
                <div class="stat">
                    <div class="label">Host</div>
                    <div class="value"><?= h($serverName) ?></div>
                </div>

                <?php
                    $disabledCount = count(array_filter($dirs, fn($d) => is_disabled_site($d)));
                    $activeCount = $totalSites - $disabledCount;
                ?>

                <div class="stat">
                    <div class="label">Total Websites</div>
                    <div class="value"><?= $totalSites ?></div>
                    <div class="mini-info"><?= $activeCount ?> active / <?= $disabledCount ?> disabled</div>
                </div>

                <div class="stat compact">
                    <div class="resource-block">
                        <div class="resource-head">
                            <div class="resource-name">RAM</div>
                            <div class="resource-value">
                                <strong><?= h($memInfo['percent']) ?>%</strong> (<?= h(format_bytes($memInfo['used'])) ?> de <?= h(format_bytes($memInfo['total'])) ?>)
                            </div>
                        </div>

                        <div class="gauge" title="RAM <?= h(format_bytes($memInfo['used'])) ?> / <?= h(format_bytes($memInfo['total'])) ?>">
                            <div class="gauge-bar mem" style="width: <?= (int)$memInfo['percent'] ?>%;"></div>
                        </div>
                    </div>

                    <div class="resource-block">
                        <div class="resource-head">
                            <div class="resource-name">Disk</div>
                            <div class="resource-value">
                                <strong><?= h($diskInfo['percent']) ?>%</strong> (<?= h(format_bytes($diskInfo['used'])) ?> de <?= h(format_bytes($diskInfo['total'])) ?>)
                            </div>
                        </div>

                        <div class="gauge" title="Disk <?= h(format_bytes($diskInfo['used'])) ?> / <?= h(format_bytes($diskInfo['total'])) ?>">
                            <div class="gauge-bar disk" style="width: <?= (int)$diskInfo['percent'] ?>%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tabs">
                <button class="tab-button active" data-tab="sites">Websites</button>
                <button class="tab-button" data-tab="apps">Supported Apps</button>
                <button class="tab-button" data-tab="instrucoes">Instructions</button>
                <button class="tab-button" data-tab="ferramentas">Tools</button>
                <button class="tab-button" data-tab="changelog">Changelog</button>
            </div>
        </section>

        <section id="tab-sites" class="tab-panel active">
            <h2 class="section-title">Available Websites</h2>

            <?php if (empty($dirs)): ?>
                <div class="empty">
                    No website folders were found in <code>/var/www</code>.
                </div>
            <?php else: ?>
                <div class="filter-bar">
                    <div class="filter-group filter-categories">
                        <button class="filter-button active" data-filter="all">All</button>
                        <?php foreach (array_keys($appCategories) as $category): ?>
                            <button class="filter-button" data-filter="<?= h($category) ?>">
                                <?= h(ucfirst($category)) ?>
                            </button>
                        <?php endforeach; ?>
                    </div>

                    <div class="filter-group filter-visibility">
                        <button class="filter-button toggle-disabled" id="toggle-disabled" data-show-disabled="0">
                            Show disabled
                        </button>
                    </div>
                </div>

                <div class="grid">
                    <?php foreach ($dirs as $d): ?>
                        <?php
                            $isDisabled = is_disabled_site($d);
                            $displayName = base_site_name($d);
                            $icon = site_icon($d);
                            $appType = detect_app_type($d);
                            $appCategory = detect_app_category($d);
                            $desc = site_desc($d);
                            $typeLabel = site_type_label($d);
                            $adminPath = site_admin_path($d);
                            $adminLabel = site_admin_label($d);
                        ?>
                        <div class="site-card <?= $isDisabled ? 'site-disabled' : '' ?>"
                             data-category="<?= h($appCategory) ?>"
                             data-app-type="<?= h($appType) ?>"
                             data-disabled="<?= $isDisabled ? '1' : '0' ?>">

                            <div class="site-category">
                                <?= h($appCategory) ?> &middot; <?= h($appType) ?>
                            </div>

                            <?php if ($isDisabled): ?>
                                <div class="site-disabled-badge">DISABLED</div>
                            <?php endif; ?>

                            <div class="site-head">
                                <?php if (!$isDisabled): ?>
                                    <a class="site-icon-link" href="/<?= rawurlencode($displayName) ?>/" target="_blank" rel="noopener noreferrer">
                                        <img
                                            class="site-icon"
                                            src="<?= h($icon) ?>"
                                            alt="<?= h($typeLabel) ?>"
                                            title="<?= h($typeLabel) ?>"
                                        >
                                    </a>
                                <?php else: ?>
                                    <div class="site-icon-link site-icon-disabled">
                                        <img
                                            class="site-icon"
                                            src="<?= h($icon) ?>"
                                            alt="<?= h($typeLabel) ?>"
                                            title="<?= h($typeLabel) ?>"
                                        >
                                    </div>
                                <?php endif; ?>

                                <div class="site-title-row">
                                    <?php if (!$isDisabled): ?>
                                        <a class="site-name-link" href="/<?= rawurlencode($displayName) ?>/" target="_blank" rel="noopener noreferrer">
                                            <div class="site-name"><?= h($displayName) ?></div>
                                        </a>
                                    <?php else: ?>
                                        <div class="site-name site-name-disabled"><?= h($displayName) ?></div>
                                    <?php endif; ?>

                                    <?php if (!$isDisabled && $adminPath !== ''): ?>
                                        <?php $adminHref = '/' . rawurlencode($displayName) . '/' . ltrim($adminPath, '/'); ?>
                                        <a
                                            class="site-admin-link"
                                            href="<?= h($adminHref) ?>"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                        >(<?= h($adminLabel) ?>)</a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if ($desc !== ''): ?>
                                <div class="site-meta"><?= h($desc) ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

         <section id="tab-apps" class="tab-panel">
            <h2 class="section-title">Supported Applications</h2>

            <div class="cmd-block">
                <div class="cmd-title">Supported applications</div>

                <div class="cmd-desc">
                    These applications can be deployed using
                    <code>lampdeck install &lt;app&gt; &lt;site_folder&gt; "Optional description"</code>.
                </div>

                <div class="cmd-title" style="margin-top:12px;">Quick examples</div>
                <pre>
lampdeck install wordpress blog
lampdeck install dokuwiki docs "Internal documentation"</pre>
            </div>

            <div class="table-wrap">
                <table class="apps-table">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Application</th>
                            <th>Description</th>
                            <th>Database</th>
                            <th>Command</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Static</td>
                            <td>HTML</td>
                            <td>Static websites</td>
                            <td>No</td>
                            <td><code>lampdeck install html my-site</code></td>
                        </tr>
                        <tr>
                            <td>Dev</td>
                            <td>PHP</td>
                            <td>Custom PHP applications</td>
                            <td>No</td>
                            <td><code>lampdeck install php my-site</code></td>
                        </tr>
                        <tr>
                            <td>CMS</td>
                            <td>WordPress</td>
                            <td>Blogging and CMS platform</td>
                            <td>Yes</td>
                            <td><code>lampdeck install wordpress my-cms</code></td>
                        </tr>
                        <tr>
                            <td>CMS</td>
                            <td>Joomla</td>
                            <td>Enterprise CMS</td>
                            <td>Yes</td>
                            <td><code>lampdeck install joomla my-cms</code></td>
                        </tr>
                        <tr>
                            <td>CMS</td>
                            <td>Grav</td>
                            <td>Flat-file CMS</td>
                            <td>No</td>
                            <td><code>lampdeck install grav my-cms</code></td>
                        </tr>
                        <tr>
                            <td>Wiki / Documentation</td>
                            <td>DokuWiki</td>
                            <td>Lightweight wiki</td>
                            <td>No</td>
                            <td><code>lampdeck install dokuwiki my-wiki</code></td>
                        </tr>
                        <tr>
                            <td>Wiki / Documentation</td>
                            <td>MediaWiki</td>
                            <td>Wikipedia-style wiki</td>
                            <td>Yes</td>
                            <td><code>lampdeck install mediawiki my-wiki</code></td>
                        </tr>
                        <tr>
                            <td>Business</td>
                            <td>Dolibarr</td>
                            <td>ERP / CRM system</td>
                            <td>Yes</td>
                            <td><code>lampdeck install dolibarr my-erp</code></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="cmd-desc" style="margin-top:12px;">
                More applications coming soon.
            </div>
        </section>

        <section id="tab-instrucoes" class="tab-panel">
            <h2 class="section-title">Instructions</h2>

            <div class="commands">

                <div class="cmd-block">
                    <div class="cmd-title">Create a website</div>
                    <div class="cmd-desc">
                        Install any supported application using a single command. See <strong>Supported Apps</strong> tab for available options.
                    </div>
                    <pre>lampdeck install &lt;app&gt; &lt;site_folder&gt; "Optional description"</pre>
                </div>
                <div class="cmd-block">
                    <div class="cmd-title">Configure a domain for an existing folder</div>
                    <div class="cmd-desc">Creates Apache vhost for an existing site.</div>
                    <pre>lampdeck create-domain site1.com site1</pre>
                </div>

                <div class="cmd-block">
                    <div class="cmd-title">Enable valid SSL with Let's Encrypt</div>
                    <div class="cmd-desc">Use when the domain is already pointing to the server IP.</div>
                    <pre>lampdeck activate-ssl site1.com</pre>
                </div>

                <div class="cmd-block">
                    <div class="cmd-title">Enable or disable a website</div>
                    <div class="cmd-desc">Temporarily disable a site without deleting it, or re-enable it later.</div>
                    <pre>
lampdeck disable site1
lampdeck enable site1</pre>
                </div>
            </div>
        </section>

        <section id="tab-ferramentas" class="tab-panel">
            <h2 class="section-title">Tools</h2>
            <div class="grid">
                <a class="tool-card" href="/phpmyadmin/" target="_blank" rel="noopener noreferrer">
                    <div class="tool-title">phpMyAdmin</div>
                    <div class="tool-desc">Access MariaDB through the browser.</div>
                </a>

                <a class="tool-card" href="/info.php" target="_blank" rel="noopener noreferrer">
                    <div class="tool-title">phpinfo()</div>
                    <div class="tool-desc">Check PHP modules, directives and environment details.</div>
                </a>
            </div>
        </section>

<!-- xxx -->

        <section id="tab-changelog" class="tab-panel">
            <h2 class="section-title">Changelog</h2>
            <div class="cmd-block">
                <pre>
Version 2.6.3 - 2026-05-10
- Improved Alpine Linux support
- Fixed HTTPS domain handling on Alpine
- Improved Apache virtual host compatibility across distributions
- Fixed frontpage and subsite coexistence
- Improved subpath website access compatibility

Version 2.6.2 - 2026-05-10
- Fixed domain vhost precedence overriding websites with frontpage default virtual hosts
- Removed unnecessary 000-lampdeck Apache vhosts during domain creation
- Improved Apache VirtualHost behavior for domain-based access on Alpine Linux

Version 2.6.1 - 2026-05-09
- Fixed PHP-FPM startup issues after reboot on Debian, Ubuntu and Alpine
- Improved PHP version detection across all supported distributions
- Improved Linux distribution detection using PRETTY_NAME
- Fixed Alpine Linux compatibility with OpenRC environments
- Fixed Apache/PHP-FPM socket handling on Alpine Linux

Version 2.6.0 - 2026-05-08
- Added Alpine Linux support (bash is required: apk add bash)
- Added automatic web user detection (multi-distro support)
- Removed hardcoded www-data user
- Improved compatibility with Alpine Linux
- Tools tab moved to other position
- Fixed regression introduced in 2.5.11 causing PHP-FPM socket issues after reboot

Version 2.5.11 - 2026-05-04
- Added "Supported Apps" tab with application list and descriptions
- Simplified Instructions tab
- Unified PHP-FPM socket
- Cleaned old PHP-FPM services and Apache configs automatically
- Standardized PHP packages
- All vhosts use version-independent socket
- Fixed incorrect PHP version detection
- Fixed Apache version output (now displays only the version number)

Version 2.5.9 - 2026-05-03
- Fixed PHP-FPM service detection in frontpage
- Fixed PHP version display on Ubuntu Jammy (removed distro suffix)
- Fixed PHP version detection in CLI (now matches active PHP-FPM)
- Fixed underline on update badge link in frontpage
- Support for Ubuntu 26.04 LTS (Resolute) - beta
- Ubuntu Jammy installer: switched to native PHP 8.1 (removed PPA).
- Ubuntu Noble installer: switched to native PHP 8.3 (removed PPA).

Version 2.5.6 - 2026-04-30
- Added Dolibarr ERP/CRM installer
- Added Grav CMS installer
- Added MediaWiki installer and new Wiki examples in Instructions section
- Refactored frontpage PHP helpers into dedicated libraries
- Fixed runtime version check on frontpage
- Fixed clean overwrite during install (lib/apps/pkg/assets)
- Fixed Ubuntu Noble SSL cert path issue
- Centralized version in common.sh

Version 2.5.4 - 2026-04-21
- Added Docuwiki installer
- Added MediaWiki installer
- Added option for installer/upgrade: # install_lampdeck.sh --ignore-install
- Added enable/disable commands to temporarily hide sites without deleting them

Version 2.5.3 - 2026-04-18
- Fixed install from scratch

Version 2.5.2 - 2026-04-18
- Added app categories

Version 2.5.0 - 2026-04-17
- Removed create-website command (replaced for "lampdesk install html/php ...")

Version 2.4.2 - 2026-04-17
- Fixed site type detection in "lampdeck sites"

Version 2.4.1 - 2026-04-17
- Standardized app installers using shared app-common.sh
- Unified structure for apps with and without database
- Simplified creation of new app scripts (minimal variables required)
- Added daily cache to avoid re-downloading packages on the same day
- Improved rollback when installation is cancelled or fails
- Fixed site folder removal when database overwrite is declined
- Fixed Joomla installation path after extraction
- Fixed loading of shared functions from app-common
- Renamed frontpage tab from HTML to HTML/PHP
- Updated frontpage new version alert text

Version 2.4.0 - 2026-04-16
- Frontpage filter by app type (HTML, WordPress, Joomla)
- Improved error message for unsupported apps
- Added confirmation prompt before replacing an existing database
- Existing database is only dropped after user confirmation
- Site folder is now removed if installation is cancelled during database overwrite

Version 2.3.2 - 2026-04-16
- Dashboard notification when a newer version of LAMP Deck is available.

Version 2.3.1 - 2026-04-16
- Fixed MariaDB root password prompt bug
- New optional `-d <domain>` flag in `lampdeck install` to create the domain during app installation.

Version 2.3.0 - 2026-04-15
- Added Joomla installer
- Shared DB validation library for apps
- Improved validation rules for site names
- Admin link support (WordPress, Joomla)
- Consistent typography in site info cards

Version 2.2.1 - 2026-04-15
- Simplified changelog
- Shared validation and DB logic across apps
- Prevent unnecessary DB password prompt when site exists

Version 2.2.0 - 2026-04-14
- Modular app architecture
- WordPress installer moved to apps/wordpress.sh
- New command: lampdeck install wordpress
- Improved frontpage app detection using .app-type markers
- Improved install flow validation
- Cached WordPress download reused when available

Version 2.1.5 - 2026-04-14
- Frontpage is always preserved when accessing the server by IP
- Domains no longer override the main frontpage
- Improved multisite behavior
- Prevents modification when website folder already exists
- More reliable domain creation
- Improved default website template (light layout)
- Version command now shows Apache, PHP, MariaDB and Redis versions
- Fixed installation phpmyadmin in upgrades
- Fixed logo size in Frontpage
- Fixed phpmyadmin installation
- Fixed installation PHP8.4 packages for Ubuntu releases

Version 2.1.0 - 2026-04-12
- Added support for Ubuntu LTS releases (22.04 Jammy, 24.04 Noble)

Version 2.0.0 - 2026-04-11
- Initial release

                </pre>
            </div>
        </section>

        <div class="footer">
            LAMP Deck v__VERSAO__ &middot; __ID__
            <?php if ($updateInfo['available']): ?>
                &middot; <strong> UPDATE AVAILABLE: <?= h($updateInfo['latest']) ?></strong>
            <?php endif; ?>
            &middot; &copy; <?= date('Y') ?> Aurélio Barreto
            <!-- próximo ano: &middot; &copy; 2026 - <?= date('Y') ?> Aurélio Barreto -->
            &middot; <a href="https://github.com/albarreto/lampdeck-v2" target="_blank" rel="noopener noreferrer">GitHub</a>
        </div>
    </div>

</body>
</html>

EOF

sed -i "s|__LIB_DIR__|${LIB_DIR}|g" /var/www/html/index.php
sed -i "s/__VERSAO__/${APP_VERSION}/g" /var/www/html/index.php
DIST_LABEL="${PRETTY_NAME:-${ID:-Linux}}"
sed -i "s|__ID__|${DIST_LABEL}|g" /var/www/html/index.php
sed -i "s/__VERSION_CODENAME__//g" /var/www/html/index.php

touch "$SUBSITES_CONF"
cat > "$SUBSITES_CONF" <<EOF
# LAMP Deck subsite aliases
EOF


#########################################################
# INFO PHP
#########################################################

echo "<?php phpinfo();" > /var/www/html/info.php

#########################################################
# BASH COMPLETION
#########################################################

mkdir -p /etc/bash_completion.d
cat > /etc/bash_completion.d/lampdeck <<'EOF'
_lampdeck_completions()
{
    local cur prev prev2 cmd
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    prev2="${COMP_WORDS[COMP_CWORD-2]}"
    cmd="${COMP_WORDS[1]}"

    local commands="install create-domain activate-ssl sites version help enable disable"

    _lampdeck_list_sites()
    {
        if [ -d /var/www ]; then
            find /var/www -mindepth 1 -maxdepth 1 -type d 2>/dev/null \
                | xargs -r -n1 basename \
                | grep -vE '^(html|certs)$'
        fi
    }

    _lampdeck_list_domains()
    {
        if [ -d /etc/apache2/sites-available ]; then
            find /etc/apache2/sites-available -maxdepth 1 -type f -name '*.conf' 2>/dev/null \
                | xargs -r -n1 basename \
                | sed 's/\.conf$//' \
                | grep -vE '^(000-lampdeck-default)$'
        fi
    }

    if [ "$COMP_CWORD" -eq 1 ]; then
        COMPREPLY=( $(compgen -W "$commands" -- "$cur") )
        return 0
    fi

    case "$cmd" in
        create-domain)
            if [ "$COMP_CWORD" -eq 3 ]; then
                COMPREPLY=( $(compgen -W "$(_lampdeck_list_sites)" -- "$cur") )
                return 0
            fi
            ;;
        activate-ssl)
            if [ "$COMP_CWORD" -eq 2 ]; then
                COMPREPLY=( $(compgen -W "$(_lampdeck_list_domains)" -- "$cur") )
                return 0
            fi
            ;;
        enable|disable)
            if [ "$COMP_CWORD" -eq 2 ]; then
                COMPREPLY=( $(compgen -W "$(_lampdeck_list_sites)" -- "$cur") )
                return 0
            fi
            ;;
    esac
}

complete -F _lampdeck_completions lampdeck
EOF

#########################################################
# DISABLE DEFAULT APACHE PAGE
#########################################################

if [ -f /var/www/html/index.html ] && [ ! -f /var/www/html/index_apache.html ]; then
    mv /var/www/html/index.html /var/www/html/index_apache.html
fi

echo
echo "#############################################################"
echo "CONGRATULATIONS!!! ${APP_NAME} v${APP_VERSION} was installed/upgraded."
echo "#############################################################"
echo
echo "How to access:"
echo "  https://${SERVER_IP}/"
echo "  https://${SERVER_IP}/phpmyadmin/"
echo
echo "Installed Commands:"
echo "  lampdeck install wordpress site1 \"Company WordPress Website\""
echo "  lampdeck create-domain site1.com site1"
echo "  lampdeck activate-ssl site1.com"
echo "  lampdeck sites"
echo "  lampdeck version"
echo "  lampdeck help"
echo "  lampdeck disable|enable site1.com"
echo
echo "Autocompletation for lampdeck was installed."
echo "NOTE: To enable it in the current shell, run: source /etc/bash_completion.d/lampdeck"
echo "      or close and reopen terminal"
echo

