#!/bin/bash
set -euo pipefail

FILE="pkg_ubuntu_resolute.sh"

cp "$FILE" "${FILE}.bak"

replace() {
    sed -i "s|$1|$2|g" "$FILE"
}

# Etapas
replace 'echo "== Updating system"' \
'echo -e "${CYAN}Updating system...${NC}"'

replace 'echo "== Base packages"' \
'echo -e "${CYAN}Installing base packages...${NC}"'

replace 'echo "== Installing Apache"' \
'echo -e "${CYAN}Installing Apache...${NC}"'

replace 'echo "== Installing PHP ${PHP_VERSION} from Ubuntu native repositories"' \
'echo -e "${CYAN}Installing PHP ${PHP_VERSION} from Ubuntu native repositories...${NC}"'

replace 'echo "== Installing optional PHP Imagick"' \
'echo -e "${CYAN}Installing optional PHP Imagick...${NC}"'

replace 'echo "== Cleaning old PHP-FPM configurations"' \
'echo -e "${CYAN}Cleaning old PHP-FPM configurations...${NC}"'

replace 'echo "== Installing Redis"' \
'echo -e "${CYAN}Installing Redis...${NC}"'

replace 'echo "== Installing Certbot"' \
'echo -e "${CYAN}Installing Certbot...${NC}"'

replace 'echo "== Installing MariaDB"' \
'echo -e "${CYAN}Installing MariaDB...${NC}"'

replace 'echo "== Configuring MariaDB root password"' \
'echo -e "${CYAN}Configuring MariaDB root password...${NC}"'

replace 'echo "== Installing phpMyAdmin"' \
'echo -e "${CYAN}Installing phpMyAdmin...${NC}"'

replace 'echo "== Configuring phpMyAdmin database"' \
'echo -e "${CYAN}Configuring phpMyAdmin database...${NC}"'

replace 'echo "== Checking default self-signed certificate"' \
'echo -e "${CYAN}Checking default self-signed certificate...${NC}"'

replace 'echo "== Generating default self-signed certificate"' \
'echo -e "${CYAN}Generating default self-signed certificate...${NC}"'

# Warnings
replace 'echo "WARNING: php-imagick could not be installed. Continuing without Imagick."' \
'echo -e "${YELLOW}WARNING: php-imagick could not be installed. Continuing without Imagick.${NC}"'

replace 'echo "WARNING: phpMyAdmin internal SQL file not found."' \
'echo -e "${YELLOW}WARNING: phpMyAdmin internal SQL file not found.${NC}"'

# Errors
replace 'echo "ERROR: DB_ROOT_PASS is required to configure phpMyAdmin."' \
'echo -e "${RED}ERROR: DB_ROOT_PASS is required to configure phpMyAdmin.${NC}"'

# Success
replace 'echo "== Existing default certificate found. Keeping current files."' \
'echo -e "${GREEN}Existing default certificate found. Keeping current files.${NC}"'

python3 <<'PY'
from pathlib import Path

p = Path("pkg_ubuntu_resolute.sh")
s = p.read_text()

old = '''
    echo
    echo "============================================"
    echo "Ubuntu 26.04 package stack installed."
    echo "============================================"
    echo
}
'''

new = '''
    echo
    echo -e "${CYAN}============================================${NC}"
    echo -e "${GREEN}Ubuntu 26.04 package stack installed successfully.${NC}"
    echo -e "${CYAN}============================================${NC}"
    echo
}
'''

s = s.replace(old, new)
p.write_text(s)
PY

bash -n "$FILE"

echo "OK: $FILE colorized."
echo "Backup: ${FILE}.bak"
