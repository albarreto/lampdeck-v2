#!/bin/bash

###############################################################################
# LAMP Deck app common helpers
#
# Shared helper functions used by all application installers.
###############################################################################

set -euo pipefail

###############################################################################
# App metadata
###############################################################################

APP_HAS_DB="${APP_HAS_DB:-0}"

# Example: wordpress
APP_SLUG="${APP_SLUG:-}"

# Example: WordPress
APP_NAME="${APP_NAME:-}"

# Example: /tmp/wordpress-latest.tar.gz
APP_CACHE_FILE="${APP_CACHE_FILE:-}"

# Example: https://wordpress.org/latest.tar.gz
APP_DOWNLOAD_URL="${APP_DOWNLOAD_URL:-}"

###############################################################################
# Runtime variables
###############################################################################

ROLLBACK_NEEDED=0
APP_TMP_DIR=""
DB_ROOT_PASS=""

###############################################################################
# Validate required app metadata
###############################################################################

app_require_metadata() {
    if [ -z "$APP_SLUG" ] || [ -z "$APP_NAME" ]; then
        echo "ERROR: APP_SLUG and APP_NAME must be defined in the app module."
        exit 1
    fi
}

###############################################################################
# Define default values
###############################################################################

app_set_defaults() {
    APP_CACHE_FILE="${APP_CACHE_FILE:-/tmp/${APP_SLUG}-latest.tar.gz}"
}

###############################################################################
# Installation usage helper
###############################################################################

app_usage() {
    echo "Usage: lampdeck install $APP_SLUG <site-name> [description]"
}

###############################################################################
# Initialize site-related variables
###############################################################################

app_init_site_vars() {
    SITE="$(normalize_site_name "${1:-}")"
    DESC="${2:-}"
    BASE="$WWW_ROOT/$SITE"
    SERVER_IP="$(get_server_ip)"

    APP_WEBROOT="${APP_WEBROOT:-}"
    ALIAS_TARGET="$BASE"

    if [ -n "$APP_WEBROOT" ]; then
        ALIAS_TARGET="$BASE/$APP_WEBROOT"
    fi
}

###############################################################################
# Initialize database credentials
###############################################################################

app_init_db_vars() {
    DB_NAME="$SITE"
    DB_USER="$SITE"
    DB_PASS="$(openssl rand -base64 18 | tr -dc 'a-zA-Z0-9' | head -c16)"
}

###############################################################################
# Validate installation inputs
###############################################################################

app_validate_inputs() {
    validate_required_site_name \
        "$SITE" \
        "$(app_usage)" \
        || exit 1

    validate_site_name_format "$SITE" || exit 1
    validate_site_not_exists "$BASE" || exit 1
}

###############################################################################
# Cleanup on installation failure or exit
###############################################################################

app_cleanup_on_exit() {
    local exit_code=$?

    # Rollback created website if installation failed
    if [ "$exit_code" -ne 0 ] && [ "$ROLLBACK_NEEDED" = "1" ]; then
        echo
        echo "Installation failed or cancelled. Removing created site..."
        remove_site "$SITE" || true
    fi

    # Cleanup temporary extraction directory
    if [ -n "${APP_TMP_DIR:-}" ] && [ -d "$APP_TMP_DIR" ]; then
        rm -rf "$APP_TMP_DIR"
    fi
}

###############################################################################
# Enable automatic rollback trap
###############################################################################

app_setup_rollback() {
    trap app_cleanup_on_exit EXIT
}

###############################################################################
# Enable rollback mode
###############################################################################

app_enable_rollback() {
    ROLLBACK_NEEDED=1
}

###############################################################################
# Disable rollback and cleanup temporary files
###############################################################################

app_disable_rollback() {
    ROLLBACK_NEEDED=0
    trap - EXIT

    # Cleanup temporary extraction directory after successful install
    if [ -n "${APP_TMP_DIR:-}" ] && [ -d "$APP_TMP_DIR" ]; then
        rm -rf "$APP_TMP_DIR"
    fi
}

###############################################################################
# Print installation header
###############################################################################

app_print_header() {
    echo
    echo "============================================"
    echo "Installing $APP_NAME: $SITE"
    echo "============================================"
    echo
}

###############################################################################
# Prompt and validate database root password
###############################################################################

app_prompt_and_validate_db_root() {
    DB_ROOT_PASS="$(db_prompt_root_password)"

    db_validate_root "$DB_ROOT_PASS" || {
        echo "ABORTING installation."
        exit 1
    }
}

###############################################################################
# Create website structure and Apache alias
###############################################################################

app_create_base_site_structure() {
    if [ -e "$BASE" ]; then
        echo
        echo "Error: website folder already exists:"
        echo "  $BASE"
        echo
        echo "Installation ABORTED to avoid overwriting existing content."
        echo
        exit 1
    fi

    mkdir -p "$BASE"

    # Ensure Apache aliases file exists
    if [ ! -f "$SUBSITES_CONF" ]; then
        touch "$SUBSITES_CONF"
    fi

    # Create Apache alias only if it does not already exist
    if ! grep -q "Alias /$SITE/" "$SUBSITES_CONF" 2>/dev/null; then

        cat >> "$SUBSITES_CONF" <<EOT

RedirectMatch 302 ^/$SITE$ /$SITE/

Alias /$SITE/ $ALIAS_TARGET/

<Directory $ALIAS_TARGET/>
    AllowOverride All
    Require all granted
    DirectoryIndex index.php index.html
</Directory>

EOT

    fi

    app_enable_rollback
}

###############################################################################
# Create database or abort installation
###############################################################################

app_create_database_or_abort() {
    if ! db_create_database \
        "$DB_ROOT_PASS" \
        "$DB_NAME" \
        "$DB_USER" \
        "$DB_PASS"; then

        echo
        echo "Installation aborted."

        return 1 2>/dev/null || exit 1
    fi

    unset DB_ROOT_PASS
}

###############################################################################
# Prepare application with database support
###############################################################################

app_prepare_with_db() {
    app_require_metadata
    app_set_defaults

    app_init_site_vars "${1:-}" "${2:-}"
    app_init_db_vars

    app_setup_rollback
    app_validate_inputs
    app_print_header
    app_prompt_and_validate_db_root

    echo "Creating base website..."
    app_create_base_site_structure

    echo
    echo "Preparing database..."

    app_create_database_or_abort
}

###############################################################################
# Prepare application without database support
###############################################################################

app_prepare_no_db() {
    app_require_metadata
    app_set_defaults

    app_init_site_vars "${1:-}" "${2:-}"

    app_setup_rollback
    app_validate_inputs
    app_print_header

    echo "Creating base website..."
    app_create_base_site_structure

    echo
}

###############################################################################
# Temporary extraction directory
#
# Uses /var/tmp instead of /tmp because many modern Linux distributions
# mount /tmp as tmpfs (RAM-backed filesystem), which may not have enough
# space for large applications like Nextcloud, Moodle or MediaWiki.
###############################################################################

app_init_tmp_dir() {
    local tmp_root="/var/tmp/lampdeck"

    mkdir -p "$tmp_root"

    APP_TMP_DIR="$(mktemp -d "$tmp_root/${APP_SLUG}.XXXXXX")"

    chmod 700 "$APP_TMP_DIR"

    export APP_TMP_DIR
}

###############################################################################
# Download application package if not cached today
###############################################################################

app_download_if_needed() {
    local cache_file="$1"
    local download_url="$2"

    if [ -z "$cache_file" ] || [ -z "$download_url" ]; then
        echo "ERROR: cache file and download URL are required."
        exit 1
    fi

    # Reuse package downloaded today
    if [ -f "$cache_file" ] && find "$cache_file" -mtime 0 | grep -q .; then
        echo "Using cached $APP_NAME package (downloaded today)"
        return 0
    fi

    echo "Downloading $APP_NAME..."

    wget \
        --no-use-server-timestamps \
        -O "$cache_file" \
        "$download_url"
}

###############################################################################
# Extract application archive
###############################################################################

app_extract_archive() {
    local subdir="${1:-}"

    echo "Extracting $APP_NAME package..."

    tar xf "$APP_CACHE_FILE" -C "$APP_TMP_DIR"

    # Validate expected extraction subdirectory
    if [ -n "$subdir" ]; then

        if [ ! -d "$APP_TMP_DIR/$subdir" ]; then
            echo "ERROR: expected subdirectory '$subdir' not found in package"
            exit 1
        fi

        APP_EXTRACT_ROOT="$APP_TMP_DIR/$subdir"

    else

        APP_EXTRACT_ROOT="$APP_TMP_DIR"

    fi
}

###############################################################################
# Copy extracted files to final website directory
###############################################################################

app_copy_files_to_base() {
    echo "Copying $APP_NAME files to $BASE..."
    rsync -a "$APP_EXTRACT_ROOT/" "$BASE/"
}

###############################################################################
# Escape INI values safely
###############################################################################

app_ini_escape() {
    local value="${1:-}"

    value="${value//\\/\\\\}"
    value="${value//\"/\\\"}"

    printf '"%s"' "$value"
}

###############################################################################
# Generate lampdeck.ini metadata file
###############################################################################

app_write_metadata() {
    cat > "$BASE/lampdeck.ini" <<EOF
[app]
type = $(app_ini_escape "${APP_SLUG}")
name = $(app_ini_escape "${APP_NAME}")
category = $(app_ini_escape "${APP_CATEGORY:-Unknown}")
has_db = ${APP_HAS_DB:-0}

[admin]
path = $(app_ini_escape "${APP_ADMIN_PATH:-}")
label = $(app_ini_escape "${APP_ADMIN_LABEL:-}")

[site]
description = $(app_ini_escape "${DESC:-}")
EOF
}

###############################################################################
# Apply default website permissions
###############################################################################

app_apply_default_permissions() {
    validate_web_user

    chown -R "$WEB_USER:$WEB_GROUP" "$BASE"

    find "$BASE" -type d -exec chmod 755 {} \;
    find "$BASE" -type f -exec chmod 644 {} \;
}

###############################################################################
# Apply writable permissions to selected paths
###############################################################################

app_apply_rw_permissions() {
    local path

    for path in "$@"; do
        if [ -n "$path" ] && [ -d "$path" ]; then
            chmod -R 775 "$path"
        fi
    done
}

###############################################################################
# Reload Apache web server
###############################################################################

app_reload_apache() {
    apache_reload
}

###############################################################################
# Print success message for apps with database
###############################################################################

app_print_success_with_db() {
    echo
    echo "============================================"
    echo "$APP_NAME WEBSITE CREATED"
    echo "URL: https://$SERVER_IP/$SITE/"
    echo "DB NAME: $DB_NAME"
    echo "DB USER: $DB_USER"
    echo "PASSWORD: $DB_PASS"
    echo
    echo "NOTE: Finish installation in the browser"
    echo "============================================"
    echo
}

###############################################################################
# Print success message for apps without database
###############################################################################

app_print_success_no_db() {
    echo
    echo "============================================"
    echo "$APP_NAME WEBSITE CREATED"
    echo "URL: https://$SERVER_IP/$SITE/"
    echo
    echo "NOTE: Finish installation in the browser"
    echo "============================================"
    echo
}
