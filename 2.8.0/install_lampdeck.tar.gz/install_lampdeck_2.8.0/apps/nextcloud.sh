#!/bin/bash

###############################################################################
# LAMP Deck app module
# nextcloud
#
# Description:
# Installs and configures a Nextcloud site inside the LAMP Deck environment.
#
# Usage:
# lampdeck install nextcloud <site-name> [description]
#
###############################################################################

set -euo pipefail

LIB_DIR="${LIB_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"

source "$LIB_DIR/common.sh"
source "$LIB_DIR/validate.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/remove-site.sh"
source "$LIB_DIR/app-common.sh"

APP_SLUG="nextcloud"
APP_NAME="Nextcloud"
APP_CATEGORY="Collaboration"
APP_HAS_DB="1"

APP_ADMIN_PATH="settings/admin"
APP_ADMIN_LABEL="Admin"

APP_DOWNLOAD_URL="https://download.nextcloud.com/server/releases/latest.tar.bz2"

###############################################################################
# PREPARE
###############################################################################

app_prepare_with_db "${1:-}" "${2:-}"

###############################################################################
# NEXTCLOUD ADMIN
###############################################################################

read -r -p "Nextcloud admin username: " NC_ADMIN_USER

if [ -z "${NC_ADMIN_USER:-}" ]; then
    echo "ERROR: admin username cannot be empty."
    exit 1
fi

read -r -s -p "Nextcloud admin password: " NC_ADMIN_PASS
echo

if [ -z "${NC_ADMIN_PASS:-}" ]; then
    echo "ERROR: admin password cannot be empty."
    exit 1
fi

###############################################################################
# PACKAGE
###############################################################################

app_download_if_needed "$APP_CACHE_FILE" "$APP_DOWNLOAD_URL"

app_init_tmp_dir

echo "Extracting Nextcloud package..."

tar xjf "$APP_CACHE_FILE" -C "$APP_TMP_DIR"

APP_EXTRACT_ROOT="$APP_TMP_DIR/nextcloud"

if [ ! -d "$APP_EXTRACT_ROOT" ]; then
    echo "ERROR: extracted Nextcloud directory not found"
    exit 1
fi

app_copy_files_to_base

###############################################################################
# DATA DIRECTORY
###############################################################################

mkdir -p "$BASE/data"

###############################################################################
# PERMISSIONS
###############################################################################

app_apply_default_permissions

app_apply_rw_permissions \
    "$BASE/config" \
    "$BASE/custom_apps" \
    "$BASE/data" \
    "$BASE/themes"

###############################################################################
# NEXTCLOUD INSTALL
###############################################################################

SERVER_HOST="${HOSTNAME_FQDN:-$SERVER_IP}"

echo
echo "Installing Nextcloud..."
echo

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" maintenance:install \
    --database mysql \
    --database-name \"$DB_NAME\" \
    --database-user \"$DB_USER\" \
    --database-pass \"$DB_PASS\" \
    --admin-user \"$NC_ADMIN_USER\" \
    --admin-pass \"$NC_ADMIN_PASS\" \
    --data-dir \"$BASE/data\"
"

###############################################################################
# NEXTCLOUD CONFIG
###############################################################################

echo
echo "Configuring Nextcloud..."
echo

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set trusted_domains 0 \
    --value=\"$SERVER_HOST\"
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set trusted_domains 1 \
    --value=\"$SITE\"
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set trusted_domains 2 \
    --value=\"$SERVER_IP\"
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set overwritewebroot \
    --value=\"/$SITE\"
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set overwriteprotocol \
    --value=\"https\"
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set overwrite.cli.url \
    --value=\"https://$SERVER_HOST/$SITE\"
"

###############################################################################
# REDIS / APCU
###############################################################################

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set memcache.local \
    --value='\\OC\\Memcache\\APCu'
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set memcache.locking \
    --value='\\OC\\Memcache\\Redis'
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set redis host \
    --value=\"127.0.0.1\"
"

su -s /bin/sh "$WEB_USER" -c "
php \"$BASE/occ\" config:system:set redis port \
    --type=integer \
    --value=6379
"

###############################################################################
# APACHE / REWRITE
###############################################################################

cat > "$BASE/.htaccess" <<EOF
<IfModule mod_rewrite.c>

RewriteEngine on

RewriteRule .* - [env=HTTP_AUTHORIZATION:%{HTTP:Authorization}]

RewriteBase /$SITE/

RewriteRule ^index\\.php$ - [L]

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d

RewriteRule . /$SITE/index.php [L]

</IfModule>
EOF

###############################################################################
# PHP TUNING
###############################################################################

PHP_VERSION="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"

for ini in \
    "/etc/php/${PHP_VERSION}/fpm/php.ini" \
    "/etc/php/${PHP_VERSION}/cli/php.ini"
do

    [ -f "$ini" ] || continue

    sed -i 's/^memory_limit = .*/memory_limit = 512M/' "$ini"
    sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 10G/' "$ini"
    sed -i 's/^post_max_size = .*/post_max_size = 10G/' "$ini"
    sed -i 's/^max_execution_time = .*/max_execution_time = 3600/' "$ini"
    sed -i 's/^max_input_time = .*/max_input_time = 3600/' "$ini"

done

###############################################################################
# METADATA
###############################################################################

app_write_metadata "$APP_SLUG"

###############################################################################
# APACHE
###############################################################################

app_reload_apache

systemctl restart "php${PHP_VERSION}-fpm" 2>/dev/null || true

app_disable_rollback

###############################################################################
# OUTPUT
###############################################################################

echo
echo "======================================================"
echo "NEXTCLOUD INSTALLED SUCCESSFULLY"
echo "======================================================"
echo
echo "URL:"
echo "  https://$SERVER_HOST/$SITE/"
echo
echo "DATABASE:"
echo "  DB NAME: $DB_NAME"
echo "  DB USER: $DB_USER"
echo "  PASSWORD: $DB_PASS"
echo
echo "NEXTCLOUD ADMIN:"
echo "  USER: $NC_ADMIN_USER"
echo
echo "RECOMMENDED:"
echo "  lampdeck create-domain cloud.local $SITE"
echo
echo "AFTER CREATING DOMAIN:"
echo "  su -s /bin/sh "$WEB_USER" -c 'php $BASE/occ config:system:set trusted_domains 2 --value=cloud.local'"
echo "  su -s /bin/sh "$WEB_USER" -c 'php $BASE/occ config:system:set overwrite.cli.url --value=https://cloud.local'"
echo
